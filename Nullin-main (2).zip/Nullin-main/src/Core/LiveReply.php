<?php

final class LiveReply
{
    public const DRAWING = '🎨 دارم می‌کشمش، چند لحظه صبر کن...';
    const DRAWING_EN = '🎨 Drawing it, wait a moment...';

    public const THINKING = '🧠 نالین داره فکر می‌کنه';
    const THINKING_EN = '🧠 Nullin is thinking';

    private const WAIT_TEXT = 'نالین داره فکر می‌کنه';
    const WAIT_TEXT_EN = 'Nullin is thinking';

    private array $ids    = [];
    private array $sent   = [];
    private string $mode  = 'wait';
    private int $lastLen  = 0;
    private int $lastTyping = 0;
    private bool $draft   = false;
    private bool $rich    = false;
    private int $draftId  = 0;
    private float $t0     = 0.0;
    private int $shown    = 0;
    private bool $armed   = false;
    private bool $adopted = false;
    private bool $richMsg = false;
    private bool $inTick  = false;
    private bool $typingOnly = false;
    private bool $stopped = false;
    private bool $quiet   = false;
    private static float $stopLast = 0.0;
    private static bool $stopHit   = false;

    public function __construct(private array $msg, private ?string $imid = null, private string $head = '', private bool $reaction = true, private bool $status = false, private bool $hold = false)
    {
    }

    public static function typingOnly(array $msg): self
    {
        $l             = new self($msg, null, '', false, true);
        $l->typingOnly = true;
        return $l;
    }

    public function watch(bool $now = false): void
    {
        if ($this->imid === null || $this->armed) {
            return;
        }
        if ($now) {
            Rich::editInline($this->imid, $this->frame(0));
        }
        $this->arm();
    }

    public function adopt(int $mid, bool $rich = false): void
    {
        $this->adopted = true;
        $this->richMsg = $rich;
        $this->quiet   = in_array($this->msg['chat']['type'] ?? '', ['group', 'supergroup'], true);
        $this->ids[0] = $mid;
        $this->editMsg($mid, $this->frame(0));
        $this->arm();
    }

    private function editMsg(int $mid, string $html): ?array
    {
        return AnswerButtons::editHtmlRich((int) $this->msg['chat']['id'], $mid, $html);
    }

    public function stop(): void
    {
        $this->disarm();
        $this->releaseStop();
    }

    /** کاربر دکمه‌ی استاپِ حباب رو زده؟ (بعد از releaseStop هم true می‌مونه) */
    public function stopped(): bool
    {
        return $this->stopped;
    }

    /** قطع‌کننده‌ی curl رو برمی‌داره؛ باید بعد از تموم‌شدن تولید جواب صدا زده بشه */
    public function releaseStop(): void
    {
        if ($this->draft && $this->draftId > 0) {
            self::stopReset($this->msg['chat']['id'], $this->draftId);
        }
        Http::clearAbort();
    }

    private function armStop(): void
    {
        if (!self::stopEnabled() || $this->draftId <= 0) {
            return;
        }
        $chat = $this->msg['chat']['id'];
        $did  = $this->draftId;
        $self = $this;
        self::stopReset($chat, $did);
        Http::$aborted = false;
        Http::$abort   = static function () use ($chat, $did, $self): bool {
            if (self::stopRequested($chat, $did)) {
                $self->stopped = true;
                return true;
            }
            return false;
        };
    }

    private function stopOpts(bool $stoppable): array
    {
        return $stoppable && self::stopEnabled() ? ['can_stop' => true, 'keep_on_stop' => true] : [];
    }

    /*
     * استاپ جنریشن (Bot API 10.3): حباب پیش‌نویس با can_stop فرستاده می‌شه و با زدن دکمه‌ی توقف آپدیت
     * stopped_message_generation میاد. چون هر آپدیت تو یه پروسه‌ی جدا اجرا می‌شه، فلگ تو دیتابیس نگه داشته می‌شه:
     *   Kernel::handle → LiveReply::onStopped()  ← فلگ رو می‌نویسه
     *   پروسه‌ی تولید  → stopRequested()         ← هر ~۰.۳ ثانیه فلگ رو چک می‌کنه و curl رو قطع می‌کنه
     */
    private static function stopEnabled(): bool
    {
        return (bool) App::cfg('gen_stop', true);
    }

    private static function stopKey(int|string $chatId, int $draftId): string
    {
        return $chatId . '_' . $draftId;
    }

    /** آپدیت stopped_message_generation: { chat, draft_id } */
    public static function onStopped(array $u): void
    {
        $chatId  = (int) ($u['chat']['id'] ?? 0);
        $draftId = (int) ($u['draft_id'] ?? 0);
        if ($chatId === 0 || $draftId === 0) {
            return;
        }
        Store::set('gen_stop', self::stopKey($chatId, $draftId), ['at' => time()]);
    }

    private static function stopRequested(int|string $chatId, int $draftId): bool
    {
        if (self::$stopHit) {
            return true;
        }
        $now = microtime(true);
        if ($now - self::$stopLast < 0.3) {
            return false;
        }
        self::$stopLast = $now;
        try {
            if (Store::get('gen_stop', self::stopKey($chatId, $draftId)) !== null) {
                self::$stopHit = true;
                return true;
            }
        } catch (Throwable) {
        }
        return false;
    }

    private static function stopReset(int|string $chatId, int $draftId): void
    {
        self::$stopHit  = false;
        self::$stopLast = 0.0;
        try {
            Store::delete('gen_stop', self::stopKey($chatId, $draftId));
        } catch (Throwable) {
        }
    }

    private function arm(): void
    {
        $this->armed = true;
        $this->t0    = microtime(true);
        $this->shown = 0;
        Http::$tick  = $this->tick(...);
    }

    private function disarm(): void
    {
        if (!$this->armed) {
            return;
        }
        $this->armed = false;
        Http::$tick  = null;
    }

    public function tick(): void
    {
        if (!$this->armed || $this->inTick || $this->mode === 'live') {
            return;
        }
        if ($this->typingOnly) {
            $this->inTick = true;
            try {
                $this->typing();
            } catch (Throwable) {
            } finally {
                $this->inTick = false;
            }
            return;
        }
        if (!$this->draft) {
            $this->typing();
            if ($this->adopted && !$this->quiet && ($this->msg['chat']['type'] ?? '') === 'private' && isset($this->ids[0])) {
                $n = (int) floor(microtime(true) - $this->t0);
                if ($n >= $this->shown + 1) {
                    $this->inTick = true;
                    $this->shown  = $n;
                    try {
                        $r = $this->editMsg($this->ids[0], $this->frame($n));
                        if ((int) ($r['error_code'] ?? 0) === 429) {
                            $this->disarm();
                        }
                    } catch (Throwable) {
                    } finally {
                        $this->inTick = false;
                    }
                }
            }
            return;
        }
        $n    = (int) floor(microtime(true) - $this->t0);
        if ($n < $this->shown + 1) {
            return;
        }
        $this->inTick = true;
        $this->shown  = $n;
        try {
            $html = $this->frame($n);
            $r    = null;
            if ($this->draft) {
                $this->waitDraft($n, $html);
            } elseif ($this->imid !== null) {
                $r = Rich::editInline($this->imid, $html);
            } elseif (isset($this->ids[0])) {
                $r = $this->editMsg($this->ids[0], $html);
            }
            if ((int) ($r['error_code'] ?? 0) === 429) {
                $this->disarm();
            }
        } catch (Throwable) {
        } finally {
            $this->inTick = false;
        }
    }

    public function start(): void
    {
        if (!$this->status || $this->imid !== null || $this->ids !== [] || $this->draft) {
            return;
        }
        if ($this->typingOnly) {
            $this->typing();
            $this->arm();
            return;
        }
        $tg = App::tg();

        if (($this->msg['chat']['type'] ?? '') === 'private') {
            $this->draftId = mt_rand(1, 2147483646);
            $this->sendThinking(0);
            $this->rich  = true;
            $this->draft = true;
            $this->armStop();
            $this->arm();
            return;
        }

        $this->quiet = true;
        $r = $tg->call('sendRichMessage', [
            'chat_id'          => $this->msg['chat']['id'],
            'rich_message'     => ['html' => '<p>' . h($this->frame(0)) . '</p>'],
            'reply_parameters' => ['message_id' => $this->msg['message_id'], 'allow_sending_without_reply' => true],
        ], 10);
        if (empty($r['ok']) || !isset($r['result']['message_id'])) {
            return;
        }
        $this->richMsg = true;
        Rich::mark((int) $this->msg['chat']['id'], (int) $r['result']['message_id']);
        $this->ids[0] = (int) $r['result']['message_id'];
        $this->lastTyping = 0;
        $this->typing();
        $this->arm();
    }

    private function sendThinking(int $n, bool $stoppable = true): bool
    {
        $r = App::tg()->call('sendRichMessageDraft', [
            'chat_id'      => $this->msg['chat']['id'],
            'draft_id'     => $this->draftId,
            'rich_message' => ['html' => L('<tg-thinking>🧠 نالین داره فکر می‌کنه… ', '<tg-thinking>🧠 Nullin is thinking… ') . $n . 's</tg-thinking>'],
        ] + $this->stopOpts($stoppable), 8);
        return !empty($r['ok']);
    }

    private function sendRichText(string $text): bool
    {
        $r = App::tg()->call('sendRichMessageDraft', [
            'chat_id'      => $this->msg['chat']['id'],
            'draft_id'     => $this->draftId,
            'rich_message' => ['markdown' => Rich::markdown($text) . ' ▍'],
        ] + $this->stopOpts(true), 8);
        return !empty($r['ok']);
    }

    private function waitDraft(int $n, string $html, bool $stoppable = true): void
    {
        $this->sendThinking($n, $stoppable);
    }

    private function frame(int $n): string
    {
        return ($this->head !== '' ? $this->head . (Lang::is('en') ? self::WAIT_TEXT_EN : self::WAIT_TEXT) : (Lang::is('en') ? self::THINKING_EN : self::THINKING)) . ($n > 0 ? '… ' . $n . 's' : '');
    }

    private function typing(): void
    {
        if ($this->status && !$this->draft && time() - $this->lastTyping >= 4) {
            $this->lastTyping = time();
            App::tg()->action($this->msg['chat']['id'], 'typing');
        }
    }

    public function feed(string $raw): void
    {
        if ($this->typingOnly || $this->mode === 'silent' || $this->stopped) {
            return;
        }
        $this->typing();
        $body = $this->body($raw, false);
        if ($body === false) {
            $this->mode = 'silent';
            return;
        }
        if ($body === null) {
            return;
        }
        if ($this->hold && $body !== (Lang::is('en') ? self::DRAWING_EN : self::DRAWING)) {
            return;
        }
        if ($this->quiet && $body !== (Lang::is('en') ? self::DRAWING_EN : self::DRAWING)) {
            return;
        }
        $this->mode = 'live';
        $this->disarm();
        $this->show($body);
    }

    public function finish(string $answer): bool
    {
        $this->disarm();
        $this->releaseStop();
        Http::$pulse = null;
        if ($this->typingOnly) {
            return false;
        }
        if ($this->draft) {
            $this->waitDraft(0, $this->frame(0), false);
            $ok = $this->sync($answer, true);
            if ($ok) {
                return true;
            }
            $this->discard();
            return false;
        }
        if ($this->ids === []) {
            return false;
        }
        if ($this->sync($answer, true)) {
            return true;
        }
        $this->discard();
        return false;
    }

    public function finishHtml(string $html): bool
    {
        $this->disarm();
        $this->releaseStop();
        Http::$pulse = null;
        if (!isset($this->ids[0])) {
            return false;
        }
        $r = $this->editMsg($this->ids[0], $html);
        if (!empty($r['ok']) || stripos((string) ($r['description'] ?? ''), 'not modified') !== false) {
            return true;
        }
        $this->discard();
        return false;
    }

    public function draftId(): int
    {
        return $this->draft ? $this->draftId : 0;
    }

    public function ids(): array
    {
        return array_values($this->ids);
    }

    public function active(): bool
    {
        return $this->ids !== [];
    }

    public function discard(): void
    {
        $this->releaseStop();
        if (!$this->draft) {
            $this->disarm();
        }
        foreach ($this->ids as $id) {
            App::tg()->call('deleteMessage', ['chat_id' => $this->msg['chat']['id'], 'message_id' => $id], 8);
        }
        $this->ids     = [];
        $this->sent    = [];
        $this->mode    = 'wait';
        $this->lastLen = 0;
    }

    private function body(string $raw, bool $final)
    {
        $t = preg_replace('#<think>.*?</think>#si', '', $raw) ?? $raw;
        $t = ltrim(preg_replace('#<think>.*$#si', '', $t) ?? $t);
        if ($t === '') {
            return null;
        }

        $nl = strpos($t, "\n");
        if ($this->reaction) {
            if ($nl === false) {
                if (!$final && (preg_match('/^[\s*`«»\[]*reaction(?![A-Za-z])/iu', $t) || AI::isEmojiLine($t))) {
                    return null;
                }
            } else {
                $t = AI::splitReaction($t, true)[1];
                if (!$final && AI::isEmojiLine($t)) {
                    return null;
                }
            }
        }

        $t = ltrim($t);
        if ($t === '') {
            return null;
        }

        if (preg_match('/^\s*\[\[\s*image(?![A-Za-z])/iu', $t)) {
            return (Lang::is('en') ? self::DRAWING_EN : self::DRAWING);
        }
        if (preg_match('/^\s*\[\[\s*(' . implode('|', Intent::NAMES) . ')(?![A-Za-z])/iu', $t)) {
            return false;
        }
        if (!$final && preg_match('/^\s*\[{1,2}\s*[A-Za-z]*$/u', $t)) {
            return null;
        }

        if (preg_match('/^[\s*`«»]*([A-Za-z]+)(.*)$/su', $t, $w)) {
            if (!$final && trim($w[2]) === '') {
                return null;
            }
        }
        return $t;
    }

    private function show(string $body): void
    {
        $chunked = $this->imid === null && $this->head === '';
        $text    = AI::clean($body, $chunked ? PHP_INT_MAX : 4094 - AI::visible($this->head));
        if ($text === '') {
            return;
        }
        $len = mb_strlen($text);
        if ($len === $this->lastLen) {
            return;
        }
        $this->lastLen = $len;

        if ($this->draft) {
            if ($len > 3500) {
                $text = mb_substr($text, -3500);
            }
            if (substr_count($text, '```') % 2 === 1) {
                $text .= "\n```";
            }
            $this->sendRichText($text);
            return;
        }

        if ($chunked) {
            $this->sync($text, false);
            return;
        }

        if (substr_count($text, '```') % 2 === 1) {
            $text .= "\n```";
        }
        $html = $this->head . AI::toHtml($text) . ' ▍';
        $tg   = App::tg();

        if ($this->imid !== null) {
            Rich::editInline($this->imid, $html);
        } elseif (!isset($this->ids[0])) {
            $r = Rich::notice($this->msg, $html);
            if (!empty($r['ok']) && isset($r['result']['message_id'])) {
                $this->ids[0] = (int) $r['result']['message_id'];
            }
        } else {
            $this->editMsg($this->ids[0], $html);
        }
    }

    private function sync(string $text, bool $final): bool
    {
        $tg    = App::tg();
        $parts = AI::chunks($text);
        $last  = count($parts) - 1;

        if ($final && $this->richMsg && isset($this->ids[0])) {
            $mid = (int) $this->ids[0];
            $r   = $tg->call('editMessageText', [
                'chat_id'      => $this->msg['chat']['id'],
                'message_id'   => $mid,
                'rich_message' => ['markdown' => Rich::markdown(substr_count($text, '```') % 2 === 1 ? $text . "\n```" : $text)],
            ], 10);
            if (!empty($r['ok']) || stripos((string) ($r['description'] ?? ''), 'not modified') !== false) {
                Rich::mark((int) $this->msg['chat']['id'], $mid);
                $this->ids  = [0 => $mid];
                $this->sent = [];
                return true;
            }
            return false;
        }

        if ($final && !$this->adopted) {
            $rid = Rich::reply($this->msg, substr_count($text, '```') % 2 === 1 ? $text . "\n```" : $text);
            if ($rid === null) {
                return false;
            }
            foreach ($this->ids as $old) {
                $tg->call('deleteMessage', ['chat_id' => $this->msg['chat']['id'], 'message_id' => $old], 8);
            }
            $this->ids  = [0 => $rid];
            $this->sent = [];
            return true;
        }

        foreach ($parts as $i => $part) {
            if (substr_count($part, '```') % 2 === 1) {
                $part .= "\n```";
            }
            $html = AI::toHtml($part) . ($i === $last && !$final && mb_strlen($part) <= 4094 ? ' ▍' : '');
            if (($this->sent[$i] ?? null) === $html) {
                continue;
            }
            if (!isset($this->ids[$i])) {
                $r = Rich::notice($this->msg, $html);
                if (empty($r['ok']) || !isset($r['result']['message_id'])) {
                    return false;
                }
                $this->ids[$i] = (int) $r['result']['message_id'];
            } else {
                $r = $i === 0 ? $this->editMsg($this->ids[0], $html) : AnswerButtons::editHtmlRich((int) $this->msg['chat']['id'], (int) $this->ids[$i], $html);
                if (empty($r['ok']) && stripos((string) ($r['description'] ?? ''), 'not modified') === false) {
                    return false;
                }
            }
            $this->sent[$i] = $html;
        }
        return true;
    }
}
