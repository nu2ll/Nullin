<?php

final class ConnectFour
{
    private const P    = 'c4';
    private const ROWS = 6;
    private const COLS = 7;
    private const DISC = ['R' => '🔴', 'Y' => '🟡', '' => '⚪'];

    public static function intro(): string
    {
        return L("<b>🔴 دوز سکه‌ای</b>\n\nچهارتا هم‌رنگ پشت سر هم بچین!\n\nحالت بازی رو انتخاب کن:", "<b>🔴 Connect Four</b>\n\nLine up four discs of your color!\n\nPick a game mode:");
    }

    public static function modeKeyboard(): array
    {
        return GameKit::modeKeyboard(self::P);
    }

    private static function drop(array $b, int $col): ?int
    {
        for ($r = self::ROWS - 1; $r >= 0; $r--) {
            if ($b[$r * self::COLS + $col] === '') {
                return $r;
            }
        }
        return null;
    }

    private static function winner(array $b): array
    {
        foreach ([[0, 1], [1, 0], [1, 1], [1, -1]] as [$dr, $dc]) {
            for ($r = 0; $r < self::ROWS; $r++) {
                for ($c = 0; $c < self::COLS; $c++) {
                    $m = $b[$r * self::COLS + $c];
                    if ($m === '') {
                        continue;
                    }
                    $cells = [$r * self::COLS + $c];
                    for ($k = 1; $k < 4; $k++) {
                        $rr = $r + $dr * $k;
                        $cc = $c + $dc * $k;
                        if ($rr < 0 || $rr >= self::ROWS || $cc < 0 || $cc >= self::COLS || $b[$rr * self::COLS + $cc] !== $m) {
                            continue 2;
                        }
                        $cells[] = $rr * self::COLS + $cc;
                    }
                    return [$m, $cells];
                }
            }
        }
        return [in_array('', $b, true) ? null : 'draw', []];
    }

    private static function validCols(array $b): array
    {
        return array_values(array_filter(range(0, self::COLS - 1), static fn($c) => $b[$c] === ''));
    }

    private static function botMove(array $b): int
    {
        $cols = self::validCols($b);
        $try  = static function (array $b, int $c, string $m): array {
            $b[self::drop($b, $c) * self::COLS + $c] = $m;
            return $b;
        };
        foreach ($cols as $c) {
            if (self::winner($try($b, $c, 'Y'))[0] === 'Y') {
                return $c;
            }
        }
        if (random_int(1, 100) <= 50) {
            foreach ($cols as $c) {
                if (self::winner($try($b, $c, 'R'))[0] === 'R') {
                    return $c;
                }
            }
        }
        $safe = array_values(array_filter($cols, static function ($c) use ($b, $try) {
            $after = $try($b, $c, 'Y');
            foreach (self::validCols($after) as $c2) {
                if (self::winner($try($after, $c2, 'R'))[0] === 'R') {
                    return false;
                }
            }
            return true;
        }));
        $pool     = $safe ?: $cols;
        $weighted = [];
        foreach ($pool as $c) {
            $weighted = array_merge($weighted, array_fill(0, 4 - (int) abs($c - 3), $c));
        }
        return $weighted[array_rand($weighted)];
    }

    private static function board(array $b, bool $active, array $s = []): array
    {
        [, $win] = self::winner($b);
        $rows    = [];
        for ($r = 0; $r < self::ROWS; $r++) {
            $row = [];
            for ($c = 0; $c < self::COLS; $c++) {
                $i     = $r * self::COLS + $c;
                $row[] = btn(self::DISC[$b[$i]], $active ? self::P . ":col:{$c}" : 'noop', in_array($i, $win, true) ? 'success' : null);
            }
            $rows[] = $row;
        }
        $rows[] = $active ? GameKit::controlRow($s, self::P) : [btn(L('🔁 بازی دوباره', '🔁 Play again'), self::P . ':replay', 'success')];
        return ikb($rows);
    }

    private static function header(array $s): string
    {
        return '<b>' . L('🔴 دوز سکه‌ای', '🔴 Connect Four') . '</b> · ' . ($s['mode'] === 'bot' ? L('با ربات', 'Vs bot') : L('دو نفره', 'Two players')) . "\n" . divider() . "\n"
            . '🔴 ' . GameKit::name($s['p1']) . '  vs  🟡 ' . GameKit::name($s['p2'] ?? null, L('❔ منتظر حریف', '❔ Waiting for opponent')) . "\n" . divider() . "\n";
    }

    private static function render(string $imid, array $s): void
    {
        $tg = App::tg();
        if ($s['status'] === 'over') {
            [$w] = self::winner($s['board']);
            $end = !empty($s['resigned']) ? GameKit::resignLine($s)
                : ($w === 'draw' ? L('🤝 <b>بازی مساوی شد!</b>', '🤝 <b>It’s a draw!</b>') : '🏆 <b>' . GameKit::name($w === 'R' ? $s['p1'] : $s['p2']) . L(' برد!</b>', ' wins!</b>'));
            Rich::editInline($imid, self::header($s) . $end, self::board($s['board'], false));
            return;
        }
        $turn = $s['turn'] === 'R' ? '🔴 ' . GameKit::name($s['p1']) : '🟡 ' . GameKit::name($s['p2'] ?? null, L('هر کی اول بزنه', 'Whoever taps first'));
        Rich::editInline($imid, self::header($s) . L("👉 نوبت: {$turn}\n<i>روی هر خونه‌ی یه ستون بزنی،\nسکه میفته اون ستون.</i>", "👉 Turn: {$turn}\n<i>Tap any cell in a column\nand the disc drops into that column.</i>") . GameKit::resignNote($s), self::board($s['board'], true, $s));
    }

    public static function onCallback(array $cq, string $data, string $imid): void
    {
        $tg   = App::tg();
        $from = $cq['from'];
        $s    = GameKit::ensure($imid, self::P, $from);

        $handled = GameKit::common($s, $cq, $data, self::P,
            function (string $mode) use (&$s, $imid) {
                $s['mode']   = $mode === 'bot' ? 'bot' : 'pvp';
                $s['status'] = 'playing';
                $s['board']  = array_fill(0, self::ROWS * self::COLS, '');
                $s['turn']   = 'R';
                $s['p2']     = $s['mode'] === 'bot' ? ['id' => 0, 'name' => L('🤖 نالین', '🤖 Nullin')] : null;
                GameKit::save($imid, $s);
                self::render($imid, $s);
            },
            function () use (&$s, $imid, $tg) {
                $s = GameKit::fresh(self::P, $s['p1']);
                GameKit::save($imid, $s);
                Rich::editInline($imid, self::intro(), self::modeKeyboard());
            },
            function (string $by) use (&$s, $imid, $tg) {
                GameKit::save($imid, $s);
                Rich::editInline($imid, self::header($s) . L("✖️ بازی توسط {$by} لغو شد.", "✖️ Game cancelled by {$by}."), self::board($s['board'], false));
            },
            function () use (&$s, $imid) {
                GameKit::save($imid, $s);
                self::render($imid, $s);
            }
        );
        if ($handled) {
            return;
        }

        if (!str_starts_with($data, self::P . ':col:') || ($s['status'] ?? '') !== 'playing') {
            $tg->answer($cq, L('⌛️ این بازی تموم شده', '⌛️ This game is over'));
            return;
        }
        $col = (int) substr($data, strlen(self::P . ':col:'));
        if ($col < 0 || $col >= self::COLS) {
            $tg->answer($cq);
            return;
        }

        $turnSeat = $s['turn'] === 'R' ? 1 : 2;
        if ($s['mode'] === 'bot') {
            if (!GameKit::isCreator($s, (int) $from['id'])) {
                $tg->alert($cq, L('🚫 این بازی مال یکی دیگه‌ست؛' . "\n" . 'خودت از منو یکی بساز!', '🚫 This game belongs to someone else;' . "\n" . 'start your own from the menu!'));
                return;
            }
        } else {
            $seat = GameKit::seat($s, $from, $turnSeat);
            if ($seat === 0) {
                $tg->alert($cq, L('🚫 این بازی دو نفره پر شده.', '🚫 This two-player game is full.'));
                return;
            }
            if ($seat !== $turnSeat) {
                $tg->answer($cq, L('⏳ نوبت تو نیست', '⏳ It’s not your turn'));
                return;
            }
        }

        $row = self::drop($s['board'], $col);
        if ($row === null) {
            $tg->answer($cq, L('🈵 این ستون پره', '🈵 This column is full'));
            return;
        }
        $s['board'][$row * self::COLS + $col] = $s['turn'];
        unset($s['resign_ask']);

        if (self::winner($s['board'])[0] === null) {
            if ($s['mode'] === 'bot') {
                $bc                                      = self::botMove($s['board']);
                $s['board'][self::drop($s['board'], $bc) * self::COLS + $bc] = 'Y';
            } else {
                $s['turn'] = $s['turn'] === 'R' ? 'Y' : 'R';
            }
        }
        if (self::winner($s['board'])[0] !== null) {
            $s['status'] = 'over';
        }
        GameKit::save($imid, $s);
        self::render($imid, $s);
        $tg->answer($cq);
    }
}
