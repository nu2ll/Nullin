<?php

final class AnswerButtons
{
    private const NS        = 'aibtn';
    private const VOICE_MAX = 2500;
    private const L_SEARCH = '🔎';
    private const L_VOICE  = '🔊';
    private const L_RETRY  = '🔄';
    private const L_MENU   = '⚙️';
    private const L_BACK   = '↩️';

    public static function plain(string $answer): string
    {
        return trim((string) preg_replace('/\n\n🔗 (?:منابع|Sources):.*$/su', '', $answer));
    }

    /** @return array{0:string,1:array<int,array{0:string,1:string}>} [answer without its sources block, [label, url] links] */
    public static function splitSources(string $answer): array
    {
        if (!preg_match('/\n\n🔗 (?:منابع|Sources): (.*)$/su', $answer, $m)) {
            return [$answer, []];
        }
        $links = [];
        if (preg_match_all('/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/u', $m[1], $mm, PREG_SET_ORDER)) {
            foreach (array_slice($mm, 0, 5) as $x) {
                $links[] = [mb_substr($x[1], 0, 40), $x[2]];
            }
        }
        return [rtrim((string) preg_replace('/\n\n🔗 (?:منابع|Sources): .*$/su', '', $answer)), $links];
    }

    public static function hasSources(string $answer): bool
    {
        return self::splitSources($answer)[1] !== [];
    }

    /** Source buttons for a classic inline keyboard, merged under an existing keyboard (or alone). */
    public static function withLinks(?array $kb, array $links): ?array
    {
        if (!$links) {
            return $kb;
        }
        $rows = $kb['inline_keyboard'] ?? [];
        foreach (self::linkChunks($links) as $pair) {
            $rows[] = array_map(static fn(array $l): array => ['text' => '🔗 ' . $l[0], 'url' => $l[1], 'src' => 1], $pair);
        }
        return ['inline_keyboard' => $rows];
    }

    /** First source alone in its row, the rest two per row. */
    private static function linkChunks(array $links, int $per = 2): array
    {
        $links = array_values($links);
        return array_merge(array_slice($links, 0, 1) ? [array_slice($links, 0, 1)] : [], array_chunk(array_slice($links, 1), $per));
    }

    public static function sourcesLabel(): string
    {
        return L('🔗 منابع', '🔗 Sources');
    }

    /** The label is drawn by Rich::buttonsHtml as a centered quote block above the source buttons, so the text stays untouched. */
    public static function withLabel(string $text, array $links): string
    {
        return $text;
    }

    private static function linkRows(array $links, bool $voiced = false): string
    {
        if (!$links) {
            return '';
        }
        $out = '<aside>' . h(self::sourcesLabel()) . '</aside>';
        foreach (self::linkChunks($links, $voiced ? 3 : 2) as $pair) {
            $out .= '<tg-button-row align="center">';
            foreach ($pair as $l) {
                $out .= '<tg-button type="url" url="' . h($l[1]) . '">' . h($l[0]) . '</tg-button>';
            }
            $out .= '</tg-button-row>';
        }
        return $out;
    }

    public static function keyboard(bool $searched, bool $voice = true, bool $noSearch = false): array
    {
        $row = [];
        if (!$searched && !$noSearch && WebSearch::available()) {
            $row[] = btn('🔎', 'ab:s', 'primary');
        }
        if ($voice) {
            $row[] = btn('🔊', 'ab:v', 'success');
        }

        return ['inline_keyboard' => $row ? [$row] : []];
    }

    private static function rb(string $label, string $data, string $style): string
    {
        return '<tg-button type="callback_data" style="' . $style . '" data="' . h($data) . '">' . h($label) . '</tg-button>';
    }

    public static function rows(bool $searched, bool $voice = true, bool $noSearch = false): string
    {
        $search = !$searched && !$noSearch && WebSearch::available();
        if ($search && $voice) {
            return '<tg-button-row>' . self::rb(self::L_MENU, 'ab:o', 'primary') . '</tg-button-row>';
        }
        $row = '';
        if ($search) {
            $row .= self::rb(self::L_SEARCH, 'ab:s', 'primary');
        }
        if ($voice) {
            $row .= self::rb(self::L_VOICE, 'ab:v', 'success');
        }
        return $row === '' ? '' : '<tg-button-row>' . $row . '</tg-button-row>';
    }

    public static function rowsOpen(bool $searched, bool $voice = true, bool $noSearch = false): string
    {
        $search = !$searched && !$noSearch && WebSearch::available();
        if (!$search || !$voice) {
            return self::rows($searched, $voice, $noSearch);
        }
        return '<tg-button-row>' . self::rb(self::L_SEARCH, 'ab:s', 'primary') . self::rb(self::L_VOICE, 'ab:v', 'success') . '</tg-button-row>'
            . '<tg-button-row>' . self::rb(self::L_BACK, 'ab:c', 'primary') . '</tg-button-row>';
    }

    public static function retryRows(): string
    {
        return '<tg-button-row>' . self::rb(self::L_RETRY, 'ab:r', 'danger') . '</tg-button-row>';
    }

    private static function body(string $answer, string $rows, bool $voiced = false): string
    {
        [$answer, $links] = self::splitSources($answer);
        $rows              = self::linkRows($links, $voiced) . $rows;
        $answer           = rtrim($answer);
        if (substr_count($answer, '```') % 2 === 1) {
            $answer .= "\n```";
        }
        return Rich::markdown($answer) . ($rows !== '' ? "\n\n" . $rows : '');
    }

    public static function okEditPublic(?array $r): bool
    {
        return self::okEdit($r);
    }

    private static function okEdit(?array $r): bool
    {
        return !empty($r['ok']) || stripos((string) ($r['description'] ?? ''), 'not modified') !== false;
    }

    public static function editRich(int $chatId, int $mid, string $answer, string $rows, bool $voiced = false): bool
    {
        if (trim($answer) === '' || mb_strlen($answer) > 12000) {
            return false;
        }
        return self::okEdit(self::richEdit(App::tg(), $chatId, $mid, $answer, $rows, $voiced));
    }

    private static function richEdit(Telegram $tg, int $chatId, int $mid, string $answer, string $rows, bool $voiced = false): ?array
    {
        return $tg->call('editMessageText', [
            'chat_id'      => $chatId,
            'message_id'   => $mid,
            'rich_message' => ['markdown' => self::body($answer, $rows, $voiced)],
        ], 10);
    }

    public static function editHtmlRich(int $chatId, int $mid, string $html): ?array
    {
        return App::tg()->call('editMessageText', [
            'chat_id'      => $chatId,
            'message_id'   => $mid,
            'rich_message' => ['html' => '<p>' . str_replace("\n", '<br>', $html) . '</p>'],
        ], 10);
    }

    private static function failBody(string $plain): string
    {
        return '<p>' . str_replace("\n", '<br>', h($plain)) . '</p>' . self::retryRows();
    }

    public static function sendFail(array $msg, string $plain, array $rec): void
    {
        $tg     = App::tg();
        $chatId = (int) $msg['chat']['id'];
        $r      = $tg->call('sendRichMessage', [
            'chat_id'          => $chatId,
            'rich_message'     => ['html' => self::failBody($plain)],
            'reply_parameters' => ['message_id' => $msg['message_id'], 'allow_sending_without_reply' => true],
        ]);
        $mid = (int) ($r['result']['message_id'] ?? 0);
        if ($mid > 0) {
            self::attach($chatId, $mid, $rec + ['a' => $plain, 'f' => 1, 'rc' => 1], false);
        }
    }

    public static function failEdit(int $chatId, int $mid, string $plain): void
    {
        $tg   = App::tg();
        $tg->call('editMessageText', [
            'chat_id'      => $chatId,
            'message_id'   => $mid,
            'rich_message' => ['html' => self::failBody($plain)],
        ], 10);
        $key = $chatId . ':' . $mid;
        $rec = Store::get(self::NS, $key);
        if (is_array($rec)) {
            $rec['rc'] = 1;
            Store::set(self::NS, $key, $rec);
        }
    }

    private static function applyKb(int $chatId, int $mid, array $rec, bool $voice): void
    {
        $sr = !empty($rec['sr']);
        $ns = !empty($rec['ns']);
        if (!empty($rec['rc'])) {
            self::editRich($chatId, $mid, (string) $rec['a'], self::rows($sr, $voice, $ns), !$voice);
        }
    }

    public static function retryKeyboard(): array
    {
        return ['inline_keyboard' => [[btn('🔄', 'ab:r', 'danger')]]];
    }

    public static function searchOnly(): ?array
    {
        return WebSearch::available() ? ['inline_keyboard' => [[btn('🔎', 'ab:s', 'primary')]]] : null;
    }

    public static function attachInline(string $imid, array $rec): void
    {
        if ($imid === '' || trim((string) ($rec['a'] ?? '')) === '' || trim((string) ($rec['q'] ?? '')) === '') {
            return;
        }
        $rec['a']  = mb_substr((string) $rec['a'], 0, 12000);
        $rec['q']  = mb_substr((string) $rec['q'], 0, 4000);
        $rec['b']  = App::botIndex();
        $rec['in'] = 1;
        Store::set(self::NS, 'i:' . $imid, $rec);
    }

    public static function attach(int $chatId, int $mid, array $rec, bool $withMarkup = true): void
    {
        if ($mid <= 0 || trim((string) ($rec['a'] ?? '')) === '') {
            return;
        }
        $fits     = mb_strlen((string) $rec['a']) <= 12000;
        $rec['a'] = mb_substr((string) $rec['a'], 0, 12000);
        $rec['q'] = mb_substr((string) ($rec['q'] ?? ''), 0, 4000);
        $rec['b'] = App::botIndex();
        if ($withMarkup) {
            $rows = !empty($rec['f']) ? self::retryRows() : self::rows(!empty($rec['sr']), empty($rec['vo']), !empty($rec['ns']));
            $rich = ($rows !== '' || self::hasSources((string) $rec['a'])) && $fits && empty($rec['k']) && (Rich::was($chatId, $mid) || (int) ($rec['n'] ?? 1) <= 1)
                && self::editRich($chatId, $mid, (string) $rec['a'], $rows, !empty($rec['vo']));
            $rec['rc'] = $rich ? 1 : 0;
            Store::set(self::NS, $chatId . ':' . $mid, $rec);
            return;
        }
        Store::set(self::NS, $chatId . ':' . $mid, $rec);
    }

    public static function sweep(int $budget = 100): int
    {
        $end  = microtime(true) + $budget;
        $done = 0;
        $keys = Db::run('SELECT k FROM kv WHERE ns = ? AND updated_at < ? LIMIT 3000', [self::NS, Store::dayStart()])->fetchAll(PDO::FETCH_COLUMN);
        foreach ($keys as $k) {
            if (microtime(true) > $end) {
                break;
            }
            $rec = Store::get(self::NS, (string) $k);
            $tgx = App::tgFor((int) (is_array($rec) ? ($rec['b'] ?? 0) : 0));
            if (str_starts_with((string) $k, 'i:')) {
                $r = $tgx->call('editMessageReplyMarkup', [
                    'inline_message_id' => substr((string) $k, 2),
                    'reply_markup'      => ['inline_keyboard' => []],
                ], 5);
            } else {
                [$chat, $mid] = array_pad(explode(':', (string) $k, 2), 2, '0');
                if (is_array($rec) && !empty($rec['rc']) && trim((string) ($rec['a'] ?? '')) !== '') {
                    $r = self::richEdit($tgx, (int) $chat, (int) $mid, (string) $rec['a'], '', !empty($rec['vo']));
                } else {
                    $r = $tgx->call('editMessageReplyMarkup', [
                        'chat_id'      => (int) $chat,
                        'message_id'   => (int) $mid,
                        'reply_markup' => ['inline_keyboard' => []],
                    ], 5);
                }
            }
            if ((int) ($r['error_code'] ?? 0) === 429) {
                break;
            }
            Store::delete(self::NS, (string) $k);
            $done++;
            usleep(60000);
        }
        return $done;
    }

    public static function onCallback(array $cq): void
    {
        $tg   = App::tg();
        $imid = (string) ($cq['inline_message_id'] ?? '');
        if ($imid !== '') {
            self::onInline($cq, $imid);
            return;
        }
        $m = $cq['message'] ?? null;
        if (!is_array($m) || !isset($m['chat']['id'], $m['message_id']) || !Switches::on('ai')) {
            $tg->answer($cq);
            return;
        }

        $chatId = (int) $m['chat']['id'];
        $mid    = (int) $m['message_id'];
        $uid    = (int) ($cq['from']['id'] ?? 0);
        $act    = substr((string) ($cq['data'] ?? ''), 3);
        $key    = $chatId . ':' . $mid;
        $rec    = Store::getToday(self::NS, $key);

        $late = $act === 'v' || $act === 's';
        if (!$late) {
            $tg->answer($cq);
        }
        if (!is_array($rec) || trim((string) ($rec['a'] ?? '')) === '') {
            if ($late) {
                $tg->answer($cq);
            }
            $tg->call('editMessageReplyMarkup', ['chat_id' => $chatId, 'message_id' => $mid, 'reply_markup' => ['inline_keyboard' => []]], 8);
            return;
        }

        switch ($act) {
            case 'o':
            case 'c':
                $owner = (int) ($rec['u'] ?? 0);
                if (($owner !== 0 && $owner !== $uid) || !empty($rec['f']) || empty($rec['rc'])) {
                    return;
                }
                $sr = !empty($rec['sr']);
                $vl = empty($rec['vo']);
                $ns = !empty($rec['ns']);
                self::editRich($chatId, $mid, (string) $rec['a'], $act === 'o' ? self::rowsOpen($sr, $vl, $ns) : self::rows($sr, $vl, $ns), !$vl);
                return;

            case 'r':
                $owner = (int) ($rec['u'] ?? 0);
                if (($owner !== 0 && $owner !== $uid) || empty($rec['f']) || !self::lock($key, 'r')) {
                    return;
                }
                try {
                    match ((string) ($rec['k'] ?? '')) {
                        'tr'    => Assistant::retryTranslate($cq, $rec),
                        'img'   => ImageGen::retry($cq, $rec),
                        default => Assistant::retry($cq, $rec),
                    };
                } finally {
                    self::unlock($key, 'r');
                }
                return;

            case 'v':
                $owner = (int) ($rec['u'] ?? 0);
                if (($owner !== 0 && $owner !== $uid) || !empty($rec['vo']) || !self::lock($key, 'v')) {
                    $tg->answer($cq);
                    return;
                }
                $rec['vo'] = 1;
                Store::set(self::NS, $key, $rec);
                self::applyKb($chatId, $mid, $rec, false);
                $voiced = self::voice($chatId, $mid, (string) $rec['a'], $uid);
                if (!$voiced) {
                    $rec['vo'] = 0;
                    Store::set(self::NS, $key, $rec);
                    self::applyKb($chatId, $mid, $rec, true);
                }
                self::unlock($key, 'v');
                $tg->answer($cq, $voiced ? null : L('😕 نتونستم ویس بسازم، یه‌کم دیگه دوباره امتحان کن.', '😕 I couldn\'t make the voice, try again in a bit.'));
                return;

            case 's':
                $owner = (int) ($rec['u'] ?? 0);
                if (($owner !== 0 && $owner !== $uid) || !empty($rec['ns']) || !WebSearch::available() || !empty($rec['sr']) || !self::lock($key, 's')) {
                    $tg->answer($cq);
                    return;
                }
                try {
                    Assistant::searchAgain($cq, $rec);
                } finally {
                    self::unlock($key, 's');
                }
                return;
        }
    }

    private static function onInline(array $cq, string $imid): void
    {
        $tg    = App::tg();
        $key   = 'i:' . $imid;
        $rec   = Store::getToday(self::NS, $key);
        $rm    = static fn() => $tg->call('editMessageReplyMarkup', ['inline_message_id' => $imid, 'reply_markup' => ['inline_keyboard' => []]], 8);
        $data  = (string) ($cq['data'] ?? '');
        $retry = $data === 'ab:r';

        if (!Switches::on('ai') || ($data !== 'ab:s' && !$retry)) {
            $tg->answer($cq);
            return;
        }
        if (!is_array($rec) || trim((string) ($rec['a'] ?? '')) === '' || trim((string) ($rec['q'] ?? '')) === '') {
            $tg->answer($cq);
            $rm();
            return;
        }
        $owner = (int) ($rec['u'] ?? 0);
        $uid   = (int) ($cq['from']['id'] ?? 0);
        $act   = $retry ? 'r' : 's';
        if (($owner !== 0 && $owner !== $uid) || ($retry ? empty($rec['f']) : !WebSearch::available()) || !self::lock($key, $act)) {
            $tg->answer($cq);
            return;
        }

        $kind = (string) ($rec['k'] ?? '');
        if ($retry && $kind === 'img') {
            $tg->answer($cq);
            Store::delete(self::NS, $key);
            try {
                GuestHandler::image($imid, null, (string) $rec['q'], $owner);
            } finally {
                self::unlock($key, $act);
            }
            return;
        }
        if ($retry && $kind === 'tr') {
            $tg->answer($cq);
            $tl = new LiveReply(['chat' => ['id' => 0, 'type' => 'inline'], 'message_id' => 0], $imid, '', false);
            $tl->watch(true);
            try {
                $out = AI::translateFast((string) $rec['q'], (string) ($rec['t'] ?? 'auto'));
            } finally {
                $tl->stop();
            }
            if ($out !== null && $out !== '') {
                Store::delete(self::NS, $key);
                Rich::editInline($imid, (string) ($rec['h'] ?? '') . h($out));
            } else {
                Rich::editInline($imid, (string) ($rec['x'] ?? '') . AI::toHtml((Lang::is('en') ? AI::FAIL_TEXT_EN : AI::FAIL_TEXT)), self::retryKeyboard());
            }
            self::unlock($key, $act);
            return;
        }

        $head = (string) ($rec['h'] ?? '');
        $live = null;
        if ($retry) {
            $tg->answer($cq);
            $live = new LiveReply(['chat' => ['id' => 0, 'type' => 'inline'], 'message_id' => 0], $imid, $head, false);
            $live->watch(true);
        } else {
            $rm();
        }
        $done = false;
        try {
            $ctx = ['user_name' => userName($cq['from'] ?? []), 'user_id' => (int) ($cq['from']['id'] ?? 0), 'chat_type' => 'guest'];
            if ($retry) {
                $q   = (string) $rec['q'];
                $opt = ['max_len' => PHP_INT_MAX, 'reaction' => false] + ($live && App::cfg('ai_stream', true) ? ['on_text' => $live->feed(...)] : []);
            } else {
                $q   = (string) $rec['q'] . "\n\n[System instruction: this time, before answering, you must search the web with the web_search tool and base your answer on up-to-date results.]";
                $opt = ['max_len' => PHP_INT_MAX, 'reaction' => false, 'force_search' => true];
            }
            $res = AI::reply($q, $ctx, [], $opt);
            if (!empty($res['action'])) {
                $res = AI::reply($q, ['no_action' => true] + $ctx, [], $opt);
            }
            $live?->stop();
            $searched = AI::$searched;
            $answer   = !empty($res['image']) || !empty($res['image_partial']) ? null : ($res['answer'] ?? null);
            if ($answer === null) {
                return;
            }
            [$shown, $links] = self::splitSources($answer);
            $kb   = self::withLinks($searched ? null : self::searchOnly(), $links);
            $text = $head . AI::toHtml(AI::fit(self::withLabel($shown, $links), $head));
            $r    = Rich::editInline($imid, $text, $kb);
            if (empty($r['ok']) && stripos((string) ($r['description'] ?? ''), 'not modified') === false) {
                $r = Rich::editInline($imid, mb_substr(strip_tags($text), 0, 4096), $kb, null, false);
            }
            if (empty($r['ok']) && stripos((string) ($r['description'] ?? ''), 'not modified') === false) {
                return;
            }
            $done = true;
            if ($searched) {
                Store::delete(self::NS, $key);
            } else {
                $rec['a'] = $answer;
                unset($rec['f']);
                Store::set(self::NS, $key, $rec);
            }
        } finally {
            $live?->stop();
            if ($retry) {
                if (!$done) {
                    Rich::editInline($imid, $head . AI::toHtml((Lang::is('en') ? AI::FAIL_TEXT_EN : AI::FAIL_TEXT)), self::retryKeyboard());
                }
            } else {
                $tg->answer($cq, $done ? null : (Lang::is('en') ? AI::FAIL_TEXT_EN : AI::FAIL_TEXT));
                if (!$done) {
                    $tg->call('editMessageReplyMarkup', ['inline_message_id' => $imid, 'reply_markup' => self::searchOnly() ?? ['inline_keyboard' => []]], 8);
                }
            }
            self::unlock($key, $act);
        }
    }

    private static function voice(int $chatId, int $mid, string $answer, int $uid = 0): bool
    {
        $tg = App::tg();
        $tg->action($chatId, 'record_voice');
        $file = AI::speak(mb_substr(self::plain($answer), 0, self::VOICE_MAX), null, 'ogg', VoicePick::get($uid));
        if ($file === null) {
            return false;
        }
        $r = $tg->call('sendVoice', [
            'chat_id'          => $chatId,
            'voice'            => new CURLFile($file, 'audio/ogg', 'voice.ogg'),
            'reply_parameters' => ['message_id' => $mid, 'allow_sending_without_reply' => true],
        ], 120);
        AI::markMsg($chatId, $r['result']['message_id'] ?? 0);
        @unlink($file);
        return !empty($r['ok']);
    }

    private static function lock(string $key, string $act): bool
    {
        return Store::update('rl', "abl_{$act}_" . md5($key), static fn($at) => (is_int($at) && time() - $at < 120) ? null : time()) !== null;
    }

    private static function unlock(string $key, string $act): void
    {
        Store::delete('rl', "abl_{$act}_" . md5($key));
    }
}
