<?php

final class InlineHandler
{
    private const ROUTES = [
        'ai'      => ['ai', 'nullini', 'nullin', 'هوش', 'نالینی', 'نالین'],
        'tr'      => ['tr', 'tarjome', 'translate', 'ترجمه'],
        'whisper' => ['nj', 'najva', 'نجوا'],
        'weather' => ['hv', 'havaye', 'hava', 'weather', 'آب و هوای', 'آب و هوا', 'آب‌وهوای', 'آب‌وهوا', 'هوای', 'هوا'],
        'nid'     => ['codemeli', 'codmeli', 'meli', 'کدملی', 'کد‌ملی'],
        'funstat' => ['id', 'آیدی'],
        'love'    => ['love', 'عشق'],
        'roast'   => ['roast', 'روست', 'بشور'],
        'qr'      => ['qr', 'کیوآر'],
        'short'   => ['sh'],
        'search'  => ['g', 'google', 'search', 'گوگل', 'سرچ', 'جستجو'],
        'font'    => ['ft', 'font', 'fonts', 'فونت'],
        'wiki'    => ['wk', 'wiki', 'ویکی‌پدیا', 'ویکیپدیا', 'ویکی'],
        'gif'     => ['gif', 'گیف'],
        'gw'      => ['gw', 'giveaway', 'قرعه‌کشی', 'قرعه کشی', 'قرعه'],
        'linkcheck' => ['st'],
        'like'    => ['like', 'لایک'],
        'date'    => ['date'],
    ];

    private static array $iq = [];

    private static function send(array $params): void
    {
        App::tg()->call('answerInlineQuery', $params);
    }

    public static function handle(array $iq): void
    {
        self::$iq = $iq;
        $from     = $iq['from'];
        $query    = trim((string) ($iq['query'] ?? ''));

        Users::touch($from);
        if (Membership::missing((int) $from['id'])) {
            self::send([
                'inline_query_id' => $iq['id'],
                'results'         => [],
                'cache_time'      => 0,
                'is_personal'     => true,
                'button'          => ['text' => L('🔒 اول عضو کانال/گروه نالین شو', '🔒 First join the Nullin channel/group'), 'start_parameter' => 'join'],
            ]);
            return;
        }

        foreach (self::ROUTES as $route => $words) {
            foreach ($words as $w) {
                if (preg_match('/^' . preg_quote($w, '/') . '(?:\s+|$)(.*)$/isu', $query, $m)) {
                    $rest = trim($m[1]);
                    $sw   = ['tr' => 'translate', 'gw' => 'giveaway'][$route] ?? $route;
                    if (!Switches::on($sw)) {
                        self::answer([], 0);
                        return;
                    }
                    match ($route) {
                        'ai'      => self::ai($rest),
                        'tr'      => self::translate($rest),
                        'whisper' => self::whisper($rest),
                        'weather' => self::weather($rest),
                        'nid'     => self::nid($rest),
                        'funstat' => self::funstat($rest),
                        'love'    => self::love($rest),
                        'roast'   => self::roast($rest),
                        'qr'      => self::qr($rest),
                        'short'   => self::short($rest),
                        'search'  => self::search($rest),
                        'font'    => self::font($rest),
                        'gw'      => self::giveaway($rest),
                        'wiki'    => self::wiki($rest),
                        'gif'     => self::gif($rest),
                        'linkcheck' => self::linkcheck($rest),
                        'like'    => self::like($rest),
                        'date'    => self::date($rest),
                    };
                    return;
                }
            }
        }

        if (Switches::on('rates') && ($pm = PriceCard::match($query, true, true)) !== null) {
            self::price($pm);
            return;
        }
        if (Switches::on('calc') && Calculator::looksLikeExpression($query)) {
            self::quickCalc($query);
            return;
        }
        self::menu($query);
    }

    private static function answer(array $results, int $cache = 0, bool $personal = true, string $next = ''): void
    {
        self::send([
            'inline_query_id' => self::$iq['id'],
            'results'         => $results,
            'cache_time'      => $cache,
            'is_personal'     => $personal,
        ] + ($next !== '' ? ['next_offset' => $next] : []));
    }

    private static function price(array $m): void
    {
        $a = PriceCard::inlineArticle($m);
        if ($a === null) {
            self::fail('pc_fail', L('⚠️ قیمت‌ها در دسترس نیست', '⚠️ Prices are unavailable'), L('چند لحظه‌ی دیگه دوباره امتحان کن', 'Try again in a moment'), L("⚠️ الان به منبع قیمت‌ها دسترسی ندارم؛\nچند لحظه دیگه دوباره بزن.", "⚠️ I can't reach the price source right now;\ntry again in a moment."));
            return;
        }
        self::answer([$a], 20, false);
    }

    private static function guide(string $key, string $icon, string $title, string $desc): void
    {
        self::answer([Ui::article("help_{$key}", $icon, $title, $desc, Ui::guide($key), Ui::tryKeyboard($key))]);
    }

    private static function fail(string $id, string $title, string $desc, string $text): void
    {
        self::answer([Ui::article($id, 'warn', $title, $desc, $text)]);
    }

    private static function deferred(string $kind, string $q): void
    {
        self::answer([self::deferredArticle($kind, $q)]);
    }

    private static function deferredArticle(string $kind, string $q): array
    {
        $token = substr(md5($kind . $q . self::$iq['from']['id'] . microtime()), 0, 12);
        Store::set('inline_ai', $token, ['kind' => $kind, 'q' => mb_substr($q, 0, 256), 'name' => userName(self::$iq['from']), 'from' => self::$iq['from']]);

        $isAi  = $kind === 'ai';
        $head  = $isAi ? '❓ <b>' . h(mb_substr($q, 0, 256)) . '</b>' : '📝 ' . h(mb_substr($q, 0, 256));
        $wait  = $isAi ? L('🧠 نالین داره فکر می‌کنه...', '🧠 Nullin is thinking...') : L('🌐 در حال ترجمه...', '🌐 Translating...');
        return Ui::article(
            "{$kind}q_{$token}",
            $isAi ? 'ai' : 'translate',
            $isAi ? L('🧠 بپرس از نالین', '🧠 Ask Nullin') : L('🌐 ترجمه کن', '🌐 Translate'),
            mb_substr($q, 0, 80),
            "{$head}\n\n⏳ {$wait}",
            ikb([[btn(L('⏳ صبر کن...', '⏳ Wait...'), "{$kind}q:{$token}", null)]])
        );
    }

    private static function wiki(string $q): void
    {
        if ($q === '') {
            self::guide('wiki', 'wiki', L('📖 ویکی‌پدیا', '📖 Wikipedia'), L('بعد از wk موضوعت رو بنویس', 'Type your topic after wk'));
            return;
        }
        $list = Wiki::search($q, 8);
        if (!$list && Wiki::lang($q) === 'fa') {
            $list = Wiki::search($q, 6, 'en');
        }
        if (!$list) {
            self::fail('wk_none', L('📖 چیزی پیدا نشد', '📖 Nothing found'), L('یه جور دیگه بنویس', 'Try wording it differently'), L('📖 تو ویکی‌پدیا چیزی درباره‌ی «', '📖 I found nothing on Wikipedia about “') . h(mb_substr($q, 0, 80)) . L('» پیدا نکردم.', '”.'));
            return;
        }
        self::answer(array_map(static fn($p) => Wiki::inline('wk_' . substr(md5($p['url']), 0, 16), $p), $list), 600, false);
    }

    private static function gif(string $q): void
    {
        if (!Gif::enabled()) {
            self::fail('gif_off', L('🎞 گیف فعال نیست', '🎞 GIF isn’t set up'), L('کلید گیفی هنوز تنظیم نشده', 'The Giphy key isn’t configured yet'), L('🎞 گیف‌ها هنوز راه‌اندازی نشدن.', '🎞 GIFs aren’t set up yet.'));
            return;
        }
        $offset = max(0, (int) (self::$iq['offset'] ?? 0));
        $page   = Gif::inline($q, $offset);
        if ($page === null) {
            self::fail('gif_err', L('😕 گیفی در دسترس نیست', '😕 GIFs are unavailable'), L('چند لحظه‌ی دیگه دوباره امتحان کن', 'Try again in a moment'), L('😕 الان به سرویس گیف دسترسی ندارم؛ چند لحظه‌ی دیگه دوباره امتحان کن.', '😕 I can’t reach the GIF service right now; try again in a moment.'));
            return;
        }
        if (!$page['results']) {
            if ($offset === 0) {
                self::fail('gif_none', L('🎞 گیفی پیدا نشد', '🎞 No GIFs found'), L('یه جور دیگه بنویس', 'Try wording it differently'), L('🎞 برای «', '🎞 I couldn’t find a GIF for “') . h(mb_substr($q, 0, 60)) . L('» گیفی پیدا نکردم.', '”.'));
                return;
            }
            self::answer([], 0);
            return;
        }
        self::answer($page['results'], 300, false, $page['next']);
    }

    private static function like(string $text): void
    {
        if ($text === '') {
            self::guide('like', 'like', L('❤️ لایک‌ساز', '❤️ Like maker'), L('بعد از like متنت رو بنویس', 'Type your text after like'));
            return;
        }
        self::answer([Likes::article($text)], 0);
    }

    private static function giveaway(string $q): void
    {
        $r = $q === '' ? null : Giveaway::inlineResult(self::$iq['from'], $q);
        if ($r === null) {
            self::guide('giveaway', 'gift', L('🎁 قرعه‌کشی', '🎁 Giveaway'), L('gw [تعداد برنده] [زمان] [جایزه]', 'gw [winners] [time] [prize]'));
            return;
        }
        self::answer([$r]);
    }

    private static ?array $failKb = null;

    public static function resolveDeferred(string $token, string $imid): void
    {
        $job = Store::update('inline_ai', $token, static fn($j) => (is_array($j) && empty($j['done'])) ? ['done' => true] + $j : null);
        if ($job === null) {
            return;
        }
        $tg = App::tg();
        if ($job['kind'] === 'ai' && AI::busy((int) ($job['from']['id'] ?? 0))) {
            Rich::editInlineRich($imid, (Lang::is('en') ? AI::BUSY_TEXT_EN : AI::BUSY_TEXT));
            return;
        }
        if ($job['kind'] === 'ai' && AI::limited((int) ($job['from']['id'] ?? 0))) {
            Rich::editInlineRich($imid, AI::limitText());
            return;
        }
        if ($job['kind'] === 'ai' && is_array($job['from'] ?? null) && self::smart((string) $job['q'], (array) $job['from'], $imid)) {
            return;
        }
        self::$failKb = null;
        $text = self::deferredText((string) $job['kind'], (string) $job['q'], (string) ($job['name'] ?? ''), $imid, (int) ($job['from']['id'] ?? 0));
        if (empty(Rich::editInline($imid, $text, self::$failKb)['ok'])) {
            Rich::editInline($imid, strip_tags($text), self::$failKb, null, false);
        }
    }

    private static function smart(string $q, array $from, string $imid): bool
    {
        if (($link = Downloader::match($q)) !== null) {
            Downloader::guest($from, $link, $imid);
            return true;
        }
        $ctx  = ['user_name' => userName($from), 'user_id' => (int) ($from['id'] ?? 0), 'chat_type' => 'guest'];
        $live = App::cfg('ai_stream', true) ? new LiveReply(['chat' => ['id' => 0, 'type' => 'inline'], 'message_id' => 0], $imid, self::aiHead($q), false) : null;
        $live?->watch();
        $opt  = ['reaction' => false] + ($live ? ['on_text' => $live->feed(...)] : []);
        $res  = AI::reply($q, $ctx, [], $opt);
        $live?->stop();
        if (!empty($res['action'])) {
            [$act, $arg] = $res['action'];
            Users::hit('intent:' . $act);
            if ($act === 'download' && ($dl = Downloader::find($arg)) !== null) {
                Downloader::guest($from, $dl, $imid);
                return true;
            }
            $o = Intent::output(['from' => $from, 'chat' => ['type' => 'inline'], 'message_id' => 0], $act, $arg, true, $imid);
            if ($o !== null) {
                GuestHandler::show($imid, '', $o);
                return true;
            }
            $res = AI::reply($q, ['no_action' => true] + $ctx, [], $opt);
        }
        if (!empty($res['image'])) {
            GuestHandler::image($imid, null, (string) $res['image'], (int) ($from['id'] ?? 0));
            return true;
        }
        if ($res['answer'] === null) {
            return false;
        }
        $text = self::aiHead($q) . AI::toHtml(AI::fit($res['answer'], self::aiHead($q)));
        $kb   = AI::$searched ? null : AnswerButtons::searchOnly();
        if (empty(Rich::editInline($imid, $text, $kb)['ok'])) {
            Rich::editInline($imid, strip_tags($text), $kb, null, false);
        }
        if ($kb !== null) {
            AnswerButtons::attachInline($imid, ['u' => (int) ($from['id'] ?? 0), 'q' => $q, 'a' => $res['answer'], 'h' => self::aiHead($q)]);
        }
        return true;
    }

    private static function aiHead(string $q): string
    {
        return '❓ <b>' . h(mb_substr($q, 0, 256)) . "</b>\n\n🧠 ";
    }

    private static function deferredText(string $kind, string $q, string $name, string $imid, int $uid = 0): string
    {
        if ($kind === 'ai') {
            $live   = App::cfg('ai_stream', true) ? new LiveReply(['chat' => ['id' => 0, 'type' => 'inline'], 'message_id' => 0], $imid, self::aiHead($q), false) : null;
            $live?->watch();
            $res    = AI::reply($q, ['user_name' => $name, 'user_id' => $uid, 'chat_type' => 'inline'], [], ['reaction' => false] + ($live ? ['on_text' => $live->feed(...)] : []));
            $live?->stop();
            $answer = $res['answer'] ?? (Lang::is('en') ? AI::FAIL_TEXT_EN : AI::FAIL_TEXT);
            if ($res['answer'] === null) {
                self::$failKb = AnswerButtons::retryKeyboard();
                AnswerButtons::attachInline($imid, ['u' => $uid, 'q' => $q, 'a' => $answer, 'h' => self::aiHead($q), 'f' => 1]);
            }
            $text   = self::aiHead($q) . AI::toHtml(AI::fit($answer, self::aiHead($q)));
        } else {
            $out  = AI::translateFast($q);
            $pre  = h(mb_substr($q, 0, 256)) . "\n\n🌐 ";
            $text = $pre . ($out !== null ? h($out) : (Lang::is('en') ? AI::FAIL_TEXT_EN : AI::FAIL_TEXT));
            if ($out === null) {
                self::$failKb = AnswerButtons::retryKeyboard();
                AnswerButtons::attachInline($imid, ['k' => 'tr', 'u' => $uid, 'q' => $q, 'a' => (Lang::is('en') ? AI::FAIL_TEXT_EN : AI::FAIL_TEXT), 'h' => $pre, 'x' => $pre, 'f' => 1]);
            }
        }
        return $text;
    }

    private static function ai(string $q): void
    {
        if ($q === '') {
            self::guide('ai', 'ai', L('🧠 هوش مصنوعی', '🧠 AI'), L('بعد از ai سؤالت رو بنویس', 'Type your question after ai'));
            return;
        }
        self::deferred('ai', $q);
    }

    private static function translate(string $q): void
    {
        if ($q === '') {
            self::guide('translate', 'translate', L('🌐 ترجمه', '🌐 Translate'), L('بعد از tr متنت رو بنویس', 'Type your text after tr'));
            return;
        }
        self::deferred('tr', $q);
    }

    private static function whisper(string $rest): void
    {
        $p    = Whisper::parse($rest);
        $text = $p['text'];
        $len  = mb_strlen($text);
        if ($len > Whisper::MAX_LEN) {
            self::fail('wh_long', L('✋ متن نجوا طولانیه', '✋ The whisper text is too long'), L('حداکثر ', 'Max ') . fa(Whisper::MAX_LEN) . L(' کاراکتر (الان ', ' characters (now ') . fa($len) . ')',
                L('✋ متن نجوا حداکثر <b>', '✋ A whisper can be at most <b>') . fa(Whisper::MAX_LEN) . L('</b> کاراکتر می‌تونه باشه؛', '</b> characters;\n') . "\n" . L('یه‌کم کوتاهش کن.', 'shorten it a bit.'));
            return;
        }
        $from = self::$iq['from'];
        if ($p['to'] !== []) {
            $tokens = array_slice(array_values(array_unique($p['to'])), 0, 10);
            Whisper::prefetch($tokens);
            $to = [];
            foreach ($tokens as $t) {
                $r = UserInfo::resolve($t);
                if (empty($r['id']) || !in_array((int) $r['id'], array_map(static fn($x) => (int) ($x['id'] ?? 0), $to), true)) {
                    $to[] = $r;
                }
            }
            foreach (array_slice($to, 0, 3) as $r) {
                if (!empty($r['id']) && Whisper::avatarUrl((int) $r['id']) === null) {
                    Whisper::refreshAvatar((int) $r['id']);
                }
            }
            $token = $text === '' ? null : Whisper::draft($from, $text, [$to]);
            self::answer([self::whisperItem($text, $to, $token, 0, count($tokens) === 1 ? $tokens[0] : null, $len)]);
            return;
        }
        $uid  = (int) $from['id'];
        $raw  = (string) (self::$iq['query'] ?? '');
        $bare = $rest === '' && preg_match('/\s$/u', $raw) !== 1;
        $results = [self::whisperGuide($bare, $len)];
        if ($bare) {
            $results[] = Whisper::requestArticle($from);
            self::answer($results);
            return;
        }
        $g      = Whisper::group($uid);
        $opts   = [];
        foreach (array_slice(Whisper::recent($uid), 0, $g !== [] ? 48 : 49) as $r) {
            $opts[] = [$r];
        }
        if ($g !== []) {
            $opts[] = $g;
        }
        $token = $text === '' || $opts === [] ? null : Whisper::draft($from, $text, $opts);
        foreach ($opts as $i => $to) {
            $results[] = self::whisperItem($text, $to, $token, $i);
        }
        self::answer($results);
    }

    private static function whisperGuide(bool $bare, int $len): array
    {
        $desc = L('nj [متن] [@یوزرنیم] [آیدی]', 'nj [text] [@username] [ID]');
        if (!$bare) {
            $desc .= "\n" . fa($len) . L(' از ', ' from ') . fa(Whisper::MAX_LEN);
        }
        return Ui::article('help_whisper', 'chat', L('🤫 نجوا', '🤫 Whisper'), $desc, Ui::guide('whisper'), Ui::tryKeyboard('whisper'));
    }

    private static function whisperItem(string $text, array $to, ?string $token, int $idx, ?string $rawTo = null, ?int $len = null): array
    {
        $names = array_map(static fn($r) => ($r['name'] ?? '') !== '' ? $r['name'] : '@' . ($r['username'] ?? ''), $to);
        $multi = count($to) > 1;
        $title = $multi ? L('نجوای چندنفره (', 'Group whisper (') . fa(count($to)) . L(' نفر)', ' people)') : $names[0];
        $desc  = $multi ? L("👥 نجوای چندنفره\n", "👥 Group whisper\n") . mb_substr(implode(' & ', $names), 0, 80) : L('💬 نجوا', '💬 Whisper');
        if ($rawTo !== null && !$multi) {
            $isUser = str_starts_with($rawTo, '@');
            $title  = $isUser ? L('نجوا به ', 'Whisper to ') . $rawTo : L('نجوا به (👤کاربر)', 'Whisper to (👤user)');
            $desc   = '💬 ' . ($isUser ? L('نجوا با آیدی', 'Whisper by ID') : L('نجوا با آیدی‌عددی', 'Whisper by numeric ID')) . ' ✅';
            if ($len !== null) {
                $desc .= "\n" . fa($len) . L(' از ', ' from ') . fa(Whisper::MAX_LEN);
            }
        }
        $icon  = $multi ? 'group' : ((($av = Whisper::avatarUrl((int) ($to[0]['id'] ?? 0))) !== null) ? $av : 'info');
        if ($text === '' || $token === null) {
            return Ui::article('whe_' . substr(md5(json_encode($to)), 0, 16), $icon, $title, $desc, Whisper::emptyText(), Whisper::emptyKeyboard());
        }
        $ref = $token . '_' . $idx;
        return Ui::article(
            "wh_{$ref}",
            $icon,
            $title,
            $desc,
            Whisper::pendingText(['recipients' => $to]),
            Whisper::pendingKeyboard($ref, $multi)
        );
    }

    private static function date(string $place): void
    {
        if (mb_strlen($place) > 40) {
            self::fail('dt_len', L('⚠️ اسم مکان نامعتبره', '⚠️ Invalid place name'), L('حداکثر ۴۰ کاراکتر', 'At most 40 characters'), L('⚠️ اسم مکان باید حداکثر ۴۰ کاراکتر باشه.', '⚠️ The place name must be at most 40 characters.'));
            return;
        }
        $r = Clock::resolve($place);
        if ($r === null) {
            self::fail('dt_fail', L('❌ پیدا نشد: ', '❌ Not found: ') . $place, L('اسم شهر یا کشور رو دقیق‌تر بنویس', 'Write the city or country more precisely'), Clock::text($place));
            return;
        }
        $title = L('📅 تاریخ و ساعت', '📅 Date & time') . ($place !== '' ? ' · ' . $r[1] : '');
        self::answer([Ui::article('date_' . substr(md5($r[0] . Lang::get() . (Lang::code() ?? '')), 0, 10), 'date', $title, Clock::clock(time(), $r[0], false) . ' · ' . $r[0], Clock::text($place))], 0, true);
    }

    private static function weather(string $city): void
    {
        if ($city === '') {
            self::guide('weather', 'weather', L('🌦 آب‌وهوا', '🌦 Weather'), L('بعد از hv اسم شهر رو بنویس', 'Type a city name after hv'));
            return;
        }
        $len = mb_strlen($city);
        if ($len < 2 || $len > 40) {
            self::fail('wt_len', L('⚠️ اسم شهر نامعتبره', '⚠️ Invalid city name'), L('بین ۲ تا ۴۰ کاراکتر بنویس', 'Write between 2 and 40 characters'), L('⚠️ اسم مکان باید بین ۲ تا ۴۰ کاراکتر باشه.', '⚠️ The place name must be between 2 and 40 characters.'));
            return;
        }
        $data = Weather::fetch($city);
        if ($data === null) {
            self::fail('wt_fail', L('❌ پیدا نشد: ', '❌ Not found: ') . $city, L('اسم شهر رو دقیق‌تر بنویس', 'Write the city name more precisely'), L("❌ جایی به اسم «", "❌ I couldn't find a place named “") . h($city) . L("» پیدا نکردم.\n💡 اسم شهر رو دقیق‌تر بنویس.", "”.\n💡 Write the city name more precisely."));
            return;
        }
        $hash = substr(md5(mb_strtolower($city)), 0, 16);
        Store::set('weather_pending', $hash, $city);
        $loc = $data['location'];
        $kb      = Weather::keyboard($hash);
        $article = Ui::article(
            "wt_{$hash}",
            'weather',
            '🌦 ' . $loc['name'] . ' · ' . round((float) $data['current']['temp_c']) . '°',
            ($data['current']['condition']['text'] ?? '') . ' · ' . ($loc['country'] ?? ''),
            Weather::format($data),
            $kb
        );
        if (Rich::usable($kb)) {
            $article['input_message_content'] = Rich::inlineContentMd(Weather::richFormat($data), $kb);
        }
        self::answer([$article], 60, false);
    }

    private static function nid(string $raw): void
    {
        if ($raw === '') {
            self::guide('nid', 'nid', L('🪪 کد ملی', '🪪 National ID'), L('بعد از meli کد ملی رو بنویس', 'Type the national ID after meli'));
            return;
        }
        $code = Tools::normalizeNid($raw);
        if ($code === null) {
            self::fail('nid_bad', L('⚠️ فرمت کد ملی اشتباهه', '⚠️ Wrong national ID format'), L('باید ۸ تا ۱۰ رقم باشه', 'It must be 8 to 10 digits'), L('⚠️ کد ملی باید فقط عدد و ۸ تا ۱۰ رقم باشه.', '⚠️ The national ID must be digits only, 8 to 10 digits.'));
            return;
        }
        $ok = Tools::isValidNid($code);
        self::answer([Ui::article("nid_{$code}", $ok ? 'ok' : 'fail', $ok ? L('✅ کد ملی سالمه', '✅ National ID is valid') : L('❌ کد ملی نامعتبره', '❌ National ID is invalid'), Tools::nidDisplay($code), Tools::nidText($code))], 300, false);
    }

    private static function linkcheck(string $rest): void
    {
        $url = LinkCheck::extract($rest);
        if ($url === null) {
            self::guide('linkcheck', 'linkcheck', L('🛡 ردیاب اشتراک', '🛡 Invite link tracker'), L('بعد از st لینک اشتراک رو بنویس', 'Type the invite link after st'));
            return;
        }
        $p = LinkCheck::pending(self::$iq['from'], $url);
        self::answer([Ui::article('st_' . $p['token'], 'linkcheck', L('🛡 ردیابی این لینک', '🛡 Trace this link'), mb_substr($url, 0, 80), $p['text'], $p['kb'])]);
    }

    private static function funstat(string $raw): void
    {
        $raw = en($raw);
        if ($raw === '' || !ctype_digit($raw) || strlen($raw) > 15) {
            self::guide('funstat', 'funstat', L('🔍 استعلام کاربر', '🔍 User lookup'), L('بعد از id آیدی عددی رو بنویس', 'Type the numeric ID after id'));
            return;
        }
        $data = UserInfo::funstat((int) $raw);
        if ($data === null) {
            self::fail('fs_fail', L('❌ کاربری پیدا نشد', '❌ User not found'), L('آیدی ', 'ID ') . $raw, L("❌ اطلاعاتی برای آیدی <code>{$raw}</code> پیدا نشد.", "❌ No information found for ID <code>{$raw}</code>."));
            return;
        }
        self::answer([Ui::article("fs_{$raw}", 'funstat', '🔍 ' . UserInfo::funstatShort($data), L('آیدی ', 'ID ') . $raw, UserInfo::funstatText($data))], 60, false);
    }

    private static function love(string $rest): void
    {
        $parts = $rest === '' ? [] : preg_split('/\s+/u', $rest);
        $tok   = '/^(@[A-Za-z0-9_]{3,32}|\d{5,15})$/';
        if (count($parts) !== 2 || !preg_match($tok, $parts[0]) || !preg_match($tok, $parts[1])) {
            self::guide('love', 'love', L('💘 تطابق عشقی', '💘 Love match'), L('love [یوزرنیم/آیدی] [یوزرنیم/آیدی۲]', 'love [username/ID] [username/ID 2]'));
            return;
        }
        $r = Love::pending($parts[0], $parts[1]);
        self::answer([Ui::article(
            'lv_' . $r['token'],
            'love',
            L("💘 {$r['a']} و {$r['b']}", "💘 {$r['a']} and {$r['b']}"),
            L('❤️ بزن تا درصد عشقشون رو ببینی', '❤️ Tap to see their love percentage'),
            $r['text'],
            $r['keyboard']
        )]);
    }

    private static function roast(string $rest): void
    {
        $tok = Roast::token($rest);
        if ($rest !== '' && $tok === '') {
            self::guide('roast', 'roast', L('🔥 روست', '🔥 Roast'), L('roast [@یوزرنیم] [آیدی]', 'roast [@username] [ID]'));
            return;
        }
        $r = Roast::pending(self::$iq['from'], $tok === 'me' ? '' : $tok);
        self::answer([Ui::article('rs_' . $r['token'], 'roast', $r['title'], L('🔥 بزن تا بشورمش', '🔥 Tap to roast them'), $r['text'], $r['kb'])]);
    }

    private static function qr(string $text): void
    {
        if ($text === '') {
            self::guide('qr', 'qr', L('🔳 QR کد', '🔳 QR code'), L('بعد از qr متن یا لینک رو بنویس', 'Type text or a link after qr'));
            return;
        }
        $text = mb_substr($text, 0, 1000);
        self::answer([[
            'type'          => 'photo',
            'id'            => 'qr_' . substr(md5($text), 0, 16),
            'photo_url'     => Tools::qrUrl($text, 512),
            'thumbnail_url' => Tools::qrUrl($text, 128),
            'photo_width'   => 512,
            'photo_height'  => 512,
            'title'         => L('🔳 QR کد', '🔳 QR code'),
            'description'   => mb_substr($text, 0, 60),
            'caption'       => '🔳 <code>' . h(mb_substr($text, 0, 1000)) . '</code>',
            'parse_mode'    => 'HTML',
        ]], 300, false);
    }

    private static function short(string $rest): void
    {
        $url = ShortLink::extract($rest);
        if ($url === null) {
            self::guide('short', 'short', L('🔗 کوتاه‌کننده لینک', '🔗 Link shortener'), L('بعد از sh لینک بلند رو بنویس', 'Type the long link after sh'));
            return;
        }
        $short = ShortLink::shorten($url);
        if ($short === null) {
            self::fail('sh_fail', L('❌ کوتاه نشد', '❌ Couldn\'t shorten'), L('چند لحظه‌ی دیگه دوباره امتحان کن', 'Try again in a moment'), L('❌ الان نتونستم این لینک رو کوتاه کنم. چند لحظه‌ی دیگه دوباره امتحان کن.', '❌ I couldn\'t shorten this link right now. Try again in a moment.'));
            return;
        }
        self::answer([Ui::article('sh_' . substr(md5($url), 0, 16), 'short', '🔗 ' . $short, mb_substr($url, 0, 80), ShortLink::text($short, $url), ShortLink::keyboard($short))], 0);
    }

    private static function search(string $q): void
    {
        if ($q === '') {
            self::guide('search', 'search', L('🔍 سرچ گوگل', '🔍 Google search'), L('بعد از g هر چی می‌خوای بنویس', 'Type whatever you want after g'));
            return;
        }
        $q     = mb_substr($q, 0, 200);
        $items = [Ui::article(
            'gs_' . substr(md5($q), 0, 16),
            'search',
            L('🔍 سرچ گوگل: ', '🔍 Google search: ') . $q,
            L('دکمه‌ها مستقیم به گوگل وصل می‌شن', 'The buttons link directly to Google'),
            "🔍 <b>" . h($q) . L("</b>\n\n👇 نتایج رو همین‌جا تو تلگرام ببین", "</b>\n\n👇 See the results right here in Telegram"),
            Search::keyboard($q)
        )];
        foreach (Search::results($q, 10) as $i => $r) {
            $a                  = Ui::article('sr_' . substr(md5($r['url']), 0, 16), 'search', $r['title'], $r['snippet'] !== '' ? $r['snippet'] : $r['url'], Search::resultText($r), ikb([[urlBtn(L('🌐 باز کردن', '🌐 Open'), $r['url'], null)]]));
            $a['thumbnail_url'] = Search::favicon($r['url']);
            $a['url']           = $r['url'];
            $a['hide_url']      = true;
            $items[]            = $a;
        }
        $params = [
            'inline_query_id' => self::$iq['id'],
            'results'         => $items,
            'cache_time'      => 300,
            'is_personal'     => false,
        ];
        self::send($params);
    }

    private static function font(string $text): void
    {
        if ($text === '') {
            self::guide('font', 'font', L('✨ فونت‌ساز', '✨ Font maker'), L('بعد از ft اسم یا متنت رو بنویس', 'Type your name or text after ft'));
            return;
        }
        $items = [];
        foreach (array_slice(Fonts::all($text), 0, 50) as [$name, $styled]) {
            $items[] = Ui::article(
                'ft_' . substr(md5($styled), 0, 20),
                'font',
                mb_substr($styled, 0, 120),
                $name,
                h($styled),
                ikb([[['text' => L('📋 کپی', '📋 Copy'), 'copy_text' => ['text' => mb_substr($styled, 0, 256)]]]])
            );
        }
        if (!$items) {
            self::guide('font', 'font', L('✨ فونت‌ساز', '✨ Font maker'), L('بعد از ft اسم یا متنت رو بنویس', 'Type your name or text after ft'));
            return;
        }
        self::answer($items, 300, false);
    }

    private static function quickCalc(string $query): void
    {
        $expr   = Calculator::normalize($query);
        $result = Calculator::evaluate($expr);
        if ($result === Calculator::ERROR) {
            self::menu($query);
            return;
        }
        $pretty = strtr($expr, ['*' => '×', '/' => '÷']);
        self::answer([Ui::article(
            'qc_' . substr(md5($expr), 0, 16),
            'calc',
            "🧮 = {$result}",
            $pretty,
            "🧮 <code>" . h($pretty) . "</code>\n= <b>" . h($result) . '</b>'
        )], 300, false);
    }

    private static function menu(string $filter): void
    {
        $from = self::$iq['from'];
        [$infoText, $infoKb] = UserInfo::card($from, self::$iq['chat_type'] ?? null);

        $items = [
            Ui::article('info', 'info', L('👤 اطلاعات من', '👤 My info'), L('آیدی، عمر اکانت، DC و...', 'ID, account age, DC and more...'), $infoText, $infoKb),
            Ui::article('chess', 'chess', L('♟️ شطرنج', '♟️ Chess'), L('با ربات در ۳ سطح سختی، یا با دوستت', 'Against the bot on 3 difficulty levels, or with a friend'), Chess::intro(), Chess::modeKeyboard()),
            Ui::article('calc', 'calc', L('🧮 ماشین‌حساب', '🧮 Calculator'), L('با پرانتز و توان', 'With parentheses and powers'), Calculator::render('0'), Calculator::keyboard()),
            Ui::article('rates', 'rates', L('💱 نرخ ارز و طلا', '💱 Currency & gold rates'), L('دلار، یورو، سکه، تتر، بیت‌کوین...', 'Dollar, euro, coins, Tether, Bitcoin...'), L("<b>💱 نرخ لحظه‌ای بازار</b>\n\nبرای دیدن قیمت‌ها دکمه‌ی زیر رو بزن 👇", "<b>💱 Live market rates</b>\n\nTap the button below to see the prices 👇"), Currency::pendingKeyboard()),
            Ui::article('unit', 'unit', L('⚖️ تبدیل واحد', '⚖️ Unit converter'), L('طول، وزن، دما، حجم، سرعت و...', 'Length, weight, temperature, volume, speed and more...'), UnitConvert::render(UnitConvert::initial()), UnitConvert::keyboard(UnitConvert::initial())),
            Ui::article('date', 'date', L('📅 تاریخ و ساعت', '📅 Date & time'), L('date [شهر] — مثلاً date tehran', 'date [city], e.g. date tehran'), Ui::guide('date'), Ui::tryKeyboard('date')),
            Ui::article('pass', 'pass', L('🔑 پسورد ساز', '🔑 Password maker'), L('یه رمز قوی و غیرقابل حدس', 'A strong, unguessable password'), Tools::passwordText(16), Tools::passwordKeyboard()),
            Ui::article('ttt', 'ttt', L('⭕ دوز', '⭕ Tic-tac-toe'), L('دوز کلاسیک، با ربات یا دوستت', 'Classic tic-tac-toe, against the bot or a friend'), TicTacToe::intro(), TicTacToe::modeKeyboard()),
            Ui::article('c4', 'c4', L('🔴 دوز سکه‌ای', '🔴 Connect Four'), L('۴ تا پشت سر هم، با ربات یا دوستت', '4 in a row, against the bot or a friend'), ConnectFour::intro(), ConnectFour::modeKeyboard()),
            Ui::article('rps', 'rps', L('✊ سنگ کاغذ قیچی', '✊ Rock paper scissors'), L('بهترین از ۳ دور', 'Best of 3 rounds'), Rps::intro(), Rps::modeKeyboard()),
            Ui::article('math', 'math', L('🔢 دوئل ریاضی', '🔢 Math duel'), L('مسابقه‌ی سرعت حساب، چندنفره', 'A math speed contest, multiplayer'), MathDuel::intro(), MathDuel::modeKeyboard()),
            Ui::article('coin', 'coin', L('🪙 سکه', '🪙 Coin'), L('شیر یا خط؟', 'Heads or tails?'), L("<b>🪙 سکه</b>\n\nآماده‌ی پرتاب! 👇", "<b>🪙 Coin</b>\n\nReady to flip! 👇"), Tools::coinKeyboard()),
            Ui::article('fal', 'fal', L('🔮 فال حافظ', '🔮 Hafez fortune'), L('یه فال از دیوان حافظ', 'A fortune from the Divan of Hafez'), Tools::hafezCaption(), Tools::hafezKeyboard()),
            Ui::article('help_group', 'group', L('👥 در گروه', '👥 In groups'), L('نالین رو به گروهت اضافه کن', 'Add Nullin to your group'), Ui::guide('group'), Ui::tryKeyboard('group')),
            Ui::article('help_image', 'image', L('🎨 ساخت عکس', '🎨 Create image'), L('فقط بگو چی بکشم؛ تو پیوی یا گروه', 'Just say what to draw; in private or group'), Ui::guide('image'), Ui::tryKeyboard('image')),
            Ui::article('help_whisper', 'whisper', L('🤫 نجوا', '🤫 Whisper'), L('nj [متن] [@یوزرنیم] [آیدی]', 'nj [text] [@username] [ID]'), Ui::guide('whisper'), Ui::tryKeyboard('whisper')),
            Ui::article('help_like', 'like', L('❤️ لایک‌ساز', '❤️ Like maker'), L('like [متن]', 'like [text]'), Ui::guide('like'), Ui::tryKeyboard('like')),
            Ui::article('help_giveaway', 'gift', L('🎁 قرعه‌کشی', '🎁 Giveaway'), L('gw [تعداد] [زمان] [جایزه]', 'gw [count] [time] [prize]'), Ui::guide('giveaway'), Ui::tryKeyboard('giveaway')),
            Ui::article('help_wiki', 'wiki', L('📖 ویکی‌پدیا', '📖 Wikipedia'), L('wk [موضوع]', 'wk [topic]'), Ui::guide('wiki'), Ui::tryKeyboard('wiki')),
            Ui::article('help_gif', 'gif', L('🎞 گیف', '🎞 GIF'), L('gif [هر چی بخوای]', 'gif [anything you want]'), Ui::guide('gif'), Ui::tryKeyboard('gif')),
            Ui::article('help_ai', 'ai', L('🧠 هوش مصنوعی', '🧠 AI'), L('ai [سؤالت]', 'ai [your question]'), Ui::guide('ai'), Ui::tryKeyboard('ai')),
            Ui::article('help_translate', 'translate', L('🌐 ترجمه', '🌐 Translate'), L('tr [متن]', 'tr [text]'), Ui::guide('translate'), Ui::tryKeyboard('translate')),
            Ui::article('help_search', 'search', L('🔍 سرچ گوگل', '🔍 Google search'), L('g [هر چی بخوای]', 'g [anything you want]'), Ui::guide('search'), Ui::tryKeyboard('search')),
            Ui::article('help_font', 'font', L('✨ فونت‌ساز', '✨ Font maker'), L('ft [اسم یا متن]', 'ft [name or text]'), Ui::guide('font'), Ui::tryKeyboard('font')),
            Ui::article('help_weather', 'weather', L('🌦 آب‌وهوا', '🌦 Weather'), L('hv [شهر]', 'hv [city]'), Ui::guide('weather'), Ui::tryKeyboard('weather')),
            Ui::article('help_qr', 'qr', L('🔳 QR کد', '🔳 QR code'), L('qr [متن یا لینک]', 'qr [text or link]'), Ui::guide('qr'), Ui::tryKeyboard('qr')),
            Ui::article('help_short', 'short', L('🔗 کوتاه‌کننده لینک', '🔗 Link shortener'), L('sh [لینک بلند]', 'sh [long link]'), Ui::guide('short'), Ui::tryKeyboard('short')),
            Ui::article('help_roast', 'roast', L('🔥 روست', '🔥 Roast'), L('roast [@یوزرنیم] [آیدی]', 'roast [@username] [ID]'), Ui::guide('roast'), Ui::tryKeyboard('roast')),
            Ui::article('help_love', 'love', L('💘 تطابق عشقی', '💘 Love match'), L('love [یوزرنیم/آیدی] [یوزرنیم/آیدی۲]', 'love [username/ID] [username/ID 2]'), Ui::guide('love'), Ui::tryKeyboard('love')),
            Ui::article('help_nid', 'nid', L('🪪 کد ملی', '🪪 National ID'), L('meli [کد ملی]', 'meli [national ID]'), Ui::guide('nid'), Ui::tryKeyboard('nid')),
            Ui::article('help_linkcheck', 'linkcheck', L('🛡 ردیاب اشتراک', '🛡 Invite link tracker'), L('st [لینک اشتراک]', 'st [invite link]'), Ui::guide('linkcheck'), Ui::tryKeyboard('linkcheck')),
            Ui::article('help_funstat', 'funstat', L('🔍 استعلام کاربر', '🔍 User lookup'), L('id [آیدی عددی]', 'id [numeric ID]'), Ui::guide('funstat'), Ui::tryKeyboard('funstat')),
        ];

        $swMap = ['info' => 'userinfo', 'chess' => 'chess', 'ttt' => 'ttt', 'c4' => 'c4', 'rps' => 'rps', 'math' => 'math', 'calc' => 'calc', 'unit' => 'unit', 'rates' => 'rates', 'date' => 'date', 'pass' => 'password', 'coin' => 'coin', 'fal' => 'fal',
            'help_image' => 'image', 'help_whisper' => 'whisper', 'help_giveaway' => 'giveaway', 'help_like' => 'like', 'help_wiki' => 'wiki', 'help_gif' => 'gif', 'help_ai' => 'ai', 'help_translate' => 'translate', 'help_search' => 'search',
            'help_font' => 'font', 'help_weather' => 'weather', 'help_qr' => 'qr', 'help_short' => 'short', 'help_roast' => 'roast', 'help_love' => 'love', 'help_nid' => 'nid', 'help_funstat' => 'funstat', 'help_linkcheck' => 'linkcheck'];
        $items = array_values(array_filter($items, static fn($r) => !isset($swMap[$r['id']]) || Switches::on($swMap[$r['id']])));

        if ($filter !== '') {
            $hits = array_values(array_filter($items, static fn($r) => mb_stripos($r['title'] . ' ' . $r['description'], $filter) !== false));
            if ($hits) {
                $items = $hits;
            }
            if (mb_strlen($filter) >= 2 && Switches::on('ai')) {
                array_unshift($items, self::deferredArticle('ai', $filter));
            }
        }

        self::send([
            'inline_query_id' => self::$iq['id'],
            'results'         => $items,
            'cache_time'      => 0,
            'is_personal'     => true,
        ]);
    }
}
