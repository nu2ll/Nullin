<?php

final class Kernel
{
    private const DAILY = ['whisper_pending', 'gw_draft', 'gw_wiz', 'like_txt'];

    private const TTL = [
        'games'           => 7 * 86400,
        'calc'            => 7 * 86400,
        'unit'            => 7 * 86400,
        'owner'           => 14 * 86400,
        'weather'         => 14 * 86400,
        'weather_pending' => 2 * 86400,
        'ai_memory'       => 2 * 86400,
        'cache'           => 3 * 86400,
        'join'            => 86400,
        'inline_ai'       => 86400,
        'dl'              => 2 * 86400,
        'rl'              => 3600,
        'spam'            => 3600,
        'tban'            => 2 * 3600,
        'dl_busy'         => 86400,
        'dl_quota'        => 2 * 86400,
        'dl_files'        => 30 * 86400,
        'love'            => 86400,
        'roast'           => 3600,
        'uname'           => 30 * 86400,
        'gw'              => 120 * 86400,
        'biz_msgs'        => 3 * 86400,
        'biz_hist'        => 2 * 86400,
        'biz_pause'       => 30 * 86400,
        'biz_wait'        => 86400,
        'tidy'            => 2 * 86400,
        'bc_last'         => 2 * 86400,
    ];

    public static function handle(array $update): void
    {
        App::useBot((int) ($update['_bot'] ?? 0));
        try {
            if (Ban::block($update)) {
                return;
            }
            if (isset($update['message'])) {
                MessageHandler::handle($update['message']);
            } elseif (isset($update['inline_query'])) {
                InlineHandler::handle($update['inline_query']);
            } elseif (isset($update['chosen_inline_result'])) {
                ChosenHandler::handle($update['chosen_inline_result']);
            } elseif (isset($update['callback_query'])) {
                CallbackHandler::handle($update['callback_query']);
            } elseif (isset($update['guest_message'])) {
                GuestHandler::handle($update['guest_message']);
            } elseif (isset($update['my_chat_member'])) {
                MessageHandler::onMyChatMember($update['my_chat_member']);
            } elseif (isset($update['business_connection'])) {
                Business::onConnection($update['business_connection']);
            } elseif (isset($update['business_message'])) {
                Business::onMessage($update['business_message']);
            } elseif (isset($update['edited_business_message'])) {
                Business::onEdited($update['edited_business_message']);
            } elseif (isset($update['deleted_business_messages'])) {
                Business::onDeleted($update['deleted_business_messages']);
            }
        } catch (\Throwable $e) {
            logError('update', '#' . ($update['update_id'] ?? '?') . ' ' . $e->getMessage() . ' @ ' . basename($e->getFile()) . ':' . $e->getLine());
            if (isset($update['callback_query']['id'])) {
                App::tg()->answer($update['callback_query'], '😕 یه مشکلی پیش اومد، دوباره امتحان کن.');
            }
        }
    }

    public static function tick(): void
    {
        try {
            MathDuel::tick();
            static $swept = 0;
            if (time() - $swept >= 5) {
                $swept = time();
                Cookies::sweep();
                Broadcast::sweep();
            }
        } catch (\Throwable $e) {
            logError('tick', $e->getMessage());
        }
        App::useBot(0);
    }

    public static function dailyCleanup(): void
    {
        try {
            $removed = Store::cleanupDaily(self::DAILY) + AnswerButtons::sweep(120);
        } catch (\Throwable $e) {
            logError('daily', $e->getMessage());
            return;
        }
        if ($removed > 0) {
            logInfo('daily', "removed {$removed} drafts");
        }
    }

    public static function janitor(): void
    {
        try {
            $removed = Store::cleanup(self::TTL) + Store::cleanupDaily(self::DAILY);
            Users::cleanupStats();
            Giveaway::janitor();
            $removed += AnswerButtons::sweep(600);
        } catch (\Throwable $e) {
            logError('janitor', $e->getMessage());
            return;
        }
        if ($removed > 0) {
            logInfo('janitor', "removed {$removed} old records");
        }
        $log = NULLINI_DATA . '/error.log';
        if (is_file($log) && filesize($log) > 5 * 1024 * 1024) {
            @rename($log, $log . '.old');
        }
    }
}
