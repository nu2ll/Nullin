<?php

final class LiveReply
{
    public const DRAWING = '🎨 دارم می‌کشمش، چند لحظه صبر کن...';

    private const STEPS = ['session initialized', 'context loaded', 'runtime prepared', 'processing request'];
    private const STEP_DELAY_US = 300000;

    private array $ids    = [];
    private array $sent   = [];
    private string $mode  = 'wait';
    private int $lastLen  = 0;
    private int $lastTyping = 0;
    private bool $draft   = false;
    private int $draftId  = 0;

    public function __construct(private array $msg, private ?string $imid = null, private string $head = '', private bool $reaction = true, private bool $status = false)
    {
    }

    public function start(): void
    {
        if (!$this->status || $this->imid !== null || $this->ids !== [] || $this->draft) {
            return;
        }
        $tg = App::tg();
        $cid = $this->msg['chat']['id'];

        if (($this->msg['chat']['type'] ?? '') === 'private') {
            $this->draftId = mt_rand(1, 2147483646);
            if ($this->sendDraft(self::frame(1))) {
                $this->draft = true;
                for ($i = 2; $i <= count(self::STEPS); $i++) {
                    usleep(self::STEP_DELAY_US);
                    $this->sendDraft(self::frame($i));
                }
                return;
            }
        }

        $this->typing();
        $r = $tg->reply($this->msg, self::frame(1));
        if (empty($r['ok']) || !isset($r['result']['message_id'])) {
            return;
        }
        $this->ids[0] = (int) $r['result']['message_id'];
        for ($i = 2; $i <= count(self::STEPS); $i++) {
            usleep(self::STEP_DELAY_US);
            $this->typing();
            $tg->editMessage($cid, $this->ids[0], self::frame($i));
        }
    }

    private function sendDraft(string $html): bool
    {
        $r = App::tg()->call('sendMessageDraft', [
            'chat_id'    => $this->msg['chat']['id'],
            'draft_id'   => $this->draftId,
            'text'       => $html,
            'parse_mode' => 'HTML',
        ], 8);
        return !empty($r['ok']);
    }

    private static function frame(int $n): string
    {
        $lines = [];
        foreach (self::STEPS as $i => $label) {
            if ($i + 1 > $n) {
                break;
            }
            $lines[] = '<code>' . $label . ' ' . ($i + 1 < $n ? '[+]' : '[>]') . '</code>';
        }
        return '⚡ <b>در حال پردازش...</b>' . "\n" . implode("\n", $lines);
    }

    private function typing(): void
    {
        if ($this->status && !$this->draft && time() - $this->lastTyping >= 4) {
            $this->lastTyping = time();
            App::tg()->action($this->msg['chat']['id'], 'typing');
        }
    }

    public function feed(string $raw): void
    {
        if ($this->mode === 'silent') {
            return;
        }
        $this->typing();
        $body = $this->body($raw, false);
        if ($body === false) {
            $this->mode = 'silent';
            return;
        }
        if ($body === null) {
            return;
        }
        $this->mode = 'live';
        $this->show($body);
    }

    public function finish(string $answer): bool
    {
        if ($this->draft) {
            if ($this->sync($answer, true)) {
                return true;
            }
            $this->discard();
            return false;
        }
        if ($this->ids === []) {
            return false;
        }
        if ($this->sync($answer, true)) {
            return true;
        }
        $this->discard();
        return false;
    }

    public function finishHtml(string $html): bool
    {
        if (!isset($this->ids[0])) {
            return false;
        }
        $r = App::tg()->editMessage($this->msg['chat']['id'], $this->ids[0], $html);
        if (!empty($r['ok']) || stripos((string) ($r['description'] ?? ''), 'not modified') !== false) {
            return true;
        }
        $this->discard();
        return false;
    }

    public function ids(): array
    {
        return array_values($this->ids);
    }

    public function active(): bool
    {
        return $this->ids !== [];
    }

    public function discard(): void
    {
        foreach ($this->ids as $id) {
            App::tg()->call('deleteMessage', ['chat_id' => $this->msg['chat']['id'], 'message_id' => $id], 8);
        }
        $this->ids     = [];
        $this->sent    = [];
        $this->mode    = 'wait';
        $this->lastLen = 0;
    }

    private function body(string $raw, bool $final)
    {
        $t = preg_replace('#<think>.*?</think>#si', '', $raw) ?? $raw;
        $t = ltrim(preg_replace('#<think>.*$#si', '', $t) ?? $t);
        if ($t === '') {
            return null;
        }

        $nl = strpos($t, "\n");
        if ($this->reaction) {
            if ($nl === false) {
                if (!$final && (preg_match('/^[\s*`«»\[]*reaction(?![A-Za-z])/iu', $t) || AI::isEmojiLine($t))) {
                    return null;
                }
            } else {
                $t = AI::splitReaction($t, true)[1];
                if (!$final && AI::isEmojiLine($t)) {
                    return null;
                }
            }
        }

        $t = ltrim($t);
        if ($t === '') {
            return null;
        }

        if (preg_match('/^\s*\[\[\s*image(?![A-Za-z])/iu', $t)) {
            return self::DRAWING;
        }
        if (preg_match('/^\s*\[\[\s*(' . implode('|', Intent::NAMES) . ')(?![A-Za-z])/iu', $t)) {
            return false;
        }
        if (!$final && preg_match('/^\s*\[{1,2}\s*[A-Za-z]*$/u', $t)) {
            return null;
        }

        if (preg_match('/^[\s*`«»]*([A-Za-z]+)(.*)$/su', $t, $w)) {
            if (!$final && trim($w[2]) === '') {
                return null;
            }
        }
        return $t;
    }

    private function show(string $body): void
    {
        $chunked = $this->imid === null && $this->head === '';
        $text    = AI::clean($body, $chunked ? PHP_INT_MAX : 4094 - AI::visible($this->head));
        if ($text === '') {
            return;
        }
        $len = mb_strlen($text);
        if ($len === $this->lastLen) {
            return;
        }
        $this->lastLen = $len;

        if ($this->draft) {
            if ($len > 3500) {
                $text = mb_substr($text, -3500);
            }
            if (substr_count($text, '```') % 2 === 1) {
                $text .= "\n```";
            }
            $this->sendDraft(AI::toHtml($text) . ' ▍');
            return;
        }

        if ($chunked) {
            $this->sync($text, false);
            return;
        }

        if (substr_count($text, '```') % 2 === 1) {
            $text .= "\n```";
        }
        $html = $this->head . AI::toHtml($text) . ' ▍';
        $tg   = App::tg();

        if ($this->imid !== null) {
            $tg->editInline($this->imid, $html);
        } elseif (!isset($this->ids[0])) {
            $r = $tg->reply($this->msg, $html);
            if (!empty($r['ok']) && isset($r['result']['message_id'])) {
                $this->ids[0] = (int) $r['result']['message_id'];
            }
        } else {
            $tg->editMessage($this->msg['chat']['id'], $this->ids[0], $html);
        }
    }

    private function sync(string $text, bool $final): bool
    {
        $tg    = App::tg();
        $parts = AI::chunks($text);
        $last  = count($parts) - 1;

        foreach ($parts as $i => $part) {
            if (substr_count($part, '```') % 2 === 1) {
                $part .= "\n```";
            }
            $html = AI::toHtml($part) . ($i === $last && !$final && mb_strlen($part) <= 4094 ? ' ▍' : '');
            if (($this->sent[$i] ?? null) === $html) {
                continue;
            }
            if (!isset($this->ids[$i])) {
                $r = $tg->reply($this->msg, $html);
                if (empty($r['ok']) || !isset($r['result']['message_id'])) {
                    return false;
                }
                $this->ids[$i] = (int) $r['result']['message_id'];
            } else {
                $r = $tg->editMessage($this->msg['chat']['id'], $this->ids[$i], $html);
                if (empty($r['ok']) && stripos((string) ($r['description'] ?? ''), 'not modified') === false) {
                    return false;
                }
            }
            $this->sent[$i] = $html;
        }
        return true;
    }
}
