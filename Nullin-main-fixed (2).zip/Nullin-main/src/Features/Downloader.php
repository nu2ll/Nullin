<?php

final class Downloader
{
    public const BOT_API_BYTES = 50 * 1024 * 1024;
    private const DAILY    = 20;
    private const SLOTS    = 2;
    private const TMP      = '/tmp/nullini-dl';
    private const ALBUM_MAX = 20;
    private const SET_MAX  = 100;
    private const GROUP_MAX = 10;
    private const AUTO_DELAY = 30;
    private const MULTI    = ['instagram', 'pinterest', 'twitter', 'tiktok', 'reddit', 'facebook', 'snapchat'];

    public static function genericError(): string
    {
        return L("❌ نتونستم دانلودش کنم 😕\nاین لینک پشتیبانی نمی‌شه یا مشکلی داره.", "❌ Couldn’t download it 😕\nThis link isn’t supported or has a problem.");
    }

    private const SITES = [
        'youtube'     => ['یوتیوب', '/(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com)$/', true, 'YouTube'],
        'instagram'   => ['اینستاگرام', '/(^|\.)(instagram\.com|instagr\.am)$/', true, 'Instagram'],
        'tiktok'      => ['تیک‌تاک', '/(^|\.)tiktok\.com$/', true, 'TikTok'],
        'twitter'     => ['توییتر', '/(^|\.)(twitter\.com|x\.com)$/', true, 'Twitter'],
        'soundcloud'  => ['ساندکلاد', '/(^|\.)(soundcloud\.com|snd\.sc)$/', false, 'SoundCloud'],
        'pinterest'   => ['پینترست', '/(^|\.)(pinterest\.[a-z.]+|pin\.it)$/', true, 'Pinterest'],
        'reddit'      => ['ردیت', '/(^|\.)(reddit\.com|redd\.it)$/', true, 'Reddit'],
        'facebook'    => ['فیسبوک', '/(^|\.)(facebook\.com|fb\.watch)$/', true, 'Facebook'],
        'snapchat'    => ['اسنپ‌چت', '/(^|\.)snapchat\.com$/', true, 'Snapchat'],
        'spotify'     => ['اسپاتیفای', '/(^|\.)(open\.spotify\.com|spotify\.link|spotify\.app\.link)$/', false, 'Spotify'],
    ];

    public static $resolver = null;

    private static function platformShort(string $site, string $rawHost, string $url): bool
    {
        $h    = preg_replace('/^(www|m|mobile)\./', '', $rawHost) ?? $rawHost;
        $path = (string) parse_url($url, PHP_URL_PATH);
        return match ($site) {
            'pinterest'  => $h === 'pin.it',
            'tiktok'     => str_starts_with($h, 'vm.') || str_starts_with($h, 'vt.') || preg_match('#^/t/\w+#', $path) === 1,
            'soundcloud' => $h === 'snd.sc' || $h === 'on.soundcloud.com',
            'reddit'     => $h === 'redd.it' || preg_match('#^/(?:r/[\w-]+/)?s/\w+#', $path) === 1,
            'facebook'   => $h === 'fb.watch' || preg_match('#^/share/#', $path) === 1,
            'instagram'  => preg_match('#^/share/#', $path) === 1,
            'spotify'    => $h === 'spotify.link' || $h === 'spotify.app.link',
            'snapchat'   => $h === 't.snapchat.com' || preg_match('#^/t/[\w-]+#', $path) === 1,
            default      => false,
        };
    }

    private static function isShortUrl(string $url): bool
    {
        $raw  = strtolower((string) parse_url($url, PHP_URL_HOST));
        $host = preg_replace('/^(www|m|mobile|vm|vt|music)\./', '', $raw) ?? $raw;
        foreach (self::SITES as $key => [$name, $re]) {
            if (preg_match($re, $host)) {
                return self::platformShort($key, $raw, $url);
            }
        }
        return false;
    }

    public static function resolveShort(string $url): ?string
    {
        static $cache = [];
        if (array_key_exists($url, $cache)) {
            return $cache[$url];
        }
        if (is_callable(self::$resolver)) {
            return $cache[$url] = (self::$resolver)($url);
        }
        $final = null;
        $cur   = $url;
        for ($i = 0; $i < 4; $i++) {
            $r   = Http::request('GET', $cur, ['follow' => false, 'max_bytes' => 2048, 'headers' => ['Accept: text/html,*/*']]);
            $loc = (string) ($r['redirect'] ?? '');
            if ($r['code'] < 300 || $r['code'] >= 400 || $loc === '') {
                break;
            }
            if (!preg_match('#^https?://#i', $loc)) {
                $b   = parse_url($cur);
                $loc = ($b['scheme'] ?? 'https') . '://' . ($b['host'] ?? '') . ($loc[0] === '/' ? '' : '/') . $loc;
            }
            if (!self::isShortUrl($loc)) {
                $final = $loc;
                break;
            }
            $cur = $loc;
        }
        return $cache[$url] = $final;
    }

    public static function mtproto(): bool
    {
        static $on = null;
        return $on ??= (self::apiId() > 0 && self::apiHash() !== '' && is_file(NULLINI_ROOT . '/bin/mtup.py'));
    }

    private static function apiId(): int
    {
        return (int) (env('API_ID') ?: env('TG_API_ID', 0));
    }

    private static function apiHash(): string
    {
        return trim((string) (env('API_HASH') ?: env('TG_API_HASH', '')));
    }

    public static function maxBytes(): int
    {
        return self::mtproto() ? max(50, min(2000, (int) env('DL_MAX_MB', 2000))) * 1048576 : self::BOT_API_BYTES;
    }

    public static function limitText(): string
    {
        $b = self::maxBytes();
        return $b >= 1073741824 ? fa((string) round($b / 1073741824, 1)) . L(' گیگ', ' GB') : fa((string) round($b / 1048576)) . L(' مگ', ' MB');
    }

    private static function jobTime(): int
    {
        return self::mtproto() ? 5100 : 1500;
    }

    private static function options(string $site, array $info, bool $hasVideo, int $max): array
    {
        if (!$hasVideo) {
            return [['mp3', L('🎵 دانلود آهنگ', '🎵 Download song')]];
        }
        $have = [];
        foreach ((array) ($info['formats'] ?? []) as $f) {
            if (self::kind((array) $f) !== 'v') {
                continue;
            }
            $std = self::stdOf((array) $f, $info);
            if ($std > 0) {
                $have[$std] = true;
            }
        }
        krsort($have);
        $opts = [];
        $prev = 0;
        foreach (array_keys($have) as $h) {
            $b = self::estimate($info, $h);
            if ($b > $max) {
                continue;
            }
            if ($b > 0 && $prev > 0 && $b > $prev) {
                $b = $prev;
            }
            if ($b > 0) {
                $prev = $b;
            }
            $name   = [2160 => '4K', 1440 => '2K'][$h] ?? fa($h) . 'p';
            $opts[] = ['v' . $h, '🎬 ' . $name . self::sizeHint($info, $h, $b)];
        }
        if (!$opts) {
            $opts[] = ['hd', L('🎬 دانلود ویدیو', '🎬 Download video')];
        }
        $opts[] = ['mp3', L('🎵 فقط صدا (MP3)', '🎵 Audio only (MP3)') . self::mp3Hint($info)];
        return $opts;
    }

    public static function isIgStory(string $text): bool
    {
        return preg_match('#(?:instagram\.com|instagr\.am)/stories/#i', $text) === 1;
    }

    public static function match(string $text, int $depth = 0): ?array
    {
        $text = mbTrim($text);
        if (self::isIgStory($text)) {
            return null;
        }
        if ($text === '' || mb_strlen($text) > 600) {
            return null;
        }
        if (!preg_match('/^((?:https?:\/\/)?(?:[\w-]+\.)+[a-z]{2,}(?:\/\S*)?)$/iu', $text, $m)) {
            return null;
        }
        $url = $m[1];
        if (!preg_match('#^https?://#i', $url)) {
            $url = 'https://' . $url;
        }
        $raw  = strtolower((string) parse_url($url, PHP_URL_HOST));
        $host = preg_replace('/^(www|m|mobile|vm|vt|music)\./', '', $raw) ?? $raw;
        foreach (self::SITES as $key => [$name, $re]) {
            if (preg_match($re, $host)) {
                if ($depth < 2 && self::platformShort($key, $raw, $url) && ($final = self::resolveShort($url)) !== null) {
                    return self::match($final, $depth + 1);
                }
                if (!self::isContentUrl($key, $raw, $url)) {
                    return null;
                }
                if ($key === 'pinterest' && preg_match('#/pin/(?:[\w-]*?--)?(\d+)#', $url, $pm)) {
                    $url = 'https://www.pinterest.com/pin/' . $pm[1] . '/';
                }
                if ($key === 'instagram' && preg_match('#instagram\.com/(p|reel|reels|tv)/#i', $url)) {
                    $url = (string) preg_replace('/[?#].*$/', '', $url);
                }
                return ['url' => $url, 'site' => $key, 'name' => L($name, self::SITES[$key][3])];
            }
        }
        return null;
    }

    private static function isContentUrl(string $site, string $host, string $url): bool
    {
        $host  = preg_replace('/^(?:www|m|mobile)\./', '', $host) ?? $host;
        $path  = (string) parse_url($url, PHP_URL_PATH);
        $query = (string) parse_url($url, PHP_URL_QUERY);
        $segs  = array_values(array_filter(explode('/', $path), static fn($x) => $x !== ''));
        $short = count($segs) === 1;
        $hasV  = preg_match('/(?:^|&)v=\w/', $query) === 1;
        return match ($site) {
            'youtube'    => $host === 'youtu.be'
                ? $short
                : preg_match('#^/(?:shorts|live|embed|v|clip)/[\w-]+#', $path) === 1
                    || ($path === '/watch' && preg_match('/(?:^|&)v=[\w-]+/', $query) === 1),
            'instagram'  => preg_match('#^/(?:[\w.]+/)?(?:p|reel|tv)/[\w-]+#', $path) === 1
                || preg_match('#^/reels/(?!audio\b)[\w-]+#', $path) === 1
                || preg_match('#^/share/(?:(?:p|reel|reels|tv)/)?[\w-]+#', $path) === 1,
            'tiktok'     => (str_starts_with($host, 'vm.') || str_starts_with($host, 'vt.'))
                ? $short
                : preg_match('#^/(?:@[^/]*/(?:video|photo)/\d+|t/\w+|v/\d+|video/\d+|embed/(?:v2/)?\d+)#', $path) === 1,
            'twitter'    => preg_match('#^/(?:i/web/|i/)?(?:[\w]+/)?status(?:es)?/\d+#', $path) === 1
                || preg_match('#^/i/(?:broadcasts|spaces)/\w+#', $path) === 1,
            'soundcloud' => ($host === 'snd.sc' || $host === 'on.soundcloud.com')
                ? $short
                : (count($segs) >= 2
                    && !in_array($segs[0], ['discover', 'search', 'you', 'stream', 'charts', 'upload', 'pages', 'settings', 'messages', 'notifications', 'feed', 'people', 'popular', 'mobile', 'terms-of-use', 'imprint', 'player'], true)
                    && !(count($segs) === 2 && in_array($segs[1], ['tracks', 'albums', 'sets', 'likes', 'reposts', 'following', 'followers', 'popular-tracks', 'comments', 'spotlight', 'playlists'], true))),
            'pinterest'  => $host === 'pin.it'
                ? $short
                : preg_match('#^/pin/(?:[\w-]*?--)?\d+#', $path) === 1,
            'reddit'     => ($host === 'redd.it' || $host === 'v.redd.it')
                ? $short
                : preg_match('#^/(?:(?:r|user)/[\w-]+/)?comments/\w+#', $path) === 1
                    || preg_match('#^/(?:r/[\w-]+/)?s/\w+#', $path) === 1
                    ,
            'facebook'   => $host === 'fb.watch'
                ? $short
                : (in_array($path, ['/watch', '/watch/', '/watch/live', '/watch/live/'], true) ? $hasV : false)
                    || preg_match('#^/reel/\d+#', $path) === 1
                    || preg_match('#/videos/(?:[\w.-]+/)?\d+#', $path) === 1
                    || (preg_match('#^/video\.php$#', $path) === 1 && ($hasV || preg_match('/(?:^|&)id=\d/', $query) === 1))
                    || preg_match('#^/share/[vrp]/[\w-]+#', $path) === 1
                    || preg_match('#^/[\w.-]+/posts/[\w-]+#', $path) === 1
                    || preg_match('#^/groups/[^/]+/(?:permalink|posts)/[\w-]+#', $path) === 1
                    || ($path === '/story.php' && preg_match('/(?:^|&)story_fbid=\w/', $query) === 1)
                    || (preg_match('#^/permalink\.php$#', $path) === 1 && preg_match('/(?:^|&)story_fbid=\w/', $query) === 1),
            'snapchat'   => $host === 't.snapchat.com'
                ? $short
                : preg_match('#^/(?:spotlight|t)/[\w-]+#', $path) === 1
                    || preg_match('#^/@[\w.-]+/spotlight/[\w-]+#', $path) === 1,
            'spotify'    => ($host === 'spotify.link' || $host === 'spotify.app.link')
                ? $segs !== []
                : preg_match('#^/(?:intl-[\w-]+/)?(?:embed/)?(?:track|album|playlist)/[A-Za-z0-9]{22}#', $path) === 1,
            default      => true,
        };
    }

    public static function rejected(string $text): bool
    {
        $text = mbTrim($text);
        if ($text === '' || mb_strlen($text) > 600 || !preg_match('/^((?:https?:\/\/)?(?:[\w-]+\.)+[a-z]{2,}(?:\/\S*)?)$/iu', $text, $m)) {
            return false;
        }
        $url = preg_match('#^https?://#i', $m[1]) ? $m[1] : 'https://' . $m[1];
        $raw = strtolower((string) parse_url($url, PHP_URL_HOST));
        $host = preg_replace('/^(www|m|mobile|vm|vt|music)\./', '', $raw) ?? $raw;
        foreach (self::SITES as $key => [$name, $re]) {
            if (preg_match($re, $host)) {
                if (self::platformShort($key, $raw, $url) && ($final = self::resolveShort($url)) !== null) {
                    return self::match($final, 1) === null;
                }
                return self::isIgStory($text) || !self::isContentUrl($key, $raw, $url);
            }
        }
        return false;
    }

    public static function dislike(array $msg): void
    {
        if (!empty($msg['chat']['id']) && !empty($msg['message_id'])) {
            App::tg()->react($msg['chat']['id'], (int) $msg['message_id'], '👎');
            App::tg()->reply($msg, self::genericError());
        }
    }

    public static function find(string $text): ?array
    {
        if (preg_match_all('#(?:https?://)?(?:[\w-]+\.)+[a-z]{2,}/\S+#iu', $text, $m)) {
            foreach ($m[0] as $u) {
                if (($l = self::match(rtrim($u, '.,،!؟?)»"\''))) !== null) {
                    return $l;
                }
            }
        }
        return null;
    }

    public static function groupsEnabled(): bool
    {
        return env('DL_GROUPS', '1') !== '0';
    }

    public static function bin(): ?string
    {
        static $bin = false;
        if ($bin !== false) {
            return $bin;
        }
        $try = (string) env('YTDLP_BIN', '');
        if ($try !== '' && is_executable($try)) {
            return $bin = $try;
        }
        foreach (['/usr/local/bin/yt-dlp', '/usr/bin/yt-dlp'] as $p) {
            if (is_executable($p)) {
                return $bin = $p;
            }
        }
        $found = function_exists('shell_exec') ? trim((string) @shell_exec('command -v yt-dlp 2>/dev/null')) : '';
        return $bin = ($found !== '' ? $found : null);
    }

    public static function offer(array $msg, array $link): void
    {
        $tg  = App::tg();
        $uid = (int) $msg['from']['id'];
        if (($stop = self::gate($uid, $link)) !== null) {
            $tg->reply($msg, $stop);
            return;
        }
        $tg->react($msg['chat']['id'], (int) $msg['message_id'], '👍');
        $sent = Rich::sendHtml($msg['chat']['id'], L('🔎 دارم لینک ', '🔎 Checking ') . $link['name'] . L(' رو بررسی می‌کنم...', ' link...'), (int) $msg['message_id']);
        $mid  = (int) ($sent['result']['message_id'] ?? 0);
        if (!$mid) {
            return;
        }
        $tg->action($msg['chat']['id'], 'typing');
        self::prepare(['chat' => $msg['chat']['id'], 'card' => $mid, 'imid' => null, 'group' => ($msg['chat']['type'] ?? 'private') !== 'private'], $link, $uid, (int) $msg['message_id'], $msg);
    }

    public static function guest(array $from, array $link, string $imid): void
    {
        $tg  = App::tg();
        $uid = (int) ($from['id'] ?? 0);
        if (($stop = self::gate($uid, $link)) !== null) {
            Rich::editInline($imid, $stop);
            return;
        }
        $store = self::storeChat($uid);
        if ($store === null) {
            return;
        }
        self::prepare(['chat' => $store, 'card' => 0, 'imid' => $imid], $link, $uid, 0, null);
    }

    private static function gate(int $uid, array $link): ?string
    {
        if (self::bin() === null) {
            return L('⚠️ دانلودر هنوز رو سرور نصب نشده؛', '⚠️ The downloader isn’t installed on the server yet;') . "\n" . L('یه‌کم دیگه دوباره امتحان کن.', 'please try again in a bit.');
        }
        if (!App::isAdmin($uid) && self::usedToday($uid) >= self::DAILY) {
            return L('فردا دوباره بیا 🙂', 'Come back tomorrow 🙂') . "\n" . L('✋ امروز سهمیه‌ی دانلودت (', '✋ You’ve used up today’s download quota (') . fa(self::DAILY) . L(' تا) تموم شده؛', ' downloads).');
        }
        return null;
    }

    public static function storeChat(int $uid): int|string|null
    {
        $fixed = (string) env('DL_STORE_CHAT', '');
        if ($fixed !== '') {
            return preg_match('/^-?\d+$/', $fixed) ? (int) $fixed : $fixed;
        }
        $r = App::tg()->call('sendChatAction', ['chat_id' => $uid, 'action' => 'upload_document'], 8);
        return !empty($r['ok']) ? $uid : null;
    }

    private static function show(array $t, string $text, ?array $kb = null, ?array $preview = null): void
    {
        $tg = App::tg();
        if (!empty($t['imid'])) {
            $img = ($preview['url'] ?? '') !== '' ? self::thumbId($t, (string) $preview['url']) : null;
            Rich::editInline($t['imid'], $text, $kb, $img, true, null, false);
            return;
        }
        if (!empty($t['card'])) {
            Rich::editHtml($t['chat'], (int) $t['card'], $text, $kb, (string) ($preview['url'] ?? ''), false);
        }
    }

    private static function thumbId(array $t, string $url): ?string
    {
        $r     = Http::request('GET', $url, ['timeout' => 12, 'max_bytes' => 5000000]);
        $bytes = (string) ($r['body'] ?? '');
        if ($r['code'] !== 200 || $bytes === '' || @getimagesizefromstring($bytes) === false) {
            return null;
        }
        return App::tg()->photoFileId($t['chat'], $bytes);
    }

    private static function limit(array $t): int
    {
        return self::maxBytes();
    }

    private static function prepare(array $t, array $link, int $uid, int $replyTo, ?array $msg): void
    {
        if ($link['site'] === 'spotify' && ($set = Spotify::setRef($link['url'])) !== null) {
            self::prepareSet($t, $link, $uid, $replyTo, $set);
            return;
        }
        $sp = null;
        if ($link['site'] === 'spotify') {
            $sp = Spotify::track($link['url']);
            if (isset($sp['error'])) {
                self::show($t, $sp['error']);
                return;
            }
            $hit = $sp['yt'] ?? self::ytMatch(Spotify::query($sp), (int) $sp['duration']);
            if ($hit === null) {
                self::show($t, L("🤷 این آهنگ رو جایی برای دانلود پیدا نکردم 😕", "🤷 I couldn’t find this song anywhere to download 😕"));
                return;
            }
            Spotify::remember($sp, $hit);
            $link['url'] = $hit;
        }

        $link['url'] = self::cleanUrl($link['url'], $link['site']);

        $photos = static fn(int $expect = 0) => $sp === null && Photos::supports($link['site'])
            && ($msg !== null ? Photos::deliver($msg, $link, (int) $t['card'], $expect) : Photos::inline($link, (string) $t['imid'], $t['chat'], $uid));

        $multi = $sp === null && empty($t['imid']) && in_array($link['site'], self::MULTI, true);
        $ks    = $sp === null && GalleryDl::supports($link['site']) ? GalleryDl::kinds($link['url']) : [];
        $vurls = [];
        $pin   = $link['url'];
        if ($link['site'] === 'pinterest' && in_array('v', $ks, true)) {
            $u = GalleryDl::videoUrls($link['url']);
            if ($u !== [] && count($u) === count(array_keys($ks, 'v', true))) {
                $vurls = $u;
                if (count($ks) === 1) {
                    $link['url'] = $u[0];
                }
            }
            logInfo('dl', 'pinterest video: kinds=' . implode('', $ks) . ' mp4=' . count($u) . ' direct=' . ($vurls !== [] ? '1' : '0'));
        }
        $p     = $sp !== null
            ? ['info' => ['title' => $sp['title'], 'uploader' => $sp['artist'], 'channel' => $sp['artist'], 'duration' => (int) $sp['duration'], 'thumbnail' => $sp['cover'], 'webpage_url' => $link['url'], 'formats' => []]]
            : self::probe($link['url'], $multi);
        if (isset($p['error']) && count($ks) > 1 && in_array('v', $ks, true)) {
            $p = ['info' => ['count' => count($ks), 'kinds' => $ks, 'title' => '', 'webpage_url' => $link['url']]];
        }
        if (isset($p['error'])) {
            if (!$photos()) {
                self::show($t, $p['error']);
            }
            return;
        }
        $info = $p['info'];
        if ($vurls !== []) {
            $info['vurls'] = $vurls;
        }
        if ($link['site'] === 'pinterest') {
            foreach (GalleryDl::info($pin) as $k => $v) {
                if ($v !== '' && $v !== 0 && ($k === 'duration' ? empty($info[$k]) : true)) {
                    $info[$k] = $v;
                }
            }
        }
        if ($ks !== []) {
            $info['count'] = count($ks);
            $info['kinds'] = $ks;
        }
        $count = (int) ($info['count'] ?? 1);
        $vid   = $ks !== [] ? in_array('v', $ks, true) : self::hasVideo($info);
        logInfo('dl', "probe {$link['site']}: count={$count} kinds=" . implode('', (array) ($info['kinds'] ?? [])) . ' video=' . ($vid ? '1' : '0') . ' multi=' . ($multi ? '1' : '0') . ' src=' . ($ks !== [] ? 'gallery-dl' : 'yt-dlp'));
        if ($multi && $count > 1 && (in_array('v', (array) ($info['kinds'] ?? []), true) || !Photos::supports($link['site']))) {
            $token = self::newJob($link, $info, $uid, $t['chat'], (int) $t['card'], $replyTo, null, $count);
            self::show($t, self::albumText($info, $link, $count), self::albumKeyboard($token, $count), self::preview($info));
            return;
        }
        $expect = $multi && $count > 1 ? min($count, self::ALBUM_MAX) : 0;
        if (!$vid && $sp === null && Photos::supports($link['site']) && $photos($expect)) {
            return;
        }
        if ($expect > 1) {
            $token = self::newJob($link, $info, $uid, $t['chat'], (int) $t['card'], $replyTo, null, $count);
            self::show($t, self::albumText($info, $link, $count), self::albumKeyboard($token, $count), self::preview($info));
            return;
        }
        if ($sp !== null) {
            $info['title']    = $sp['title'];
            $info['uploader'] = $sp['artist'];
            $info['channel']  = $sp['artist'];
            $info['duration'] = $sp['duration'] ?: ($info['duration'] ?? 0);
            if ($sp['cover'] !== '') {
                $info['thumbnail'] = $sp['cover'];
            }
        }

        if (!empty($info['is_live']) || in_array($info['live_status'] ?? '', ['is_live', 'is_upcoming'], true)) {
            self::show($t, L('📡 این یه پخش زنده‌ست؛', '📡 This is a live stream;') . "\n" . L('وقتی تموم شد دوباره لینکش رو بفرست.', 'send the link again when it’s over.'));
            return;
        }

        $hasVideo = self::SITES[$link['site']][2] && (self::hasVideo($info) || $vurls !== []);
        $token    = self::newJob($link, $info, $uid, $t['chat'], (int) $t['card'], $replyTo, $t['imid']);
        $auto     = $hasVideo && $sp === null && !empty($t['group']) && empty($t['imid']) && (int) ($info['count'] ?? 1) <= 1
            ? self::armAuto($token, self::options($link['site'], $info, true, self::limit($t))[0][0] ?? 'hd')
            : false;
        self::show($t, self::cardText($info, $link, $hasVideo) . ($auto ? L("\n\n⏱ اگه تا ", "\n\n⏱ If you don’t choose anything within ") . fa((string) self::AUTO_DELAY) . L(" ثانیه‌ی دیگه چیزی انتخاب نکنی،\nخودکار با بالاترین کیفیت دانلود می‌شه.", " seconds,\nit will download automatically in the highest quality.") : ''), self::cardKeyboard($token, $link['site'], $info, $hasVideo, self::limit($t)), self::preview($info));
    }

    private static function prepareSet(array $t, array $link, int $uid, int $replyTo, array $ref): void
    {
        if (!empty($t['imid'])) {
            self::show($t, L('🎶 پلی‌لیست و آلبوم رو توی پیوی ربات بفرست 🙂', '🎶 Send playlists and albums in the bot’s private chat 🙂'));
            return;
        }
        $c = Spotify::collection($ref[0], $ref[1]);
        if (isset($c['error'])) {
            self::show($t, $c['error']);
            return;
        }
        $total = count($c['tracks']);
        $n     = min($total, self::SET_MAX);
        if (!App::isAdmin($uid)) {
            $n = min($n, max(0, self::DAILY - self::usedToday($uid)) * 10);
        }
        if ($n < 1) {
            self::show($t, L('فردا دوباره بیا 🙂', 'Come back tomorrow 🙂') . "\n" . L('✋ امروز سهمیه‌ی دانلودت تموم شده؛', '✋ You’ve used up today’s download quota;'));
            return;
        }
        $link['url'] = 'https://open.spotify.com/' . $ref[0] . '/' . $ref[1];
        $title       = $c['title'] !== '' ? $c['title'] : L('بدون عنوان', 'Untitled');
        $token       = self::newJob($link, ['title' => $title, 'uploader' => $c['owner'], 'webpage_url' => $link['url']], $uid, $t['chat'], (int) $t['card'], $replyTo, null, $n);
        $job         = Store::get('dl', $token);
        if (is_array($job)) {
            $job['sp_tracks'] = array_slice($c['tracks'], 0, $n);
            Store::set('dl', $token, $job);
        }
        $text = '🎶 <b>' . h(mb_substr($title, 0, 200)) . "</b>\n"
            . ($c['owner'] !== '' ? '👤 ' . h(mb_substr($c['owner'], 0, 60)) . ' · ' : '') . '📍 ' . $link['name'] . "\n\n"
            . '🎵 ' . fa((string) $total) . L(' آهنگ', ' songs') . L("؛\nهمه‌شون رو به‌صورت آلبوم بفرستم؟ 👇", ";\nShall I send them all as an album? 👇");
        $cover = (string) ($c['cover'] ?? '');
        if ($cover === '') {
            $f     = Spotify::track('https://open.spotify.com/track/' . $c['tracks'][0]['id']);
            $cover = (string) ($f['cover'] ?? '');
        }
        self::show($t, $text, ikb([
            [btn(L('📥 دانلود همه (', '📥 Download all (') . fa((string) $n) . L(' آهنگ)', ' songs)'), "dl:{$token}:all", 'success')],
            [btn(L('✖️ بیخیال', '✖️ Cancel'), "dl:{$token}:x", null)],
        ]), self::preview(['thumbnail' => Spotify::hires($cover)]));
    }

    private static function workSet(array $job, string $token): void
    {
        $uid    = (int) $job['owner'];
        $tracks = array_values((array) $job['sp_tracks']);
        $total  = count($tracks);
        $start  = time();
        $left   = App::isAdmin($uid) ? PHP_INT_MAX : max(0, self::DAILY - self::usedToday($uid)) * 10;
        $dir    = self::TMP . "/{$token}-set";
        $slot   = null;
        $batch  = [];
        $ok     = 0;
        $failed = [];
        $stop   = '';
        $flush  = static function () use (&$batch, &$ok, &$failed, $job, $dir): void {
            if (!$batch) {
                return;
            }
            if (self::flushSet($job, $batch)) {
                $ok += count($batch);
            } else {
                foreach ($batch as $b) {
                    $failed[] = $b['name'];
                }
            }
            $batch = [];
            self::rmrf($dir);
            @mkdir($dir, 0775, true);
        };
        try {
            $slot = self::acquireSlot($job);
            if ($slot === null) {
                self::show($job, L('😮‍💨 سرور الان خیلی شلوغه؛', '😮‍💨 The server is very busy right now;') . "\n" . L('چند دقیقه دیگه لینک رو دوباره بفرست.', 'send the link again in a few minutes.'));
                return;
            }
            self::rmrf($dir);
            @mkdir($dir, 0775, true);
            foreach ($tracks as $i => $tr) {
                if (time() - $start > self::jobTime()) {
                    $stop = 'time';
                    break;
                }
                if ($ok + count($batch) >= $left) {
                    $stop = 'quota';
                    break;
                }
                $name = mb_substr(Spotify::query($tr), 0, 120);
                self::show($job, self::stageText($job, self::bar((int) floor($i / $total * 100)) . ' ' . fa((string) ($i + 1)) . L(' از ', ' of ') . fa((string) $total) . "\n🔎 " . h($name)));
                Store::set('dl_busy', (string) $uid, time());
                $item = self::setFetch($job, $tr, $dir, $i, $name);
                if ($item === null) {
                    $failed[] = $name;
                    continue;
                }
                $batch[] = $item;
                if (count($batch) >= 10) {
                    $flush();
                }
            }
            self::show($job, self::stageText($job, L('📤 دارم آلبوم رو می‌فرستم...', '📤 Sending the album...')));
            $flush();
        } catch (\Throwable $e) {
            logError('dl', 'set: ' . $e->getMessage());
            foreach ($batch as $b) {
                $failed[] = $b['name'];
            }
        } finally {
            self::rmrf($dir);
            Store::delete('dl_busy', (string) $uid);
            if ($slot) {
                flock($slot, LOCK_UN);
                fclose($slot);
            }
        }
        if ($ok > 0) {
            $bot = App::botUsername();
            App::tg()->call('sendMessage', [
                'chat_id'              => $job['chat'],
                'text'                 => ($d = dirMark($job['title'])) . '🎶 <b>' . h(mb_substr($job['title'], 0, 300)) . "</b>\n" . ($job['uploader'] !== '' ? $d . '👤 ' . bidi(h($job['uploader'])) . "\n" : '') . "\n" . $d . "📥 <a href=\"https://t.me/{$bot}\">@{$bot}</a>",
                'parse_mode'           => 'HTML',
                'link_preview_options' => ['is_disabled' => true],
            ], 20);
        }
        $text = '✅ ' . fa((string) $ok) . L(' از ', ' of ') . fa((string) $total) . L(' آهنگ فرستاده شد', ' songs sent');
        if ($stop === 'quota') {
            $text .= L("\n✋ سهمیه‌ی امروزت تموم شد؛ بقیه رو فردا بفرست.", "\n✋ Today’s quota is used up; send the rest tomorrow.");
        } elseif ($stop === 'time') {
            $text .= L("\n⏱ وقتم تموم شد؛ بقیه‌ی آهنگ‌ها نرسید.", "\n⏱ I ran out of time; the remaining songs didn’t make it.");
        }
        if ($failed) {
            $text .= L("\n\n😕 اینا رو نتونستم پیدا یا دانلود کنم:\n", "\n\n😕 I couldn’t find or download these:\n") . implode("\n", array_map(static fn($n) => '• ' . h($n), array_slice($failed, 0, 10)));
        }
        if ($stop === '' && !$failed && $ok >= $total) {
            App::tg()->call('deleteMessage', ['chat_id' => $job['chat'], 'message_id' => (int) $job['card']], 8);
        } else {
            self::show($job, '🎶 <b>' . h(mb_substr($job['title'], 0, 200)) . "</b>\n\n" . $text);
        }
        Store::delete('dl', $token);
    }

    private static function setFetch(array $job, array $tr, string $dir, int $i, string $name): ?array
    {
        $yt = Store::get('cache', 'spyt:' . $tr['id']);
        if (!is_string($yt) || $yt === '') {
            $yt = self::ytMatch(Spotify::query($tr), (int) $tr['duration']);
            if ($yt === null) {
                return null;
            }
            Store::set('cache', 'spyt:' . $tr['id'], $yt);
        }
        $key  = self::cacheKey($yt, 'mp3cv');
        $item = ['key' => $key, 'thumb' => null, 'name' => $name, 'title' => mb_substr($tr['title'], 0, 64), 'performer' => mb_substr($tr['artist'], 0, 64), 'duration' => (int) $tr['duration'], 'file' => null, 'id' => null];
        $c    = Store::get('dl_files', $key);
        if (is_array($c) && ($c['type'] ?? '') === 'audio' && !empty($c['file_id'])) {
            $item['id'] = (string) $c['file_id'];
            return $item;
        }
        $sp    = Spotify::track('https://open.spotify.com/track/' . $tr['id']);
        $cover = !isset($sp['error']) && !empty($sp['cover']) ? self::setCover(Spotify::hires((string) $sp['cover']), $dir . "/c{$i}") : null;
        $out = $dir . '/t' . $i;
        @mkdir($out, 0775, true);
        self::run(array_merge([self::bin()], self::commonArgs(), self::formatArgs('mp3', true), [
            '--no-playlist', '--no-warnings', '--no-mtime', '--restrict-filenames',
            '--socket-timeout', '20', '--retries', '3', '--fragment-retries', '3', '--max-filesize', '49M',
            '-o', $out . '/%(id).40s.%(ext)s',
        ], [], [$yt]), 240);
        $file = self::pickFile($out);
        if ($file === null || filesize($file) > self::BOT_API_BYTES) {
            self::rmrf($out);
            return null;
        }
        if ($cover !== null) {
            $tmp = $out . '/withcover.mp3';
            self::run(['ffmpeg', '-y', '-v', 'error', '-i', $file, '-i', $cover['full'], '-map', '0:a', '-map', '1:v', '-c', 'copy', '-id3v2_version', '3',
                '-metadata:s:v', 'title=Cover', '-metadata:s:v', 'comment=Cover (front)', $tmp], 60);
            if (is_file($tmp) && filesize($tmp) > 0 && filesize($tmp) <= self::BOT_API_BYTES) {
                @rename($tmp, $file);
            } else {
                @unlink($tmp);
            }
        }
        $item['file']  = $file;
        $item['thumb'] = $cover['thumb'] ?? null;
        return $item;
    }

    private static function setCover(string $url, string $base): ?array
    {
        if ($url === '' || !preg_match('#^https://#', $url)) {
            return null;
        }
        @mkdir(dirname($base), 0775, true);
        $r = Http::request('GET', $url, ['timeout' => 15, 'max_bytes' => 8 * 1048576]);
        if ($r['body'] === null || $r['body'] === '') {
            return null;
        }
        $full  = $base . '-full.jpg';
        $thumb = $base . '-thumb.jpg';
        $raw   = $base . '.src';
        file_put_contents($raw, $r['body']);
        if (str_starts_with($r['body'], "\xFF\xD8")) {
            @rename($raw, $full);
        } else {
            self::run(['ffmpeg', '-y', '-v', 'error', '-i', $raw, '-frames:v', '1', '-q:v', '1', $full], 30);
            @unlink($raw);
        }
        if (!is_file($full) || filesize($full) < 1) {
            return null;
        }
        foreach ([4, 8, 14] as $q) {
            self::run(['ffmpeg', '-y', '-v', 'error', '-i', $full, '-frames:v', '1', '-vf', 'scale=320:320:force_original_aspect_ratio=increase,crop=320:320', '-q:v', (string) $q, $thumb], 30);
            if (is_file($thumb) && filesize($thumb) > 0 && filesize($thumb) < 200 * 1024) {
                return ['full' => $full, 'thumb' => $thumb];
            }
        }
        return ['full' => $full, 'thumb' => null];
    }

    private static function flushSet(array $job, array $batch): bool
    {
        $tg      = App::tg();
        $reply   = $job['reply_to'] ? ['message_id' => (int) $job['reply_to'], 'allow_sending_without_reply' => true] : null;
        $media   = [];
        $params  = ['chat_id' => $job['chat'], 'reply_parameters' => $reply];
        foreach ($batch as $k => $b) {
            $m = ['type' => 'audio', 'media' => $b['file'] !== null ? "attach://f{$k}" : $b['id']];
            if ($b['file'] !== null) {
                $m['title']     = $b['title'];
                $m['performer'] = $b['performer'] !== '' ? $b['performer'] : null;
                $m['duration']  = $b['duration'] ?: null;
                $params["f{$k}"] = new CURLFile($b['file'], 'audio/mpeg', preg_replace('/[^\w\- ]+/u', '', $b['name']) . '.mp3');
                if (!empty($b['thumb']) && is_file($b['thumb'])) {
                    $m['thumbnail']  = "attach://c{$k}";
                    $params["c{$k}"] = new CURLFile($b['thumb'], 'image/jpeg', 'cover.jpg');
                }
            }
            $media[] = array_filter($m, static fn($v) => $v !== null);
        }
        if (count($media) === 1) {
            $m = $media[0];
            unset($params['f0'], $params['c0']);
            $p = ['chat_id' => $job['chat'], 'audio' => $batch[0]['file'] !== null ? new CURLFile($batch[0]['file'], 'audio/mpeg', 'track.mp3') : $batch[0]['id'], 'title' => $m['title'] ?? null, 'performer' => $m['performer'] ?? null, 'duration' => $m['duration'] ?? null, 'reply_parameters' => $reply];
            if ($batch[0]['file'] !== null && !empty($batch[0]['thumb']) && is_file($batch[0]['thumb'])) {
                $p['thumbnail'] = new CURLFile($batch[0]['thumb'], 'image/jpeg', 'cover.jpg');
            }
            $r    = $tg->call('sendAudio', $p, 300);
            $msgs = !empty($r['ok']) ? [$r['result']] : [];
        } else {
            $params['media'] = $media;
            $r    = $tg->call('sendMediaGroup', $params, 300);
            $msgs = !empty($r['ok']) ? array_values((array) $r['result']) : [];
        }
        if (!$msgs) {
            logWarn('dl', 'set send failed: ' . (string) ($r['description'] ?? ''));
            return false;
        }
        foreach ($batch as $k => $b) {
            if ($b['file'] !== null) {
                $fid = $msgs[$k]['audio']['file_id'] ?? $msgs[$k]['document']['file_id'] ?? null;
                if ($fid) {
                    Store::set('dl_files', $b['key'], ['type' => 'audio', 'file_id' => $fid]);
                }
            }
            Users::hit('dl:spotify');
        }
        self::charge((int) $job['owner']);
        return true;
    }

    private static function newJob(array $link, array $info, int $uid, int|string $chat, int $card, int $replyTo, ?string $imid = null, int $count = 1): string
    {
        $token = bin2hex(random_bytes(6));
        Store::set('dl', $token, [
            'url'      => (string) ($info['webpage_url'] ?? $link['url']),
            'site'     => $link['site'],
            'title'    => mb_substr((string) ($info['title'] ?? $link['name']), 0, 3500),
            'uploader' => mb_substr((string) ($info['uploader'] ?? $info['channel'] ?? $info['uploader_id'] ?? ''), 0, 80),
            'duration' => (int) ($info['duration'] ?? 0),
            'width'    => (int) ($info['width'] ?? 0),
            'height'   => (int) ($info['height'] ?? 0),
            'owner'    => $uid,
            'chat'     => $chat,
            'card'     => $card,
            'reply_to' => $replyTo,
            'imid'     => $imid,
            'count'    => $count,
            'kinds'    => array_values((array) ($info['kinds'] ?? [])),
            'vurls'    => array_values((array) ($info['vurls'] ?? [])),
        ]);
        return $token;
    }

    private static function armAuto(string $token, string $fmt): bool
    {
        $job = Store::get('dl', $token);
        if (!is_array($job) || !function_exists('exec') || in_array('exec', array_map('trim', explode(',', (string) ini_get('disable_functions'))), true)) {
            return false;
        }
        $job['auto'] = $fmt;
        Store::set('dl', $token, $job);
        $cmd = '(sleep ' . self::AUTO_DELAY . '; timeout -k 10 ' . self::jobTime() . ' ' . escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg(NULLINI_ROOT . '/bot.php')
            . ' --autodl ' . escapeshellarg($token) . ' ' . App::botIndex() . ') > /dev/null 2>&1 &';
        exec($cmd, $o, $code);
        return $code === 0;
    }

    public static function auto(string $token): void
    {
        $job = Store::get('dl', $token);
        if (!is_array($job) || empty($job['auto'])) {
            return;
        }
        if (Store::update('dl_claim', $token, static fn($v) => $v ? null : time()) === null) {
            return;
        }
        $r = self::begin($token, (string) $job['auto'], (int) $job['owner']);
        if (isset($r['error']) && $r['error'] !== '') {
            self::show($job, $r['error']);
        }
    }

    public static function charge(int $uid): void
    {
        Store::update('dl_quota', self::quotaKey($uid), static fn($n) => (int) $n + 1);
    }

    private static function ytMatch(string $q, int $dur): ?string
    {
        if ($q === '') {
            return null;
        }
        $res = self::run(array_merge([self::bin()], self::commonArgs(), [
            '-J', '--flat-playlist', '--no-warnings', '--socket-timeout', '15', 'ytsearch6:' . $q,
        ]), 45);
        $j    = json_decode($res['out'], true);
        $list = [];
        foreach (array_values((array) ($j['entries'] ?? [])) as $e) {
            $id = (string) ($e['id'] ?? '');
            if (preg_match('/^[\w-]{11}$/', $id)) {
                $list[] = ['id' => $id, 'title' => (string) ($e['title'] ?? ''), 'by' => (string) ($e['channel'] ?? $e['uploader'] ?? ''), 'd' => (int) ($e['duration'] ?? 0)];
            }
        }
        $best = null;
        if ($dur > 0 && $list) {
            $near = array_values(array_filter($list, static fn($e) => $e['d'] > 0 && abs($e['d'] - $dur) <= 4));
            if ($near && $near[0]['id'] === $list[0]['id']) {
                return 'https://www.youtube.com/watch?v=' . $list[0]['id'];
            }
        }
        if ($list) {
            $lines = [];
            foreach ($list as $n => $e) {
                $lines[] = ($n + 1) . '. ' . $e['title'] . ' | ' . $e['by'] . ' | ' . $e['d'] . 's';
            }
            $pick = AI::chat([
                ['role' => 'system', 'content' => 'Pick the YouTube result that is the original studio recording of the requested track. Reply with its number only.'],
                ['role' => 'user', 'content' => "Track: {$q}" . ($dur > 0 ? " ({$dur}s)" : '') . "\n" . implode("\n", $lines)],
            ], ['tier' => 'lite', 'temperature' => 0, 'thinking' => null, 'deadline' => microtime(true) + 10]);
            $n = $pick !== null && preg_match('/\d+/', $pick, $pm) ? (int) $pm[0] - 1 : -1;
            if (!isset($list[$n])) {
                usort($list, static fn($a, $b) => ($dur > 0 && $a['d'] > 0 ? abs($a['d'] - $dur) : 999) <=> ($dur > 0 && $b['d'] > 0 ? abs($b['d'] - $dur) : 999));
                $n = 0;
            }
            $best = 'https://www.youtube.com/watch?v=' . $list[$n]['id'];
        }
        if ($best === null) {
            logWarn('dl', 'spotify yt match failed: ' . self::lastLine($res['err']));
        }
        return $best;
    }

    public static function begin(string $token, string $fmt, int $uid): array
    {
        if (!preg_match('/^(fhd|hd|sd|mp3|all|v\d{3,4})$/', $fmt) || !preg_match('/^[a-f0-9]{6,32}$/', $token)) {
            return ['error' => L('⌛️ منقضی شده؛', '⌛️ Expired;') . "\n" . L('لینک رو دوباره بفرست.', 'send the link again.')];
        }
        $tg  = App::tg();
        $job = Store::get('dl', $token);
        if (!is_array($job)) {
            return ['error' => L('⌛️ منقضی شده؛', '⌛️ Expired;') . "\n" . L('لینک رو دوباره بفرست.', 'send the link again.')];
        }
        if ($uid !== (int) $job['owner'] && !App::isAdmin($uid)) {
            return ['error' => L('🙅 این دکمه مال کسیه که لینک رو فرستاده؛', '🙅 This button belongs to whoever sent the link;') . "\n" . L('لینک خودت رو بفرست 🙂', 'send your own link 🙂')];
        }
        Store::set('dl_claim', $token, time());
        $cached = Store::get('dl_files', self::cacheKey($job['url'], $fmt));
        if (is_array($cached) && (!empty($job['imid']) ? self::toInline($job, $cached) : self::sendCached($job, $cached))) {
            if ($job['card'] && empty($job['imid'])) {
                $tg->call('deleteMessage', ['chat_id' => $job['chat'], 'message_id' => $job['card']], 8);
            }
            Users::hit('dl:' . $job['site']);
            return ['ok' => 'sent'];
        }
        if (!App::isAdmin($uid) && self::usedToday($uid) >= self::DAILY) {
            return ['error' => L('فردا دوباره بیا 🙂', 'Come back tomorrow 🙂') . "\n" . L('✋ امروز سهمیه‌ی دانلودت (', '✋ You’ve used up today’s download quota (') . fa(self::DAILY) . L(' تا) تموم شده؛', ' downloads).')];
        }
        $got = Store::update('dl_busy', (string) $uid, static fn($at) => (is_int($at) && time() - $at < self::jobTime() + 20) ? null : time());
        if ($got === null) {
            return ['error' => L('⏳ یه دانلود دیگه‌ت در جریانه؛', '⏳ You already have another download in progress;') . "\n" . L('صبر کن اون تموم شه.', 'wait for it to finish.')];
        }
        if (!empty($job['imid'])) {
            self::show($job, self::stageText($job, L('⏳ آماده‌ی دانلود...', '⏳ Getting ready to download...')));
        } elseif (!$job['card']) {
            $r = Rich::sendHtml($job['chat'], self::stageText($job, L('⏳ آماده‌ی دانلود...', '⏳ Getting ready to download...')), null, null, null, false);
            $card = (int) ($r['result']['message_id'] ?? 0);
            if (!$card) {
                Store::delete('dl_busy', (string) $uid);
                return ['error' => ''];
            }
            $job['card'] = $card;
            Store::set('dl', $token, $job);
        } else {
            self::show($job, self::stageText($job, L('⏳ آماده‌ی دانلود...', '⏳ Getting ready to download...')));
        }
        if (!self::spawn($token, $fmt)) {
            if (function_exists('pcntl_alarm')) {
                pcntl_alarm(self::jobTime());
            }
            @set_time_limit(self::jobTime());
            self::work($token, $fmt);
        }
        return ['ok' => 'started'];
    }

    private static function hasVideo(array $info): bool
    {
        if (!empty($info['formats']) && is_array($info['formats'])) {
            foreach ($info['formats'] as $f) {
                if (($f['vcodec'] ?? 'none') !== 'none' || !empty($f['height'])) {
                    return true;
                }
            }
            return false;
        }
        return !empty($info['height']) || ($info['vcodec'] ?? 'none') !== 'none';
    }

    private static function preview(array $info): array
    {
        $thumb = (string) ($info['thumbnail'] ?? '');
        if ($thumb === '' || !preg_match('#^https://#', $thumb)) {
            return ['is_disabled' => true];
        }
        return ['url' => $thumb, 'prefer_large_media' => true, 'show_above_text' => true];
    }

    private static function cardText(array $info, array $link, bool $hasVideo): string
    {
        $title = mb_substr((string) ($info['title'] ?? ''), 0, 3500);
        $who   = (string) ($info['uploader'] ?? $info['channel'] ?? '');
        $meta  = [];
        if ($who !== '') {
            $meta[] = '👤 ' . h(mb_substr($who, 0, 40));
        }
        if (!empty($info['duration'])) {
            $meta[] = '⏱ ' . fa(self::clock((int) $info['duration']));
        }
        $meta[] = '📍 ' . $link['name'];

        return ($hasVideo ? '🎬 ' : '🎵 ') . '<b>' . h($title !== '' ? $title : L('بدون عنوان', 'Untitled')) . "</b>\n"
            . implode(' · ', $meta) . "\n\n"
            . ($hasVideo ? L('چی می‌خوای؟ 👇', 'What do you want? 👇') : L('آماده‌ی دانلود 👇', 'Ready to download 👇'));
    }

    private static function cardKeyboard(string $token, string $site, array $info, bool $hasVideo, int $max): array
    {
        $rows = [];
        foreach (self::options($site, $info, $hasVideo, $max) as $i => [$fmt, $label]) {
            $rows[] = [btn($label, "dl:{$token}:{$fmt}", $i === 0 ? 'success' : 'primary')];
        }
        $rows[] = [btn(L('✖️ بیخیال', '✖️ Cancel'), "dl:{$token}:x", null)];
        return ikb($rows);
    }

    private static function albumText(array $info, array $link, int $count): string
    {
        $title = mb_substr((string) ($info['title'] ?? ''), 0, 3500);
        $who   = (string) ($info['uploader'] ?? $info['channel'] ?? '');
        $kinds = array_count_values((array) ($info['kinds'] ?? []));
        $parts = [];
        if (!empty($kinds['v'])) {
            $parts[] = fa((string) $kinds['v']) . L(' ویدیو', ' video(s)');
        }
        if (!empty($kinds['p'])) {
            $parts[] = fa((string) $kinds['p']) . L(' عکس', ' photo(s)');
        }
        return '📚 <b>' . h($title !== '' ? $title : L('بدون عنوان', 'Untitled')) . "</b>\n"
            . ($who !== '' ? '👤 ' . h(mb_substr($who, 0, 40)) . ' · ' : '') . '📍 ' . $link['name'] . "\n\n"
            . L('🎞 این پست ', '🎞 This post has ') . fa((string) $count) . L(' تا فایل داره', ' files') . ($parts ? ' (' . implode(L(' و ', ' and '), $parts) . ')' : '') . L("؛\nهمه‌شون رو بفرستم؟ 👇", ";\nShall I send them all? 👇");
    }

    private static function albumKeyboard(string $token, int $count): array
    {
        return ikb([
            [btn(L('📥 دانلود همه (', '📥 Download all (') . fa((string) $count) . L(' تا)', ' files)'), "dl:{$token}:all", 'success')],
            [btn(L('✖️ بیخیال', '✖️ Cancel'), "dl:{$token}:x", null)],
        ]);
    }

    private static function sizeHint(array $info, int $h, ?int $bytes = null): string
    {
        $b = $bytes ?? self::estimate($info, $h);
        return $b >= 1048576 ? ' (~' . self::mb((float) $b) . ')' : '';
    }

    private static function mp3Hint(array $info): string
    {
        $dur = (int) ($info['duration'] ?? 0);
        $b   = $dur * 16500;
        return $b >= 1048576 ? ' (~' . self::mb((float) $b) . ')' : '';
    }

    private static function isVertical(array $a): bool
    {
        $w = (int) ($a['width'] ?? 0);
        $h = (int) ($a['height'] ?? 0);
        return $w > 0 && $h > $w;
    }

    private static function kind(array $f): string
    {
        $vc = $f['vcodec'] ?? null;
        $ac = $f['acodec'] ?? null;
        if ($vc === 'none' || ($vc === null && (int) ($f['height'] ?? 0) <= 0)) {
            return ($ac !== null && $ac !== 'none') ? 'a' : '';
        }
        return 'v';
    }

    private static function shortSide(array $f, array $info): int
    {
        $h = (int) ($f['height'] ?? 0);
        $w = (int) ($f['width'] ?? 0);
        if ($h <= 0) {
            return 0;
        }
        if ($w > 0) {
            return min($h, $w);
        }
        $iw = (int) ($info['width'] ?? 0);
        $ih = (int) ($info['height'] ?? 0);
        return ($iw > 0 && $ih > $iw) ? (int) round($h * $iw / $ih) : $h;
    }

    private static function stdOf(array $f, array $info): int
    {
        $s = self::shortSide($f, $info);
        if ($s <= 0) {
            return 0;
        }
        foreach ([144, 240, 360, 480, 720, 1080, 1440, 2160] as $std) {
            if ($s <= $std + 40 && $s >= $std * 0.85) {
                return $std;
            }
        }
        return 0;
    }

    private static function fmtSize(array $f, int $dur): int
    {
        $s = (int) ($f['filesize'] ?? 0);
        if ($s <= 0) {
            $s = (int) ($f['filesize_approx'] ?? 0);
        }
        if ($s <= 0 && $dur > 0) {
            $br = (float) ($f['tbr'] ?? 0);
            if ($br <= 0) {
                $br = (float) ($f['vbr'] ?? 0) + (float) ($f['abr'] ?? 0);
            }
            $s = (int) round($br * 125 * $dur);
        }
        return max(0, $s);
    }

    private static function codecDistance(string $vcodec): int
    {
        $order = ['/^av0?1/i', '/^vp0?9\.2/i', '/^vp0?9/i', '/^(hev|hvc|h265|hevc)/i', '/^(avc|h264)/i', '/^vp0?8/i', '/^(mp4v|h263)/i', '/^theora/i'];
        $idx   = count($order);
        foreach ($order as $i => $re) {
            if (preg_match($re, $vcodec)) {
                $idx = $i;
                break;
            }
        }
        return abs($idx - 4);
    }

    private static function estimate(array $info, int $std): int
    {
        $dur    = (int) ($info['duration'] ?? 0);
        $videos = [];
        $audios = [];
        foreach ((array) ($info['formats'] ?? []) as $f) {
            $f = (array) $f;
            $k = self::kind($f);
            if ($k === 'v' && self::stdOf($f, $info) === $std) {
                $videos[] = $f;
            } elseif ($k === 'a') {
                $audios[] = $f;
            }
        }
        if (!$videos) {
            return 0;
        }
        $isOdd = static fn(array $f): bool => stripos((string) ($f['format_note'] ?? ''), 'premium') !== false
            || str_starts_with((string) ($f['protocol'] ?? ''), 'm3u8');
        $plain = array_values(array_filter($videos, static fn($f) => !$isOdd($f)));
        if ($plain) {
            $videos = $plain;
        }
        $plainA = array_values(array_filter($audios, static fn($f) => !$isOdd($f)));
        if ($plainA) {
            $audios = $plainA;
        }
        usort($videos, static function (array $a, array $b) use ($info, $dur): int {
            $ra = self::shortSide($a, $info);
            $rb = self::shortSide($b, $info);
            if ($ra !== $rb) {
                return $rb <=> $ra;
            }
            $ha = str_starts_with((string) ($a['vcodec'] ?? ''), 'avc') ? 1 : 0;
            $hb = str_starts_with((string) ($b['vcodec'] ?? ''), 'avc') ? 1 : 0;
            if ($ha !== $hb) {
                return $hb <=> $ha;
            }
            $ea = (($a['ext'] ?? '') === 'mp4') ? 1 : 0;
            $eb = (($b['ext'] ?? '') === 'mp4') ? 1 : 0;
            if ($ea !== $eb) {
                return $eb <=> $ea;
            }
            $da = self::codecDistance((string) ($a['vcodec'] ?? ''));
            $db = self::codecDistance((string) ($b['vcodec'] ?? ''));
            if ($da !== $db) {
                return $da <=> $db;
            }
            $fa = (float) ($a['fps'] ?? 0);
            $fb = (float) ($b['fps'] ?? 0);
            if ($fa !== $fb) {
                return $fb <=> $fa;
            }
            $sa = self::fmtSize($a, $dur);
            $sb = self::fmtSize($b, $dur);
            if ($sa !== $sb) {
                return $sb <=> $sa;
            }
            $va = (($a['acodec'] ?? 'none') === 'none' || ($a['acodec'] ?? null) === null) ? 1 : 0;
            $vb = (($b['acodec'] ?? 'none') === 'none' || ($b['acodec'] ?? null) === null) ? 1 : 0;
            return $vb <=> $va;
        });
        $v     = null;
        $vsize = 0;
        foreach ($videos as $cand) {
            $sz = self::fmtSize($cand, $dur);
            if ($v === null) {
                $v = $cand;
            }
            if ($sz > 0) {
                $v     = $cand;
                $vsize = $sz;
                break;
            }
        }
        if ($vsize <= 0) {
            return 0;
        }
        $muxed = ($v['acodec'] ?? 'none') !== 'none' && ($v['acodec'] ?? null) !== null;
        if ($muxed || !$audios) {
            return $vsize;
        }
        usort($audios, static function (array $a, array $b): int {
            $ma = str_starts_with((string) ($a['acodec'] ?? ''), 'mp4a') ? 1 : 0;
            $mb = str_starts_with((string) ($b['acodec'] ?? ''), 'mp4a') ? 1 : 0;
            if ($ma !== $mb) {
                return $mb <=> $ma;
            }
            return (float) ($b['abr'] ?? 0) <=> (float) ($a['abr'] ?? 0);
        });
        $asize = 0;
        foreach ($audios as $a) {
            $asize = self::fmtSize($a, $dur);
            if ($asize > 0) {
                break;
            }
        }
        return $vsize + $asize;
    }

    public static function onCallback(array $cq, string $data): void
    {
        $tg = App::tg();
        if (!preg_match('/^dl:([a-f0-9]{12}):(fhd|hd|sd|mp3|all|x|v\d{3,4})$/', $data, $m)) {
            $tg->answer($cq);
            return;
        }
        [, $token, $fmt] = $m;
        $uid = (int) $cq['from']['id'];
        $job = Store::get('dl', $token);
        if (!is_array($job)) {
            $tg->alert($cq, L('⌛️ این کارت منقضی شده؛', '⌛️ This card has expired;') . "\n" . L('لینک رو دوباره بفرست.', 'send the link again.'));
            return;
        }
        if ($uid !== (int) $job['owner'] && !App::isAdmin($uid)) {
            $tg->alert($cq, L('🙅 این دکمه مال کسیه که لینک رو فرستاده؛', '🙅 This button belongs to whoever sent the link;') . "\n" . L('لینک خودت رو بفرست 🙂', 'send your own link 🙂'));
            return;
        }
        if ($fmt === 'x') {
            if (!empty($job['imid'])) {
                self::show($job, L('✖️ بیخیال شدی.', '✖️ You cancelled.'));
            } else {
                $tg->call('deleteMessage', ['chat_id' => $job['chat'], 'message_id' => $job['card']], 8);
            }
            Store::delete('dl', $token);
            $tg->answer($cq, L('باشه 👌', 'OK 👌'));
            return;
        }

        $r = self::begin($token, $fmt, $uid);
        if (isset($r['error'])) {
            $r['error'] !== '' ? $tg->alert($cq, $r['error']) : $tg->answer($cq);
            return;
        }
        $tg->answer($cq, $r['ok'] === 'sent' ? L('⚡️ فرستادمش', '⚡️ Sent it') : L('⏳ شروع شد', '⏳ Started'));
    }

    private static function spawn(string $token, string $fmt): bool
    {
        if (!function_exists('exec') || in_array('exec', array_map('trim', explode(',', (string) ini_get('disable_functions'))), true)) {
            return false;
        }
        $cmd = 'timeout -k 10 ' . self::jobTime() . ' ' . escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg(NULLINI_ROOT . '/bot.php')
            . ' --download ' . escapeshellarg($token) . ' ' . escapeshellarg($fmt) . ' ' . App::botIndex() . ' > /dev/null 2>&1 &';
        exec($cmd, $o, $code);
        return $code === 0;
    }

    public static function work(string $token, string $fmt): void
    {
        $tg  = App::tg();
        $job = Store::get('dl', $token);
        if (!is_array($job)) {
            return;
        }
        if ($fmt === 'all' && !empty($job['sp_tracks'])) {
            self::workSet($job, $token);
            return;
        }
        $chat = $job['chat'];
        $card = (int) $job['card'];
        $dir  = self::TMP . "/{$token}-{$fmt}";
        $slot = null;

        try {
            $slot = self::acquireSlot($job);
            if ($slot === null) {
                self::show($job, L('😮‍💨 سرور الان خیلی شلوغه؛', '😮‍💨 The server is very busy right now;') . "\n" . L('چند دقیقه دیگه لینک رو دوباره بفرست.', 'send the link again in a few minutes.'));
                return;
            }
            self::rmrf($dir);
            @mkdir($dir, 0775, true);

            if ($fmt === 'all') {
                self::workAlbum($job, $token, $dir);
                return;
            }
            self::show($job, self::stageText($job, self::bar(0) . L(' ۰٪', ' 0%')));
            $limit = self::limit($job);
            $last  = 0.0;
            $stage = '';
            $res   = self::run(array_merge([self::bin()], self::commonArgs(), self::formatArgs($fmt, $limit <= self::BOT_API_BYTES, self::isVertical($job)), [
                '--no-playlist', '--newline', '--no-warnings', '--no-mtime', '--restrict-filenames',
                '--socket-timeout', '20', '--retries', '3', '--fragment-retries', '3', '--concurrent-fragments', '4',
                '--max-filesize', (int) ($limit / 1048576) . 'M',
                '--progress-template', 'download:NLP %(progress.downloaded_bytes)s %(progress.total_bytes)s %(progress.total_bytes_estimate)s %(progress.speed)s',
                '-o', $dir . '/%(id).40s.%(ext)s',
            ], [], [
                $job['url'],
            ]), self::jobTime() - 60, static function (string $line) use ($job, &$last, &$stage): void {
                $now = microtime(true);
                if (str_starts_with($line, 'NLP ')) {
                    if ($now - $last < 3.5) {
                        return;
                    }
                    $p     = explode(' ', $line);
                    $done  = (float) ($p[1] ?? 0);
                    $total = (float) (is_numeric($p[2] ?? '') ? $p[2] : ($p[3] ?? 0));
                    $speed = (float) (is_numeric($p[4] ?? '') ? $p[4] : 0);
                    $pct   = $total > 0 ? min(100, (int) floor($done / $total * 100)) : 0;
                    $line2 = '📦 ' . self::mb($done) . ($total > 0 ? L(' از ', ' of ') . self::mb($total) : '') . ($speed > 0 ? ' · ⚡️ ' . self::mb($speed) . L('/ث', '/s') : '');
                    self::show($job, self::stageText($job, self::bar($pct) . ' ' . fa((string) $pct) . L("٪\n", "%\n") . $line2));
                    $last = $now;
                } elseif (preg_match('/^\[(Merger|ExtractAudio|VideoConvertor|FixupM3u8|EmbedThumbnail)\]/', $line) && $stage === '') {
                    $stage = 'post';
                    self::show($job, self::stageText($job, L('⚙️ دارم آماده‌اش می‌کنم...', '⚙️ Preparing it...')));
                    $last = $now;
                }
            });

            $file = self::pickFile($dir);
            if ($file === null) {
                logError('dl', "{$job['site']} {$fmt} failed (exit {$res['code']}): " . self::lastLine($res['err']));
                self::show($job, self::explain($res['err'] . "\n" . $res['out'], $res['code']), self::retryKeyboard($token, $fmt));
                return;
            }
            $size = (int) filesize($file);
            if ($size > $limit) {
                self::show($job, L('📦 حجمش ', '📦 Its size is ') . self::mb($size) . L(' شد و از سقف ', ', which is over the ') . self::mb($limit) . L(" بیشتره 😕\n", " limit 😕\n")
                    . ($fmt === 'mp3' ? '' : L('💡 «کم‌حجم» یا «فقط صدا» رو امتحان کن.', '💡 Try “Low size” or “Audio only”.')), self::retryKeyboard($token, $fmt));
                return;
            }

            self::show($job, self::stageText($job, L('📤 دارم می‌فرستمش... (', '📤 Sending it... (') . self::mb($size) . ')'));
            if (empty($job['imid'])) {
                $tg->action($chat, $fmt === 'mp3' ? 'upload_voice' : 'upload_video');
            }
            $meta = $fmt === 'mp3' ? [] : self::videoMeta($file);
            $sent = $size > self::BOT_API_BYTES
                ? self::uploadMtproto($job, $fmt, $file, $meta, $dir)
                : self::upload($job, $fmt, $file, $meta);
            if ($sent === null || (!empty($job['imid']) && !self::toInline($job, $sent))) {
                if ($sent !== null && !empty($sent['msg'])) {
                    $tg->call('deleteMessage', ['chat_id' => $chat, 'message_id' => (int) $sent['msg']], 8);
                }
                self::show($job, L('❌ آپلود تو تلگرام نشد؛', '❌ Upload to Telegram failed;') . "\n" . L('یه بار دیگه امتحان کن.', 'please try again.'), self::retryKeyboard($token, $fmt));
                return;
            }
            $stored = $sent;
            unset($stored['msg']);
            Store::set('dl_files', self::cacheKey($job['url'], $fmt), $stored);
            self::charge((int) $job['owner']);
            Users::hit('dl:' . $job['site'] . (!empty($job['imid']) ? ':guest' : ''));
            if (!empty($job['imid'])) {
                if (!empty($sent['msg']) && env('DL_STORE_CHAT', '') === '') {
                    $tg->call('deleteMessage', ['chat_id' => $chat, 'message_id' => (int) $sent['msg']], 8);
                }
            } else {
                $tg->call('deleteMessage', ['chat_id' => $chat, 'message_id' => $card], 8);
            }
        } catch (\Throwable $e) {
            logError('dl', 'worker: ' . $e->getMessage());
            self::show($job, L('❌ یه مشکلی پیش اومد؛', '❌ Something went wrong;') . "\n" . L('یه بار دیگه امتحان کن.', 'please try again.'), self::retryKeyboard($token, $fmt));
        } finally {
            self::rmrf($dir);
            Store::delete('dl_busy', (string) $job['owner']);
            if ($slot) {
                flock($slot, LOCK_UN);
                fclose($slot);
            }
        }
    }

    public static function albumFiles(string $dir): array
    {
        $files = (array) glob($dir . '/*');
        natsort($files);
        $out = [];
        foreach ($files as $f) {
            $ext = strtolower(pathinfo((string) $f, PATHINFO_EXTENSION));
            if (!is_file($f) || str_contains((string) $f, '.part') || (int) filesize($f) <= 0) {
                continue;
            }
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)) {
                $out[] = ['photo', $f];
            } elseif (in_array($ext, ['mp4', 'mov', 'm4v', 'webm', 'mkv'], true)) {
                $out[] = ['video', $f];
            }
        }
        return $out;
    }

    public static function cleanUrl(string $url, string $site): string
    {
        if ($site !== 'instagram') {
            return $url;
        }
        return rtrim(preg_replace('/([?&])img_index=\d+&?/', '$1', $url) ?? $url, '?&');
    }

    private static function albumYtdlp(array $job, string $url, string $outDir, int $limit, int $total, array $urls = []): array
    {
        $last = 0.0;
        return self::run(array_merge([self::bin()], self::commonArgs(), [
            '-f', $limit > self::BOT_API_BYTES ? 'bv*+ba/b' : 'bv*[filesize<45M]+ba[filesize<5M]/b[filesize<50M]/bv*+ba/b', '-S', 'res,vcodec:h264,ext:mp4:m4a', '--merge-output-format', 'mp4',
            '--no-playlist', '--playlist-items', '1:' . self::ALBUM_MAX, '--ignore-errors', '--newline', '--no-warnings', '--no-mtime', '--restrict-filenames',
            '--socket-timeout', '20', '--retries', '3', '--fragment-retries', '3', '--concurrent-fragments', '4',
            '--max-filesize', (int) ($limit / 1048576) . 'M',
            '-o', $outDir . ($urls !== [] ? '/%(autonumber)02d_%(id).30s.%(ext)s' : '/%(playlist_index)02d_%(id).30s.%(ext)s'),
            ...($urls !== [] ? $urls : [$url]),
        ]), self::jobTime() - 60, static function (string $line) use ($job, $total, &$last): void {
            if (preg_match('/Downloading item (\\d+) of (\\d+)/', $line, $m) && microtime(true) - $last >= 2.5) {
                $n = min((int) $m[2], self::ALBUM_MAX);
                self::show($job, self::stageText($job, L('📦 فایل ', '📦 File ') . fa($m[1]) . L(' از ', ' of ') . fa((string) $n) . "\n" . self::bar((int) floor(((int) $m[1] - 1) / max(1, $n) * 100)) . ' ' . fa((string) (int) floor(((int) $m[1] - 1) / max(1, $n) * 100)) . L('٪', '%')));
                $last = microtime(true);
            }
        });
    }

    private static function albumVideos(array $job, string $url, string $dir, int $limit, int $total): array
    {
        $sub = $dir . '/v';
        @mkdir($sub, 0775, true);
        $res    = self::albumYtdlp($job, $url, $sub, $limit, $total, array_values((array) ($job['vurls'] ?? [])));
        $videos = [];
        foreach (self::albumFiles($sub) as [$kind, $f]) {
            if ($kind === 'video') {
                $videos[] = $f;
            }
        }
        $pos = [];
        foreach (array_values((array) ($job['kinds'] ?? [])) as $i => $k) {
            if ($k === 'v') {
                $pos[] = $i + 1;
            }
        }
        $aligned = $videos !== [];
        foreach ($videos as $f) {
            if (!preg_match('/^(\d+)_/', basename($f), $m) || !in_array((int) $m[1], $pos, true)) {
                $aligned = false;
                break;
            }
        }
        foreach ($videos as $i => $f) {
            $n = $aligned ? (int) substr(basename($f), 0, (int) strpos(basename($f), '_')) : ($pos[$i] ?? 99);
            @rename($f, $dir . '/' . sprintf('%02d_v_', $n) . (string) preg_replace('/^\d+_/', '', basename($f)));
        }
        self::rmrf($sub);
        logInfo('dl', "{$job['site']} album videos via yt-dlp: files=" . count($videos) . ' aligned=' . ($aligned ? '1' : '0'));
        return $res;
    }

    private static function workAlbum(array $job, string $token, string $dir): void
    {
        $tg    = App::tg();
        $chat  = $job['chat'];
        $total = max(2, (int) ($job['count'] ?? 2));
        $limit = self::limit($job);
        $last  = 0.0;
        self::show($job, self::stageText($job, L('⏳ دارم ', '⏳ Fetching ') . fa((string) $total) . L(' تا فایل رو می‌گیرم...', ' files...')));
        $url   = self::cleanUrl((string) $job['url'], (string) $job['site']);
        $kinds = (array) ($job['kinds'] ?? []);
        $res   = ['code' => 1, 'out' => '', 'err' => ''];
        if (GalleryDl::supports((string) $job['site'])) {
            if ($kinds === [] || in_array('p', $kinds, true)) {
                $pp = [];
                foreach (array_values($kinds) as $i => $k) {
                    if ($k === 'p') {
                        $pp[] = $i + 1;
                    }
                }
                $res = GalleryDl::download($url, $dir, self::jobTime() - 60, $limit, self::ALBUM_MAX, true, $pp !== [] ? implode(',', $pp) : null);
                logInfo('dl', "{$job['site']} album photos via gallery-dl: files=" . count(self::albumFiles($dir)));
            }
            if ($kinds === [] || in_array('v', $kinds, true)) {
                $res = self::albumVideos($job, $url, $dir, $limit, $total);
            }
        }
        Photos::convertDir($dir);
        if (self::albumFiles($dir) === []) {
            $res = self::albumYtdlp($job, $url, $dir, $limit, $total);
        }

        $items   = [];
        $big     = [];
        $skipped = 0;
        foreach (self::albumFiles($dir) as [$kind, $f]) {
            $size = (int) filesize($f);
            if ($size > $limit) {
                $skipped++;
            } elseif ($size > self::BOT_API_BYTES || ($kind === 'photo' && $size > 10 * 1048576)) {
                $big[] = [$kind, $f];
            } else {
                $items[] = [$kind, $f];
            }
        }
        if (!$items && !$big) {
            logError('dl', "{$job['site']} album failed (exit {$res['code']}): " . self::lastLine($res['err']));
            self::show($job, self::explain($res['err'] . "\n" . $res['out'], $res['code']), self::retryKeyboard($token, 'all'));
            return;
        }

        self::show($job, self::stageText($job, L('📤 دارم می‌فرستمشون... (', '📤 Sending them... (') . fa((string) (count($items) + count($big))) . L(' تا)', ' files)')));
        $tg->action($chat, 'upload_document');
        $reply = $job['reply_to'] ? ['message_id' => (int) $job['reply_to'], 'allow_sending_without_reply' => true] : null;
        $cap   = self::caption($job);
        $ok    = false;

        $rest  = $items;
        $first = true;
        if (count($items) >= 2) {
            $rest = [];
            foreach (array_chunk($items, self::GROUP_MAX) as $chunk) {
                if (count($chunk) < 2) {
                    array_push($rest, ...$chunk);
                    continue;
                }
                $media  = [];
                $params = ['chat_id' => $chat, 'reply_parameters' => $reply];
                foreach ($chunk as $i => [$kind, $f]) {
                    $m = ['type' => $kind, 'media' => "attach://f{$i}"];
                    if ($kind === 'video') {
                        $meta = self::videoMeta($f);
                        $m   += ['supports_streaming' => true, 'width' => $meta['width'] ?: null, 'height' => $meta['height'] ?: null, 'duration' => $meta['duration'] ?: null];
                        $m    = array_filter($m, static fn($v) => $v !== null);
                    }
                    if ($i === 0 && $first) {
                        $m += ['caption' => $cap, 'parse_mode' => 'HTML'];
                    }
                    $media[]         = $m;
                    $params["f{$i}"] = new CURLFile($f, $kind === 'photo' ? 'image/jpeg' : 'video/mp4', basename($f));
                }
                $params['media'] = $media;
                $r = $tg->call('sendMediaGroup', $params, 300);
                if (!empty($r['ok'])) {
                    $ok    = true;
                    $first = false;
                } else {
                    array_push($rest, ...$chunk);
                }
            }
        }
        foreach ($rest as $i => [$kind, $f]) {
            $r = $tg->call($kind === 'photo' ? 'sendPhoto' : 'sendVideo', [
                'chat_id'          => $chat,
                $kind              => new CURLFile($f, $kind === 'photo' ? 'image/jpeg' : 'video/mp4', basename($f)),
                'caption'          => $first ? $cap : null,
                'parse_mode'       => 'HTML',
                'reply_parameters' => $reply,
            ], 300);
            if (!empty($r['ok'])) {
                $ok    = true;
                $first = false;
            }
        }
        foreach ($big as $i => [$kind, $f]) {
            $size = (int) filesize($f);
            $sent = null;
            if ($size > self::BOT_API_BYTES) {
                $sent = self::uploadMtproto($job, 'hd', $f, $kind === 'video' ? self::videoMeta($f) : [], $dir);
            } else {
                $r    = $tg->call('sendDocument', [
                    'chat_id'          => $chat,
                    'document'         => new CURLFile($f, 'application/octet-stream', basename($f)),
                    'caption'          => !$ok && $i === 0 && !$items ? $cap : null,
                    'parse_mode'       => 'HTML',
                    'reply_parameters' => $reply,
                ], 300);
                $sent = !empty($r['ok']) ? $r : null;
            }
            if ($sent !== null) {
                $ok = true;
            } else {
                $skipped++;
            }
        }
        if (!$ok) {
            self::show($job, L('❌ آپلود تو تلگرام نشد؛', '❌ Upload to Telegram failed;') . "\n" . L('یه بار دیگه امتحان کن.', 'please try again.'), self::retryKeyboard($token, 'all'));
            return;
        }
        if ($skipped > 0) {
            $tg->send($chat, '📦 ' . fa((string) $skipped) . L(' تا از فایل‌ها از سقف حجم (', ' of the files exceeded the size limit (') . self::limitText() . L(') بیشتر بود یا آپلودشون نشد.', ') or failed to upload.'), ['reply_parameters' => $reply]);
        }
        self::charge((int) $job['owner']);
        Users::hit('dl:' . $job['site'] . ':album');
        $tg->call('deleteMessage', ['chat_id' => $chat, 'message_id' => (int) $job['card']], 8);
    }

    private static function formatArgs(string $fmt, bool $small = false, bool $vertical = false): array
    {
        if ($fmt === 'mp3') {
            return ['-f', 'ba[filesize<45M]/ba[filesize_approx<45M]/ba/b', '-x', '--audio-format', 'mp3', '--audio-quality', '5',
                '--embed-metadata', '--embed-thumbnail', '--convert-thumbnails', 'jpg'];
        }
        $h = ['sd' => 360, 'hd' => 720, 'fhd' => 1080][$fmt] ?? (preg_match('/^v(\d{3,4})$/', $fmt, $vm) ? (int) $vm[1] : 720);
        $v = '[' . ($vertical ? 'width' : 'height') . '<=?' . ($h + 40) . ']';
        if (self::mtproto() && !$small) {
            $sel = "bv*{$v}+ba/b{$v}/bv*+ba/b";
        } else {
            $sel = "bv*{$v}[filesize<45M]+ba[filesize<5M]/bv*{$v}[filesize_approx<45M]+ba/b{$v}[filesize<50M]/b{$v}[filesize_approx<50M]/bv*{$v}+ba/b{$v}/bv*+ba/b";
        }
        return ['-f', $sel, '-S', 'res,vcodec:h264,ext:mp4:m4a', '--merge-output-format', 'mp4', '--remux-video', 'mp4'];
    }

    public static function cookiesPath(): string
    {
        $saved = NULLINI_DATA . '/cookies.txt';
        if (!is_file($saved) || filesize($saved) === 0) {
            $kept = Store::get('cfg', 'cookies_txt');
            if (is_string($kept) && $kept !== '') {
                @mkdir(NULLINI_DATA, 0775, true);
                if (@file_put_contents($saved, $kept, LOCK_EX) !== false) {
                    @chmod($saved, 0600);
                }
            }
        }
        return is_file($saved) && filesize($saved) > 0 ? $saved : NULLINI_ROOT . '/cookies.txt';
    }

    public static function normalizeCookies(string $raw): array
    {
        $raw   = preg_replace('/^\xEF\xBB\xBF/', '', $raw) ?? $raw;
        $raw   = str_replace(["\r\n", "\r"], "\n", $raw);
        $lines = ['# Netscape HTTP Cookie File'];
        $n     = 0;
        $insta = false;
        foreach (explode("\n", $raw) as $line) {
            $t = ltrim($line);
            if ($t === '' || ($t[0] === '#' && !str_starts_with($t, '#HttpOnly_'))) {
                continue;
            }
            $p = explode("\t", $t);
            if (count($p) < 7) {
                $p = preg_split('/\s+/', trim($t), 7) ?: [];
            }
            if (count($p) < 7) {
                continue;
            }
            if (count($p) > 7) {
                $p = [$p[0], $p[1], $p[2], $p[3], $p[4], $p[5], implode("\t", array_slice($p, 6))];
            }
            $p[1] = strtoupper(trim($p[1]));
            $p[3] = strtoupper(trim($p[3]));
            if (!in_array($p[1], ['TRUE', 'FALSE'], true) || !in_array($p[3], ['TRUE', 'FALSE'], true)
                || preg_match('/^-?\d+(\.\d+)?$/', trim($p[4])) !== 1) {
                continue;
            }
            $p[4]    = (string) max(0, (int) trim($p[4]));
            $lines[] = implode("\t", $p);
            $n++;
            if ($p[5] === 'sessionid' && trim($p[6]) !== '' && str_contains(strtolower($p[0]), 'instagram.com')) {
                $insta = true;
            }
        }
        return ['text' => implode("\n", $lines) . "\n", 'count' => $n, 'insta' => $insta];
    }

    public static function saveCookies(string $raw): array
    {
        if (str_contains($raw, "\0") || strlen($raw) > 2 * 1048576) {
            return ['error' => L('این فایل کوکی نیست یا خیلی بزرگه.', 'This isn’t a cookie file or it’s too large.')];
        }
        $c = self::normalizeCookies($raw);
        if ($c['count'] === 0) {
            return ['error' => L("فرمت فایل درست نیست؛\nباید کوکی‌ها با فرمت Netscape (cookies.txt) باشن.", "Invalid file format;\nthe cookies must be in Netscape format (cookies.txt).")];
        }
        $path = NULLINI_DATA . '/cookies.txt';
        @mkdir(NULLINI_DATA, 0775, true);
        if (@file_put_contents($path, $c['text'], LOCK_EX) === false) {
            return ['error' => L('نتونستم فایل رو ذخیره کنم.', 'Couldn’t save the file.')];
        }
        @chmod($path, 0600);
        Store::set('cfg', 'cookies_txt', $c['text']);
        return ['count' => $c['count'], 'insta' => $c['insta']];
    }

    public static function cookiesInfo(): array
    {
        $p = self::cookiesPath();
        if (!is_file($p) || filesize($p) === 0) {
            return [];
        }
        $n = 0;
        foreach (explode("\n", (string) file_get_contents($p)) as $line) {
            $line = trim($line);
            if ($line !== '' && ($line[0] !== '#' || str_starts_with($line, '#HttpOnly_')) && count(explode("\t", $line)) >= 7) {
                $n++;
            }
        }
        return ['count' => $n, 'at' => (int) filemtime($p), 'saved' => $p === NULLINI_DATA . '/cookies.txt'];
    }

    public static function cookiesFile(): ?string
    {
        $src = self::cookiesPath();
        $jar = is_file($src) && filesize($src) > 0 ? rtrim((string) file_get_contents($src)) . "\n" : '';
        if ($jar === '') {
            return null;
        }
        if (preg_match('/^#( Netscape)? HTTP Cookie File/', $jar) !== 1) {
            $jar = "# Netscape HTTP Cookie File\n" . $jar;
        }
        $tmp = self::TMP . '/cookies-' . getmypid() . '.txt';
        @mkdir(self::TMP, 0775, true);
        return @file_put_contents($tmp, $jar) !== false ? $tmp : null;
    }

    public static function exec(array $args, int $timeout): array
    {
        return self::run($args, $timeout);
    }

    private static function commonArgs(): array
    {
        $args = ['--ignore-config', '--no-color'];
        if (($jar = self::cookiesFile()) !== null) {
            $args[] = '--cookies';
            $args[] = $jar;
        }
        $proxy = (string) env('DL_PROXY', '');
        if ($proxy !== '') {
            $args[] = '--proxy';
            $args[] = $proxy;
        }
        return $args;
    }

    private static function acquireSlot(array $job)
    {
        @mkdir(self::TMP, 0775, true);
        $told = false;
        for ($wait = 0; $wait < 120; $wait += 2) {
            for ($i = 0; $i < self::SLOTS; $i++) {
                $fh = @fopen(self::TMP . "/slot{$i}.lock", 'c');
                if ($fh && flock($fh, LOCK_EX | LOCK_NB)) {
                    return $fh;
                }
                if ($fh) {
                    fclose($fh);
                }
            }
            if (!$told) {
                self::show($job, self::stageText($job, L('🕐 تو صفم؛ چند لحظه صبر کن...', '🕐 You’re in the queue; wait a moment...')));
                $told = true;
            }
            sleep(2);
        }
        return null;
    }

    private static function pickFile(string $dir): ?string
    {
        $best = null;
        $size = 0;
        foreach ((array) glob($dir . '/*') as $f) {
            $ext = strtolower(pathinfo((string) $f, PATHINFO_EXTENSION));
            if (!is_file($f) || in_array($ext, ['part', 'ytdl', 'jpg', 'jpeg', 'png', 'webp', 'json', 'temp', 'txt'], true) || str_contains((string) $f, '.part')) {
                continue;
            }
            $s = (int) filesize($f);
            if ($s > $size) {
                $best = $f;
                $size = $s;
            }
        }
        return $size > 0 ? $best : null;
    }

    private static function upload(array $job, string $fmt, string $file, array $meta = []): ?array
    {
        $tg      = App::tg();
        $caption = self::caption($job);
        $reply   = $job['reply_to'] ? ['message_id' => (int) $job['reply_to'], 'allow_sending_without_reply' => true] : null;
        $ext     = strtolower(pathinfo($file, PATHINFO_EXTENSION));

        if ($fmt === 'mp3') {
            $r = $tg->call('sendAudio', [
                'chat_id'          => $job['chat'],
                'audio'            => new CURLFile($file, $ext === 'mp3' ? 'audio/mpeg' : 'audio/mp4', self::fileName($job, $ext)),
                'title'            => mb_substr($job['title'], 0, 64),
                'performer'        => $job['uploader'] !== '' ? mb_substr($job['uploader'], 0, 64) : null,
                'duration'         => $job['duration'] ?: null,
                'caption'          => $caption,
                'parse_mode'       => 'HTML',
                'reply_parameters' => $reply,
            ], 300);
            $id = $r['result']['audio']['file_id'] ?? $r['result']['document']['file_id'] ?? null;
            return $id ? ['type' => 'audio', 'file_id' => $id, 'msg' => (int) ($r['result']['message_id'] ?? 0)] : null;
        }

        $viaStore = '';
        if (empty($job['imid'])) {
            $viaStore = (string) App::cfg('storage_chat', '');
            $viaStore = $viaStore !== '' ? $viaStore : (string) (App::cfg('admins', [])[0] ?? '');
        }
        $r = $tg->call('sendVideo', [
            'chat_id'            => $viaStore !== '' ? $viaStore : $job['chat'],
            'video'              => new CURLFile($file, 'video/mp4', self::fileName($job, $ext)),
            'duration'           => ($meta['duration'] ?? 0) ?: ($job['duration'] ?: null),
            'width'              => ($meta['width'] ?? 0) ?: null,
            'height'             => ($meta['height'] ?? 0) ?: null,
            'supports_streaming' => true,
            'caption'            => $caption,
            'parse_mode'         => 'HTML',
            'reply_parameters'   => $reply,
        ], 300);
        $id = $r['result']['video']['file_id'] ?? null;
        if ($id && $viaStore !== '') {
            if (env('DL_STORE_CHAT', '') === '' && !empty($r['result']['message_id'])) {
                $tg->call('deleteMessage', ['chat_id' => $viaStore, 'message_id' => (int) $r['result']['message_id']], 8);
            }
            $rr = Rich::sendVideo($job['chat'], self::caption($job, true), (string) $id, $job['reply_to'] ? (int) $job['reply_to'] : null);
            if (empty($rr['ok'])) {
                logWarn('dl', 'rich video send failed: ' . (string) ($rr['description'] ?? ''));
                return null;
            }
            return ['type' => 'video', 'file_id' => $id, 'msg' => 0];
        }
        if ($id) {
            return ['type' => 'video', 'file_id' => $id, 'msg' => (int) ($r['result']['message_id'] ?? 0)];
        }
        $id = $r['result']['document']['file_id'] ?? $r['result']['animation']['file_id'] ?? null;
        if ($id && $viaStore !== '' && !empty($r['result']['message_id'])) {
            $cp = $tg->call('copyMessage', [
                'chat_id'          => $job['chat'],
                'from_chat_id'     => $viaStore,
                'message_id'       => (int) $r['result']['message_id'],
                'caption'          => $caption,
                'parse_mode'       => 'HTML',
                'reply_parameters' => $reply,
            ], 60);
            if (env('DL_STORE_CHAT', '') === '') {
                $tg->call('deleteMessage', ['chat_id' => $viaStore, 'message_id' => (int) $r['result']['message_id']], 8);
            }
            return !empty($cp['ok']) ? ['type' => isset($r['result']['animation']) ? 'animation' : 'document', 'file_id' => $id, 'msg' => 0] : null;
        }
        if ($id) {
            return ['type' => isset($r['result']['animation']) ? 'animation' : 'document', 'file_id' => $id, 'msg' => (int) ($r['result']['message_id'] ?? 0)];
        }
        $r  = $tg->call('sendDocument', [
            'chat_id'          => $job['chat'],
            'document'         => new CURLFile($file, 'application/octet-stream', self::fileName($job, $ext)),
            'caption'          => $caption,
            'parse_mode'       => 'HTML',
            'reply_parameters' => $reply,
        ], 300);
        $id = $r['result']['document']['file_id'] ?? null;
        return $id ? ['type' => 'document', 'file_id' => $id, 'msg' => (int) ($r['result']['message_id'] ?? 0)] : null;
    }

    private static function videoMeta(string $file): array
    {
        $r = self::run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height:format=duration', '-of', 'json', $file], 30);
        $j = json_decode($r['out'], true);
        return [
            'width'    => (int) ($j['streams'][0]['width'] ?? 0),
            'height'   => (int) ($j['streams'][0]['height'] ?? 0),
            'duration' => (int) round((float) ($j['format']['duration'] ?? 0)),
        ];
    }

    private static function uploadMtproto(array $job, string $fmt, string $file, array $meta, string $dir): ?array
    {
        if (!self::mtproto()) {
            return null;
        }
        $tg    = App::tg();
        $ext   = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        $kind  = $fmt === 'mp3' ? 'audio' : ($ext === 'mp4' ? 'video' : 'document');
        $thumb = '';
        if ($kind === 'video') {
            $thumb = $dir . '/thumb.jpg';
            self::run(['ffmpeg', '-y', '-v', 'error', '-ss', '1', '-i', $file, '-frames:v', '1', '-vf', 'scale=320:-2', '-q:v', '4', $thumb], 40);
            if (!is_file($thumb)) {
                $thumb = '';
            }
        }
        $viaStore = '';
        if ($kind === 'video' && empty($job['imid'])) {
            $viaStore = (string) App::cfg('storage_chat', '');
            $viaStore = $viaStore !== '' ? $viaStore : (string) (App::cfg('admins', [])[0] ?? '');
        }
        $job2 = [
            'session_file' => NULLINI_DATA . '/mtproto' . (App::botIndex() === 0 ? '' : (string) App::botIndex()) . '.session',
            'api_id'       => self::apiId(),
            'api_hash'     => self::apiHash(),
            'bot_token'    => $tg->token(),
            'test'         => App::botIndex() === 2 ? ['dc' => (int) env('TEST_DC_ID', 2), 'ip' => (string) env('TEST_DC_IP', '149.154.167.40'), 'port' => (int) env('TEST_DC_PORT', 443)] : null,
            'chat'         => $viaStore !== '' ? (int) $viaStore : (int) $job['chat'],
            'reply_to'     => $viaStore !== '' ? 0 : (int) $job['reply_to'],
            'file'         => $file,
            'name'         => self::fileName($job, $ext),
            'kind'         => $kind,
            'mime'         => $kind === 'audio' ? ($ext === 'mp3' ? 'audio/mpeg' : 'audio/mp4') : ($kind === 'video' ? 'video/mp4' : null),
            'thumb'        => $thumb,
            'caption'      => self::caption($job),
            'duration'     => ($meta['duration'] ?? 0) ?: $job['duration'],
            'width'        => $meta['width'] ?? 0,
            'height'       => $meta['height'] ?? 0,
            'title'        => mb_substr($job['title'], 0, 64),
            'performer'    => mb_substr($job['uploader'], 0, 64),
        ];
        $last = 0.0;
        $out  = null;
        $res  = self::run(['python3', NULLINI_ROOT . '/bin/mtup.py'], self::jobTime() - 120, static function (string $line) use ($tg, $job, &$last, &$out): void {
            $j = json_decode($line, true);
            if (!is_array($j)) {
                return;
            }
            if (isset($j['ok'])) {
                $out = $j;
                return;
            }
            if (isset($j['p'], $j['t']) && microtime(true) - $last >= 3.5) {
                $pct = $j['t'] > 0 ? (int) floor($j['p'] / $j['t'] * 100) : 0;
                self::show($job, self::stageText($job, '📤 ' . self::bar($pct) . ' ' . fa((string) $pct) . L("٪\n📦 ", "%\n📦 ") . self::mb((float) $j['p']) . L(' از ', ' of ') . self::mb((float) $j['t'])));
                $last = microtime(true);
            }
        }, ['NL_JOB' => json_encode($job2, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
        if (empty($out['ok']) || empty($out['msg_id'])) {
            logError('dl', 'mtproto upload failed (exit ' . $res['code'] . '): ' . (string) ($out['error'] ?? self::lastLine($res['err'])));
            return null;
        }
        if ($viaStore !== '') {
            $f   = $tg->call('forwardMessage', ['chat_id' => $viaStore, 'from_chat_id' => $viaStore, 'message_id' => (int) $out['msg_id'], 'disable_notification' => true], 60);
            $m   = (array) ($f['result'] ?? []);
            $fid = (string) ($m['video']['file_id'] ?? '');
            if (env('DL_STORE_CHAT', '') === '') {
                $tg->call('deleteMessage', ['chat_id' => $viaStore, 'message_id' => (int) $out['msg_id']], 8);
                if (!empty($m['message_id'])) {
                    $tg->call('deleteMessage', ['chat_id' => $viaStore, 'message_id' => (int) $m['message_id']], 8);
                }
            }
            if ($fid === '') {
                logError('dl', 'mtproto video: no file_id after forward');
                return null;
            }
            $rr = Rich::sendVideo($job['chat'], self::caption($job, true), $fid, $job['reply_to'] ? (int) $job['reply_to'] : null);
            if (empty($rr['ok'])) {
                logWarn('dl', 'rich video send failed: ' . (string) ($rr['description'] ?? ''));
                return null;
            }
            return ['type' => 'video', 'file_id' => $fid, 'msg' => 0];
        }
        return ['type' => 'copy', 'chat' => $job['chat'], 'msg' => (int) $out['msg_id']];
    }

    private static function toInline(array $job, array $c): bool
    {
        $fwd = 0;
        if (($c['type'] ?? '') === 'copy' && !empty($c['msg']) && isset($c['chat'])) {
            $f   = App::tg()->call('forwardMessage', ['chat_id' => $job['chat'], 'from_chat_id' => $c['chat'], 'message_id' => (int) $c['msg'], 'disable_notification' => true], 60);
            $m   = (array) ($f['result'] ?? []);
            $fwd = (int) ($m['message_id'] ?? 0);
            $c   = ['type' => '', 'file_id' => ''];
            foreach (['video', 'animation', 'audio', 'document'] as $k) {
                if (!empty($m[$k]['file_id'])) {
                    $c = ['type' => $k, 'file_id' => (string) $m[$k]['file_id']];
                    break;
                }
            }
        }
        if (!in_array($c['type'] ?? '', ['video', 'audio', 'animation', 'document'], true) || empty($c['file_id'])) {
            if ($fwd > 0) {
                App::tg()->call('deleteMessage', ['chat_id' => $job['chat'], 'message_id' => $fwd], 8);
            }
            return false;
        }
        $r = $c['type'] === 'video'
            ? Rich::editInlineVideo((string) $job['imid'], self::caption($job, true), (string) $c['file_id'])
            : App::tg()->call('editMessageMedia', [
                'inline_message_id' => $job['imid'],
                'media'             => ['type' => $c['type'], 'media' => $c['file_id'], 'caption' => self::caption($job), 'parse_mode' => 'HTML'],
            ], 30);
        if ($fwd > 0) {
            App::tg()->call('deleteMessage', ['chat_id' => $job['chat'], 'message_id' => $fwd], 8);
        }
        return !empty($r['ok']);
    }

    private static function sendCached(array $job, array $c): bool
    {
        if (($c['type'] ?? '') === 'copy') {
            $r = App::tg()->call('copyMessage', [
                'chat_id'          => $job['chat'],
                'from_chat_id'     => $c['chat'],
                'message_id'       => (int) $c['msg'],
                'reply_parameters' => $job['reply_to'] ? ['message_id' => (int) $job['reply_to'], 'allow_sending_without_reply' => true] : null,
            ], 20);
            return !empty($r['ok']);
        }
        $method = ['video' => 'sendVideo', 'audio' => 'sendAudio', 'animation' => 'sendAnimation', 'document' => 'sendDocument'][$c['type'] ?? ''] ?? null;
        if ($method === null || empty($c['file_id'])) {
            return false;
        }
        if ($c['type'] === 'video') {
            $r = Rich::sendVideo($job['chat'], self::caption($job, true), (string) $c['file_id'], $job['reply_to'] ? (int) $job['reply_to'] : null);
            return !empty($r['ok']);
        }
        $r = App::tg()->call($method, [
            'chat_id'          => $job['chat'],
            $c['type']         => $c['file_id'],
            'caption'          => self::caption($job),
            'parse_mode'       => 'HTML',
            'reply_parameters' => $job['reply_to'] ? ['message_id' => (int) $job['reply_to'], 'allow_sending_without_reply' => true] : null,
        ], 30);
        return !empty($r['ok']);
    }

    public static function probe(string $url, bool $multi = false): array
    {
        $res = self::run(array_merge([self::bin()], self::commonArgs(), [
            '-J', '--no-playlist', '--no-warnings', '--skip-download', '--socket-timeout', '15', '--playlist-items', $multi ? '1:' . self::ALBUM_MAX : '1', $url,
        ]), 60);
        $info = json_decode($res['out'], true);
        if (!is_array($info)) {
            logError('dl', 'probe ' . parse_url($url, PHP_URL_HOST) . ' failed (exit ' . $res['code'] . '): ' . self::lastLine($res['err']));
            $ckPath = self::cookiesPath();
            $ck     = is_file($ckPath) ? self::normalizeCookies((string) file_get_contents($ckPath)) : ['count' => 0, 'insta' => false];
            logWarn('dl', 'cookies at probe: file=' . (is_file($ckPath) ? $ckPath : 'none') . ' count=' . $ck['count'] . ' sessionid=' . ($ck['insta'] ? '1' : '0'));
            return ['error' => self::explain($res['err'], $res['code'])];
        }
        if (($info['_type'] ?? '') === 'playlist') {
            $entries = array_values(array_filter((array) ($info['entries'] ?? []), 'is_array'));
            $first   = $entries[0] ?? null;
            if (!is_array($first)) {
                return ['error' => L('🤷 تو این لینک چیزی برای دانلود پیدا نکردم.', '🤷 I couldn’t find anything to download in this link.')];
            }
            $first['title'] ??= $info['title'] ?? '';
            $first['uploader'] ??= $info['uploader'] ?? null;
            $first['webpage_url'] = (string) ($info['webpage_url'] ?? $first['webpage_url'] ?? $url);
            $first['thumbnail'] ??= $info['thumbnail'] ?? null;
            if ($multi && count($entries) > 1) {
                $first['count'] = count($entries);
                $first['kinds'] = array_map([self::class, 'entryKind'], $entries);
            }
            $info = $first;
        }
        $slim = array_intersect_key($info, array_flip(['title', 'uploader', 'channel', 'uploader_id', 'duration', 'thumbnail', 'webpage_url',
            'is_live', 'live_status', 'width', 'height', 'vcodec', 'count', 'kinds']));
        $slim['formats'] = array_map(static fn($f) => array_intersect_key((array) $f, array_flip(['height', 'width', 'vcodec', 'acodec', 'filesize', 'filesize_approx', 'tbr', 'vbr', 'abr', 'fps', 'ext', 'protocol', 'format_note', 'dynamic_range'])),
            array_values((array) ($info['formats'] ?? [])));
        if ((int) ($slim['width'] ?? 0) <= 0 || (int) ($slim['height'] ?? 0) <= 0) {
            $area = 0;
            foreach ($slim['formats'] as $f) {
                $fw = (int) ($f['width'] ?? 0);
                $fh = (int) ($f['height'] ?? 0);
                if ($fw > 0 && $fh > 0 && $fw * $fh > $area) {
                    $area           = $fw * $fh;
                    $slim['width']  = $fw;
                    $slim['height'] = $fh;
                }
            }
        }
        return ['info' => $slim];
    }

    public static function entryKind(array $e): string
    {
        $ext = strtolower((string) ($e['ext'] ?? ''));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)) {
            return 'p';
        }
        if (in_array($ext, ['mp4', 'mov', 'm4v', 'webm', 'mkv'], true) || !empty($e['duration'])) {
            return 'v';
        }
        foreach ((array) ($e['formats'] ?? []) as $f) {
            if (($f['vcodec'] ?? 'none') !== 'none') {
                return 'v';
            }
        }
        return 'p';
    }

    private static function run(array $args, int $timeout, ?callable $onLine = null, array $env = []): array
    {
        $cmd  = array_merge(['timeout', '-k', '5', (string) $timeout], $args);
        $proc = proc_open($cmd, [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes, null, $env + ['HOME' => '/tmp', 'PATH' => '/usr/local/bin:/usr/bin:/bin', 'LANG' => 'C.UTF-8']);
        if (!is_resource($proc)) {
            return ['code' => -1, 'out' => '', 'err' => 'proc_open failed'];
        }
        stream_set_blocking($pipes[1], false);
        stream_set_blocking($pipes[2], false);
        $out = $err = $buf = '';
        $end = time() + $timeout + 15;
        while (true) {
            $r = [$pipes[1], $pipes[2]];
            $w = $e = null;
            if (@stream_select($r, $w, $e, 1) === false) {
                break;
            }
            foreach ($r as $p) {
                $chunk = (string) fread($p, 65536);
                if ($p === $pipes[1]) {
                    $out .= $chunk;
                    if ($onLine && $chunk !== '') {
                        $buf .= $chunk;
                        while (($nl = strpos($buf, "\n")) !== false) {
                            $line = rtrim(substr($buf, 0, $nl), "\r");
                            $buf  = substr($buf, $nl + 1);
                            $onLine($line);
                        }
                        if (strlen($out) > 2 * 1048576) {
                            $out = substr($out, -65536);
                        }
                    }
                } else {
                    $err = substr($err . $chunk, -65536);
                }
            }
            if (feof($pipes[1]) && feof($pipes[2])) {
                break;
            }
            if (time() > $end) {
                proc_terminate($proc, 9);
                break;
            }
        }
        fclose($pipes[1]);
        fclose($pipes[2]);
        $code = proc_close($proc);
        return ['code' => $code, 'out' => $out, 'err' => $err];
    }

    public static function explain(string $err, int $code = 1): string
    {
        $e = strtolower($err);
        return match (true) {
            $code === 124 || $code === 137                                         => L('⌛️ سایت دیر جواب داد؛', '⌛️ The site took too long to respond;') . "\n" . L('یه‌کم دیگه دوباره امتحان کن.', 'please try again in a bit.'),
            str_contains($e, 'confirm you') && str_contains($e, 'bot')              => L("🤖 یوتیوب سرور رو ربات حساب کرد و اجازه نداد 😕\nیه‌کم دیگه دوباره امتحان کن.", "🤖 YouTube treated the server as a bot and blocked it 😕\nplease try again in a bit."),
            str_contains($e, 'larger than max-filesize') || str_contains($e, 'file is larger') => L('📦 حجمش از سقف ', '📦 Its size is over the ') . self::limitText() . L(" بیشتره 😕\n💡 «کم‌حجم» یا «فقط صدا» رو امتحان کن.", " limit 😕\n💡 Try “Low size” or “Audio only”."),
            str_contains($e, 'private') || str_contains($e, 'login') || str_contains($e, 'log in')
                || str_contains($e, 'sign in') || str_contains($e, 'cookies')            => L('🔒 این پست خصوصیه یا برای دیدنش باید لاگین کرد.', '🔒 This post is private or you need to log in to view it.'),
            str_contains($e, 'age') && str_contains($e, 'restrict')                 => L("🔞 این ویدیو محدودیت سنی داره و\nبدون لاگین باز نمی‌شه.", "🔞 This video is age-restricted and\ncan’t be opened without logging in."),
            str_contains($e, 'no video formats') || str_contains($e, 'no media')
                || str_contains($e, 'there is no video')                             => L("🖼 این پست ویدیو یا صدا نداره\n(احتمالاً فقط عکسه).", "🖼 This post has no video or audio\n(probably photos only)."),
            str_contains($e, 'unavailable') || str_contains($e, '404') || str_contains($e, 'not found')
                || str_contains($e, 'removed') || str_contains($e, 'deleted')        => L('🚫 این محتوا در دسترس نیست یا پاک شده.', '🚫 This content is unavailable or has been deleted.'),
            str_contains($e, 'geo') || str_contains($e, 'country')                  => L('🌍 این محتوا تو منطقه‌ی سرور در دسترس نیست.', '🌍 This content isn’t available in the server’s region.'),
            str_contains($e, 'rate') && str_contains($e, 'limit') || str_contains($e, '429') => L('🐢 سایت گفت زیادی درخواست دادیم؛', '🐢 The site said we sent too many requests;') . "\n" . L('چند دقیقه دیگه امتحان کن.', 'try again in a few minutes.'),
            default                                                                => self::genericError(),
        };
    }

    private static function retryKeyboard(string $token, string $fmt): array
    {
        $rows = [[btn(L('🔁 دوباره', '🔁 Retry'), "dl:{$token}:{$fmt}", 'primary')]];
        if ($fmt === 'all') {
            $rows[] = [btn(L('✖️ بیخیال', '✖️ Cancel'), "dl:{$token}:x", null)];
            return ikb($rows);
        }
        if ($fmt !== 'mp3') {
            $rows[0][] = btn(L('🎵 فقط صدا', '🎵 Audio only'), "dl:{$token}:mp3", null);
        }
        if ($fmt !== 'mp3' && $fmt !== 'v360' && $fmt !== 'sd') {
            $rows[0][] = btn(L('🎬 کم‌حجم', '🎬 Low size'), "dl:{$token}:v360", null);
        }
        $rows[] = [btn(L('✖️ بیخیال', '✖️ Cancel'), "dl:{$token}:x", null)];
        return ikb($rows);
    }

    private static function stageText(array $job, string $status): string
    {
        return dirMark($job['title']) . '📥 <b>' . h(mb_substr($job['title'], 0, 3500)) . "</b>\n\n\u{200F}" . str_replace("\n", "\n\u{200F}", $status);
    }

    private static function caption(array $job, bool $long = false): string
    {
        $bot = App::botUsername();
        $d    = dirMark($job['title']);
        $head = $d . '🎬 <b>' . h(mb_substr($job['title'], 0, $long ? 3500 : 800)) . "</b>\n"
            . ($job['uploader'] !== '' ? $d . '👤 ' . bidi(h($job['uploader'])) . "\n" : '');
        return $head . "\n" . $d . "📥 <a href=\"https://t.me/{$bot}\">@{$bot}</a>";
    }

    private static function fileName(array $job, string $ext): string
    {
        $name = preg_replace('/[\\\\\/:*?"<>|\x00-\x1F]+/u', ' ', $job['title']) ?? 'nullini';
        $name = mbTrim(mb_substr($name, 0, 60));
        return ($name !== '' ? $name : 'nullini') . '.' . ($ext !== '' ? $ext : 'mp4');
    }

    public static function bar(int $pct): string
    {
        $n = (int) round(max(0, min(100, $pct)) / 10);
        return str_repeat('▰', $n) . str_repeat('▱', 10 - $n);
    }

    public static function mb(float $bytes): string
    {
        $mb = $bytes / 1048576;
        if ($mb >= 1024) {
            return fa(rtrim(rtrim(number_format($mb / 1024, 1, '.', ''), '0'), '.')) . L(' گیگ', ' GB');
        }
        return fa($mb >= 10 ? (string) round($mb) : number_format($mb, 1)) . L(' مگ', ' MB');
    }

    public static function clock(int $s): string
    {
        return $s >= 3600 ? sprintf('%d:%02d:%02d', intdiv($s, 3600), intdiv($s % 3600, 60), $s % 60) : sprintf('%d:%02d', intdiv($s, 60), $s % 60);
    }

    private static function cacheKey(string $url, string $fmt): string
    {
        return md5($url . '|' . $fmt . '|' . App::botIndex());
    }

    private static function quotaKey(int $uid): string
    {
        return $uid . ':' . date('Ymd');
    }

    private static function usedToday(int $uid): int
    {
        return (int) Store::get('dl_quota', self::quotaKey($uid), 0);
    }

    private static function lastLine(string $err): string
    {
        $lines = array_values(array_filter(array_map('trim', explode("\n", $err)), static fn($l) => $l !== ''));
        foreach (array_reverse($lines) as $l) {
            if (stripos($l, 'ERROR') !== false) {
                return mb_substr($l, 0, 300);
            }
        }
        return mb_substr((string) end($lines), 0, 300);
    }

    private static function rmrf(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        foreach ((array) glob($dir . '/{,.}[!.]*', GLOB_BRACE) as $f) {
            is_dir($f) ? self::rmrf($f) : @unlink($f);
        }
        @rmdir($dir);
    }

    public static function cleanupTmp(): void
    {
        foreach ((array) glob(self::TMP . '/*') as $f) {
            if (is_dir($f) && time() - (int) @filemtime($f) > self::jobTime() + 60) {
                self::rmrf($f);
            } elseif (is_file($f) && str_starts_with(basename($f), 'cookies-') && time() - (int) @filemtime($f) > 3600) {
                @unlink($f);
            }
        }
    }
}
