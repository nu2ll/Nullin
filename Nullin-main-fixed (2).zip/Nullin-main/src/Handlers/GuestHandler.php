<?php

final class GuestHandler
{
    public static function handle(array $msg): void
    {
        $qid = (string) ($msg['guest_query_id'] ?? '');
        if ($qid === '') {
            return;
        }
        $from = $msg['guest_bot_caller_user'] ?? $msg['from'] ?? [];
        $text = trim((string) ($msg['text'] ?? $msg['caption'] ?? ''));
        $bot  = App::botUsername();
        $q    = mbTrim(preg_replace('/@' . preg_quote($bot, '/') . '\b/iu', '', $text) ?? $text, " \t\n،,:");
        $q    = mbTrim(preg_replace('/^(?:نالینی|نالین|nullini|nullin)(?=[\s،,:!؟?.]|$)/iu', '', $q) ?? $q, " \t\n،,:");
        Users::hit('guest');

        $missing = Membership::missing((int) ($from['id'] ?? 0));
        if ($missing) {
            self::send($qid, Membership::text(), Membership::keyboard($missing));
            return;
        }

        $reply    = $msg['reply_to_message'] ?? null;
        $rt       = $reply ? trim((string) ($reply['text'] ?? $reply['caption'] ?? '')) : '';
        $hasMedia = Assistant::hasMedia($msg) || ($reply && Assistant::hasMedia($reply));

        if ($q === '' && $rt === '' && !$hasMedia) {
            self::send($qid, Ui::hello(), Ui::groupKeyboard());
            return;
        }

        if (Downloader::isIgStory($q . ' ' . $rt)) {
            return;
        }

        $link = $q !== '' ? Downloader::match($q) : ($rt !== '' ? Downloader::match($rt) : null);
        if (($link !== null && !Switches::on('download')) || ($link === null && !Switches::on('ai'))) {
            return;
        }
        if ($link !== null) {
            $imid = self::send($qid, L('🔎 دارم لینک ', '🔎 Checking the link ') . $link['name'] . L(' رو بررسی می‌کنم...', ' ...'));
            if ($imid !== null) {
                Users::hit('guest:dl');
                Downloader::guest($from, $link, $imid);
            }
            return;
        }

        if (AI::busy((int) ($from['id'] ?? 0))) {
            self::send($qid, (Lang::is('en') ? AI::BUSY_TEXT_EN : AI::BUSY_TEXT));
            return;
        }

        $voiceIn = isset($msg['voice']);
        $imid    = $voiceIn ? null : self::send($qid, (Lang::is('en') ? LiveReply::THINKING_EN : LiveReply::THINKING));

        $parts = [];
        $notes = [];
        if ($reply) {
            if ($m = Assistant::mediaPart($reply)) {
                $parts[] = $m;
                $notes[] = ('[The user replied to a ' . Assistant::kind($reply) . ' that is attached' . (Assistant::isFrame($reply) ? '; only its first-frame image is attached' : '') . ($rt !== '' ? "; its text: {$rt}" : '') . ']');
            } elseif ($info = Assistant::fileInfo($reply)) {
                $notes[] = ("[The user replied to a file; {$info}" . ($rt !== '' ? "; its text: {$rt}" : '') . ']');
            } elseif ($data = Assistant::dataInfo($reply)) {
                $notes[] = "[The user replied to a {$data[0]}; {$data[1]}]";
            } elseif ($rt !== '') {
                $notes[] = "[The message the user replied to]: {$rt}";
            } elseif (!empty($reply['from'])) {
                $notes[] = '[The user replied to a message that has no text]';
            }
        }
        if ($reply && $notes) {
            $notes[0] = Assistant::withAlbum($notes[0], $reply);
        }
        $n1 = count($notes);
        if (Assistant::hasMedia($msg)) {
            if ($m = Assistant::mediaPart($msg)) {
                $parts[] = $m;
                $notes[] = isset($msg['voice'])
                    ? '[The user sent a voice message; listen to it and answer]'
                    : (isset($msg['photo'])
                        ? '[The user sent a photo; look at it and answer]'
                        : ('[The user sent a ' . Assistant::kind($msg) . '; ' . (Assistant::isFrame($msg) ? 'only its first-frame image is attached' : 'its image is attached') . ', look at it and answer]'));
            } elseif ($info = Assistant::fileInfo($msg)) {
                $notes[] = "[The user sent a file; {$info}]";
            } elseif ($data = Assistant::dataInfo($msg)) {
                $notes[] = "[The user sent a {$data[0]}; {$data[1]}]";
            }
            if (count($notes) > $n1) {
                $notes[$n1] = Assistant::withAlbum($notes[$n1], $msg);
            }
        }
        $body    = trim(implode("\n", $notes) . ($q !== '' ? "\n\n{$q}" : ''));
        $content = $parts ? array_merge($parts, [['type' => 'text', 'text' => $body ?: 'Hello']]) : ($body ?: 'Hello');

        $ctx  = ['user_name' => userName($from), 'user_id' => (int) ($from['id'] ?? 0), 'chat_type' => 'guest'];
        $live = $imid !== null && App::cfg('ai_stream', true) ? new LiveReply($msg, $imid, '', false) : null;
        $live?->watch();
        $opt  = ['reaction' => false] + ($live ? ['on_text' => $live->feed(...)] : []);
        $res  = AI::reply($content, $ctx, [], $opt);
        $live?->stop();

        if (!empty($res['action'])) {
            [$act, $arg] = $res['action'];
            Users::hit('intent:' . $act);
            if ($act === 'download' && ($dl = Downloader::find($arg . ' ' . $rt)) !== null && $imid !== null) {
                Downloader::guest($from, $dl, $imid);
                return;
            }
            $o = Intent::output(['from' => $from] + $msg, $act, $arg, true, $imid);
            if ($o !== null) {
                self::show($imid, $qid, $o);
                return;
            }
            $res = AI::reply($content, ['no_action' => true] + $ctx, [], $opt);
        }

        if ($res['answer'] === null && empty($res['image']) && $parts) {
            logWarn('guest', 'reply with media failed, retrying text-only');
            $note = '[The user referred to a photo or voice message, but you have no access to its content; if their question depends on it, politely say you can\'t see files in this chat and that it\'s better to send it to you privately]';
            $res  = AI::reply(trim($note . ($rt !== '' ? "\n[Text of the replied message]: {$rt}" : '') . ($q !== '' ? "\n\n{$q}" : '')), $ctx, [], $opt);
        }

        if (!empty($res['image'])) {
            $imid ??= self::send($qid, (Lang::is('en') ? LiveReply::THINKING_EN : LiveReply::THINKING));
            self::image($imid, $qid, (string) $res['image'], (int) ($from['id'] ?? 0));
            return;
        }

        if ($res['answer'] !== null && $voiceIn && self::voice($qid, $res['answer'], (int) ($from['id'] ?? 0))) {
            return;
        }

        $answer = $res['answer'] ?? (Lang::is('en') ? AI::FAIL_TEXT_EN : AI::FAIL_TEXT);
        $html   = AI::toHtml(AI::fit($answer));
        $kb     = null;
        if ($res['answer'] !== null && $imid !== null && !$parts && !AI::$searched && trim($body) !== '' && ($kb = AnswerButtons::searchOnly()) !== null) {
            AnswerButtons::attachInline($imid, ['u' => (int) ($from['id'] ?? 0), 'q' => $body, 'a' => $answer, 'h' => '']);
        }
        if ($res['answer'] === null && $imid !== null && !$parts && trim($body) !== '') {
            $kb = AnswerButtons::retryKeyboard();
            AnswerButtons::attachInline($imid, ['u' => (int) ($from['id'] ?? 0), 'q' => $body, 'a' => $answer, 'h' => '', 'f' => 1]);
        }
        self::edit($imid, $qid, $html, $answer, $kb);
    }

    private static function voice(string $qid, string $answer, int $uid = 0): bool
    {
        $html = AI::toHtml($answer);
        if (AI::visible($html) > 1024) {
            return false;
        }
        $chat = (string) App::cfg('storage_chat', '');
        $chat = $chat !== '' ? $chat : (string) (App::cfg('admins', [])[0] ?? '');
        if ($chat === '') {
            return false;
        }
        $file = AI::speak($answer, null, 'ogg', VoicePick::get($uid));
        if ($file === null) {
            return false;
        }
        $tg = App::tg();
        $id = $tg->voiceFileId($chat, $file);
        @unlink($file);
        if ($id === null) {
            return false;
        }
        $r = $tg->call('answerGuestQuery', ['guest_query_id' => $qid, 'result' => [
            'type'          => 'voice',
            'id'            => substr(md5($qid . microtime()), 0, 16),
            'voice_file_id' => $id,
            'title'         => L('نالین', 'Nullin'),
            'caption'       => $html,
            'parse_mode'    => 'HTML',
        ]], 15);
        return !empty($r['ok']);
    }

    private static function failImage(?string $imid, ?string $qid, string $text, string $prompt, int $uid): void
    {
        if ($imid !== null && $prompt !== '') {
            AnswerButtons::attachInline($imid, ['u' => $uid, 'q' => $prompt, 'a' => $text, 'h' => '', 'f' => 1, 'k' => 'img']);
            self::edit($imid, $qid, $text, null, AnswerButtons::retryKeyboard());
            return;
        }
        self::edit($imid, $qid, $text);
    }

    public static function image(?string $imid, ?string $qid, string $prompt, int $uid = 0): void
    {
        self::edit($imid, null, (Lang::is('en') ? LiveReply::DRAWING_EN : LiveReply::DRAWING));
        $bytes = ImageGen::generate($prompt, static function () {});
        if ($bytes === null) {
            self::failImage($imid, $qid, ImageGen::failText(), $prompt, $uid);
            return;
        }
        if ($imid === null) {
            return;
        }
        $media = ImageGen::fileId($bytes);
        if ($media === null) {
            self::failImage($imid, $qid, L("😕 سرویس ساخت عکس الان جواب نمی‌ده؛\nچند دقیقه دیگه امتحان کن.", "😕 The image service isn't responding right now;\ntry again in a few minutes."), $prompt, $uid);
            return;
        }
        $tg = App::tg();
        $r  = $tg->call('editMessageMedia', [
            'inline_message_id' => $imid,
            'media'             => ['type' => 'photo', 'media' => $media, 'caption' => L('🎨 بفرما، اینم عکست!', '🎨 Here\'s your picture!'), 'parse_mode' => 'HTML'],
        ], 60);
        if (empty($r['ok'])) {
            self::failImage($imid, $qid, L('😕 عکس ساخته شد ولی ارسالش به مشکل خورد؛', '😕 The image was created but sending it failed;') . "\n" . L('دوباره امتحان کن.', 'try again.'), $prompt, $uid);
        }
    }

    public static function show(?string $imid, string $qid, array $o): void
    {
        $tg = App::tg();
        if ($imid !== null && !empty($o['retry'])) {
            AnswerButtons::attachInline($imid, $o['retry'] + ['q' => (string) ($o['retry']['q'] ?? '')]);
        }
        if ($imid === null) {
            self::send($qid, $o['text'], $o['kb'] ?? null);
            return;
        }
        if (!empty($o['md'])) {
            Rich::editInlineMd($imid, $o['md'], $o['kb'] ?? null);
            return;
        }
        if (!empty($o['photo']) && is_string($o['photo']) && str_starts_with($o['photo'], 'https://')) {
            $o['photo'] = self::photoId($o['photo']) ?? $o['photo'];   // لینک → file_id؛ اگه نشد همون لینک (رفتار قبلی)
        }
        if (!empty($o['photo']) && is_string($o['photo']) && preg_match('#^(?:https://|[A-Za-z0-9_-]{20,}$)#', $o['photo']) === 1 && (Rich::usable($o['kb'] ?? null) || !Rich::hasButtons($o['kb'] ?? null))) {
            $r = Rich::editInlinePhoto($imid, $o['text'], $o['photo'], $o['kb'] ?? null);
            if (!empty($r['ok'])) {
                return;
            }
        }
        if (!empty($o['photo']) || !empty($o['anim'])) {
            $r = $tg->call('editMessageMedia', [
                'inline_message_id' => $imid,
                'media'             => ['type' => !empty($o['photo']) ? 'photo' : 'animation', 'media' => $o['photo'] ?? $o['anim'], 'caption' => $o['text'], 'parse_mode' => 'HTML'],
                'reply_markup'      => $o['kb'] ?? null,
            ], 60);
            if (!empty($r['ok'])) {
                return;
            }
        }
        $img = $o['img'] ?? null;
        if (is_string($img) && str_starts_with($img, 'https://')) {
            $img = self::photoId($img);
        }
        $r = Rich::editInline($imid, $o['text'], $o['kb'] ?? null, $img, true, $o['preview'] ?? null);
        if (empty($r['ok']) && $img !== null) {
            Rich::editInline($imid, $o['text'], $o['kb'] ?? null, null, true, $o['preview'] ?? null);
        }
    }

    private static function photoId(string $url): ?string
    {
        return Wiki::photoId($url);
    }

    private static function send(string $qid, string $html, ?array $markup = null): ?string
    {
        $result = [
            'type'                  => 'article',
            'id'                    => substr(md5($qid . microtime()), 0, 16),
            'title'                 => L('نالین', 'Nullin'),
            'input_message_content' => ['message_text' => $html, 'parse_mode' => 'HTML', 'link_preview_options' => ['is_disabled' => true]],
        ];
        if (Rich::usable($markup)) {
            $result['input_message_content'] = Rich::inlineContent($html, $markup);
        } elseif ($markup !== null) {
            $result['reply_markup'] = $markup;
        }
        $r = App::tg()->call('answerGuestQuery', ['guest_query_id' => $qid, 'result' => $result], 15);
        return !empty($r['ok']) ? ($r['result']['inline_message_id'] ?? null) : null;
    }

    private static function edit(?string $imid, ?string $qid, string $html, ?string $plain = null, ?array $kb = null): void
    {
        $tg = App::tg();
        if ($imid === null) {
            if ($qid !== null) {
                self::send($qid, $html);
            }
            return;
        }
        if (empty(Rich::editInline($imid, $html, $kb)['ok']) && $plain !== null) {
            Rich::editInline($imid, mb_substr($plain, 0, 4096), $kb, null, false);
        }
    }
}
